

(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";window.sortPaths=require("./sort-paths.js");
},{"./sort-paths.js":3}],2:[function(require,module,exports){
"use strict";function splitRetain(e,t,r){if(r=defaults(r,{}),r.leadingSeparator=defaults(r.leadingSeparator,!1),assert.type(e,"string","`string` is not a string"),assert("string"==typeof t||t instanceof RegExp,"invalid `separator` type"),assert.type(r,"object","invalid `options` type"),assert.type(r.leadingSeparator,"boolean","invalid `options.leadingSeparator` type"),0===e.length)return[""];t=separatorToRegex(t);var n=e.split(t);if(1===n.length)return n;var s=[];for(r.leadingSeparator&&s.push(n.shift());n.length>0;)1===n.length?s.push(n.shift()):s.push(n.shift()+n.shift());return""===s[0]&&s.shift(),""===s[s.length-1]&&s.pop(),s}function separatorToRegex(e){return e instanceof RegExp?e:new RegExp("("+escapeRegex(e)+")","g")}function escapeRegex(e){return e.replace(/[-[\]{}()*+?.,\\^$|#\s]/g,"\\$&")}function assert(e,t){if(!e)throw new Error(t)}function defaults(e,t){return void 0===e?t:e}exports=module.exports=splitRetain,splitRetain.VERSION="1.0.1",assert.type=function(e,t,r){if(typeof e!==t)throw new Error(r)};
},{}],3:[function(require,module,exports){
"use strict";function sortPaths(t){assert(arguments.length>=2,"too few arguments"),assert(arguments.length<=3,"too many arguments");var r,e;2===arguments.length?(r=identity,e=arguments[1]):(r=arguments[1],e=arguments[2]),assert(isArray(t),"items is not an list"),assert(isFunction(r),"iteratee is not a function"),assert("string"==typeof e,"dirSeparator is not a String"),assert(1===e.length,"dirSeparator must be a single character");var n=t.map(function(t){var n=r(t);return assert("string"==typeof n,"item or iteratee(item) must be a String"),{item:t,pathTokens:splitRetain(n,e)}});return n.sort(createItemDTOComparator(e)),n.map(function(t){return t.item})}function createItemDTOComparator(t){return function(r,e){for(var n=r.pathTokens,a=e.pathTokens,o=0,i=Math.max(n.length,a.length);o<i;o++){if(!(o in n))return-1;if(!(o in a))return 1;var s=n[o].toLowerCase(),u=a[o].toLowerCase();if(s!==u){var c=s[s.length-1]===t;return c===(u[u.length-1]===t)?s<u?-1:1:c?1:-1}}return 0}}function assert(t,r){if(!t)throw new Error(r)}function identity(t){return t}function isFunction(t){return Boolean(t)&&"[object Function]"===Object.prototype.toString.call(t)}function isArray(t){return Boolean(t)&&"[object Array]"===Object.prototype.toString.call(t)}var splitRetain=require("split-retain");module.exports=sortPaths,sortPaths.VERSION="1.1.1";
},{"split-retain":2}]},{},[1]);

!function(t,e){"object"==typeof exports&&"object"==typeof module?module.exports=e():"function"==typeof define&&define.amd?define([],e):"object"==typeof exports?exports.Pickr=e():t.Pickr=e()}(self,(function(){return(()=>{"use strict";var t={d:(e,o)=>{for(var n in o)t.o(o,n)&&!t.o(e,n)&&Object.defineProperty(e,n,{enumerable:!0,get:o[n]})},o:(t,e)=>Object.prototype.hasOwnProperty.call(t,e),r:t=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(t,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(t,"__esModule",{value:!0})}},e={};t.d(e,{default:()=>L});var o={};function n(t,e,o,n,i={}){e instanceof HTMLCollection||e instanceof NodeList?e=Array.from(e):Array.isArray(e)||(e=[e]),Array.isArray(o)||(o=[o]);for(const s of e)for(const e of o)s[t](e,n,{capture:!1,...i});return Array.prototype.slice.call(arguments,1)}t.r(o),t.d(o,{adjustableInputNumbers:()=>p,createElementFromString:()=>r,createFromTemplate:()=>a,eventPath:()=>l,off:()=>s,on:()=>i,resolveElement:()=>c});const i=n.bind(null,"addEventListener"),s=n.bind(null,"removeEventListener");function r(t){const e=document.createElement("div");return e.innerHTML=t.trim(),e.firstElementChild}function a(t){const e=(t,e)=>{const o=t.getAttribute(e);return t.removeAttribute(e),o},o=(t,n={})=>{const i=e(t,":obj"),s=e(t,":ref"),r=i?n[i]={}:n;s&&(n[s]=t);for(const n of Array.from(t.children)){const t=e(n,":arr"),i=o(n,t?{}:r);t&&(r[t]||(r[t]=[])).push(Object.keys(i).length?i:n)}return n};return o(r(t))}function l(t){let e=t.path||t.composedPath&&t.composedPath();if(e)return e;let o=t.target.parentElement;for(e=[t.target,o];o=o.parentElement;)e.push(o);return e.push(document,window),e}function c(t){return t instanceof Element?t:"string"==typeof t?t.split(/>>/g).reduce(((t,e,o,n)=>(t=t.querySelector(e),o<n.length-1?t.shadowRoot:t)),document):null}function p(t,e=(t=>t)){function o(o){const n=[.001,.01,.1][Number(o.shiftKey||2*o.ctrlKey)]*(o.deltaY<0?1:-1);let i=0,s=t.selectionStart;t.value=t.value.replace(/[\d.]+/g,((t,o)=>o<=s&&o+t.length>=s?(s=o,e(Number(t),n,i)):(i++,t))),t.focus(),t.setSelectionRange(s,s),o.preventDefault(),t.dispatchEvent(new Event("input"))}i(t,"focus",(()=>i(window,"wheel",o,{passive:!1}))),i(t,"blur",(()=>s(window,"wheel",o)))}const{min:u,max:h,floor:d,round:m}=Math;function f(t,e,o){e/=100,o/=100;const n=d(t=t/360*6),i=t-n,s=o*(1-e),r=o*(1-i*e),a=o*(1-(1-i)*e),l=n%6;return[255*[o,r,s,s,a,o][l],255*[a,o,o,r,s,s][l],255*[s,s,a,o,o,r][l]]}function v(t,e,o){const n=(2-(e/=100))*(o/=100)/2;return 0!==n&&(e=1===n?0:n<.5?e*o/(2*n):e*o/(2-2*n)),[t,100*e,100*n]}function b(t,e,o){const n=u(t/=255,e/=255,o/=255),i=h(t,e,o),s=i-n;let r,a;if(0===s)r=a=0;else{a=s/i;const n=((i-t)/6+s/2)/s,l=((i-e)/6+s/2)/s,c=((i-o)/6+s/2)/s;t===i?r=c-l:e===i?r=1/3+n-c:o===i&&(r=2/3+l-n),r<0?r+=1:r>1&&(r-=1)}return[360*r,100*a,100*i]}function y(t,e,o,n){e/=100,o/=100;return[...b(255*(1-u(1,(t/=100)*(1-(n/=100))+n)),255*(1-u(1,e*(1-n)+n)),255*(1-u(1,o*(1-n)+n)))]}function g(t,e,o){e/=100;const n=2*(e*=(o/=100)<.5?o:1-o)/(o+e)*100,i=100*(o+e);return[t,isNaN(n)?0:n,i]}function _(t){return b(...t.match(/.{2}/g).map((t=>parseInt(t,16))))}function w(t){t=t.match(/^[a-zA-Z]+$/)?function(t){if("black"===t.toLowerCase())return"#000";const e=document.createElement("canvas").getContext("2d");return e.fillStyle=t,"#000"===e.fillStyle?null:e.fillStyle}(t):t;const e={cmyk:/^cmyk[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)/i,rgba:/^((rgba)|rgb)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]*?([\d.]+|$)/i,hsla:/^((hsla)|hsl)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]*?([\d.]+|$)/i,hsva:/^((hsva)|hsv)[\D]+([\d.]+)[\D]+([\d.]+)[\D]+([\d.]+)[\D]*?([\d.]+|$)/i,hexa:/^#?(([\dA-Fa-f]{3,4})|([\dA-Fa-f]{6})|([\dA-Fa-f]{8}))$/i},o=t=>t.map((t=>/^(|\d+)\.\d+|\d+$/.test(t)?Number(t):void 0));let n;t:for(const i in e){if(!(n=e[i].exec(t)))continue;const s=t=>!!n[2]==("number"==typeof t);switch(i){case"cmyk":{const[,t,e,s,r]=o(n);if(t>100||e>100||s>100||r>100)break t;return{values:y(t,e,s,r),type:i}}case"rgba":{const[,,,t,e,r,a]=o(n);if(t>255||e>255||r>255||a<0||a>1||!s(a))break t;return{values:[...b(t,e,r),a],a,type:i}}case"hexa":{let[,t]=n;4!==t.length&&3!==t.length||(t=t.split("").map((t=>t+t)).join(""));const e=t.substring(0,6);let o=t.substring(6);return o=o?parseInt(o,16)/255:void 0,{values:[..._(e),o],a:o,type:i}}case"hsla":{const[,,,t,e,r,a]=o(n);if(t>360||e>100||r>100||a<0||a>1||!s(a))break t;return{values:[...g(t,e,r),a],a,type:i}}case"hsva":{const[,,,t,e,r,a]=o(n);if(t>360||e>100||r>100||a<0||a>1||!s(a))break t;return{values:[t,e,r,a],a,type:i}}}}return{values:null,type:null}}function A(t=0,e=0,o=0,n=1){const i=(t,e)=>(o=-1)=>e(~o?t.map((t=>Number(t.toFixed(o)))):t),s={h:t,s:e,v:o,a:n,toHSVA(){const t=[s.h,s.s,s.v,s.a];return t.toString=i(t,(t=>`hsva(${t[0]}, ${t[1]}%, ${t[2]}%, ${s.a})`)),t},toHSLA(){const t=[...v(s.h,s.s,s.v),s.a];return t.toString=i(t,(t=>`hsla(${t[0]}, ${t[1]}%, ${t[2]}%, ${s.a})`)),t},toRGBA(){const t=[...f(s.h,s.s,s.v),s.a];return t.toString=i(t,(t=>`rgba(${t[0]}, ${t[1]}, ${t[2]}, ${s.a})`)),t},toCMYK(){const t=function(t,e,o){const n=f(t,e,o),i=n[0]/255,s=n[1]/255,r=n[2]/255,a=u(1-i,1-s,1-r);return[100*(1===a?0:(1-i-a)/(1-a)),100*(1===a?0:(1-s-a)/(1-a)),100*(1===a?0:(1-r-a)/(1-a)),100*a]}(s.h,s.s,s.v);return t.toString=i(t,(t=>`cmyk(${t[0]}%, ${t[1]}%, ${t[2]}%, ${t[3]}%)`)),t},toHEXA(){const t=function(t,e,o){return f(t,e,o).map((t=>m(t).toString(16).padStart(2,"0")))}(s.h,s.s,s.v),e=s.a>=1?"":Number((255*s.a).toFixed(0)).toString(16).toUpperCase().padStart(2,"0");return e&&t.push(e),t.toString=()=>`#${t.join("").toUpperCase()}`,t},clone:()=>A(s.h,s.s,s.v,s.a)};return s}const C=t=>Math.max(Math.min(t,1),0);function $(t){const e={options:Object.assign({lock:null,onchange:()=>0,onstop:()=>0},t),_keyboard(t){const{options:o}=e,{type:n,key:i}=t;if(document.activeElement===o.wrapper){const{lock:o}=e.options,s="ArrowUp"===i,r="ArrowRight"===i,a="ArrowDown"===i,l="ArrowLeft"===i;if("keydown"===n&&(s||r||a||l)){let n=0,i=0;"v"===o?n=s||r?1:-1:"h"===o?n=s||r?-1:1:(i=s?-1:a?1:0,n=l?-1:r?1:0),e.update(C(e.cache.x+.01*n),C(e.cache.y+.01*i)),t.preventDefault()}else i.startsWith("Arrow")&&(e.options.onstop(),t.preventDefault())}},_tapstart(t){i(document,["mouseup","touchend","touchcancel"],e._tapstop),i(document,["mousemove","touchmove"],e._tapmove),t.cancelable&&t.preventDefault(),e._tapmove(t)},_tapmove(t){const{options:o,cache:n}=e,{lock:i,element:s,wrapper:r}=o,a=r.getBoundingClientRect();let l=0,c=0;if(t){const e=t&&t.touches&&t.touches[0];l=t?(e||t).clientX:0,c=t?(e||t).clientY:0,l<a.left?l=a.left:l>a.left+a.width&&(l=a.left+a.width),c<a.top?c=a.top:c>a.top+a.height&&(c=a.top+a.height),l-=a.left,c-=a.top}else n&&(l=n.x*a.width,c=n.y*a.height);"h"!==i&&(s.style.left=`calc(${l/a.width*100}% - ${s.offsetWidth/2}px)`),"v"!==i&&(s.style.top=`calc(${c/a.height*100}% - ${s.offsetHeight/2}px)`),e.cache={x:l/a.width,y:c/a.height};const p=C(l/a.width),u=C(c/a.height);switch(i){case"v":return o.onchange(p);case"h":return o.onchange(u);default:return o.onchange(p,u)}},_tapstop(){e.options.onstop(),s(document,["mouseup","touchend","touchcancel"],e._tapstop),s(document,["mousemove","touchmove"],e._tapmove)},trigger(){e._tapmove()},update(t=0,o=0){const{left:n,top:i,width:s,height:r}=e.options.wrapper.getBoundingClientRect();"h"===e.options.lock&&(o=t),e._tapmove({clientX:n+s*t,clientY:i+r*o})},destroy(){const{options:t,_tapstart:o,_keyboard:n}=e;s(document,["keydown","keyup"],n),s([t.wrapper,t.element],"mousedown",o),s([t.wrapper,t.element],"touchstart",o,{passive:!1})}},{options:o,_tapstart:n,_keyboard:r}=e;return i([o.wrapper,o.element],"mousedown",n),i([o.wrapper,o.element],"touchstart",n,{passive:!1}),i(document,["keydown","keyup"],r),e}function k(t={}){t=Object.assign({onchange:()=>0,className:"",elements:[]},t);const e=i(t.elements,"click",(e=>{t.elements.forEach((o=>o.classList[e.target===o?"add":"remove"](t.className))),t.onchange(e),e.stopPropagation()}));return{destroy:()=>s(...e)}}const S={variantFlipOrder:{start:"sme",middle:"mse",end:"ems"},positionFlipOrder:{top:"tbrl",right:"rltb",bottom:"btrl",left:"lrbt"},position:"bottom",margin:8},O=(t,e,o)=>{const{container:n,margin:i,position:s,variantFlipOrder:r,positionFlipOrder:a}={container:document.documentElement.getBoundingClientRect(),...S,...o},{left:l,top:c}=e.style;e.style.left="0",e.style.top="0";const p=t.getBoundingClientRect(),u=e.getBoundingClientRect(),h={t:p.top-u.height-i,b:p.bottom+i,r:p.right+i,l:p.left-u.width-i},d={vs:p.left,vm:p.left+p.width/2+-u.width/2,ve:p.left+p.width-u.width,hs:p.top,hm:p.bottom-p.height/2-u.height/2,he:p.bottom-u.height},[m,f="middle"]=s.split("-"),v=a[m],b=r[f],{top:y,left:g,bottom:_,right:w}=n;for(const t of v){const o="t"===t||"b"===t,n=h[t],[i,s]=o?["top","left"]:["left","top"],[r,a]=o?[u.height,u.width]:[u.width,u.height],[l,c]=o?[_,w]:[w,_],[p,m]=o?[y,g]:[g,y];if(!(n<p||n+r>l))for(const r of b){const l=d[(o?"v":"h")+r];if(!(l<m||l+a>c))return e.style[s]=l-u[s]+"px",e.style[i]=n-u[i]+"px",t+r}}return e.style.left=l,e.style.top=c,null};function E(t,e,o){return e in t?Object.defineProperty(t,e,{value:o,enumerable:!0,configurable:!0,writable:!0}):t[e]=o,t}class L{constructor(t){E(this,"_initializingActive",!0),E(this,"_recalc",!0),E(this,"_nanopop",null),E(this,"_root",null),E(this,"_color",A()),E(this,"_lastColor",A()),E(this,"_swatchColors",[]),E(this,"_setupAnimationFrame",null),E(this,"_eventListener",{init:[],save:[],hide:[],show:[],clear:[],change:[],changestop:[],cancel:[],swatchselect:[]}),this.options=t=Object.assign({...L.DEFAULT_OPTIONS},t);const{swatches:e,components:o,theme:n,sliders:i,lockOpacity:s,padding:r}=t;["nano","monolith"].includes(n)&&!i&&(t.sliders="h"),o.interaction||(o.interaction={});const{preview:a,opacity:l,hue:c,palette:p}=o;o.opacity=!s&&l,o.palette=p||a||l||c,this._preBuild(),this._buildComponents(),this._bindEvents(),this._finalBuild(),e&&e.length&&e.forEach((t=>this.addSwatch(t)));const{button:u,app:h}=this._root;this._nanopop=((t,e,o)=>{const n="object"!=typeof t||t instanceof HTMLElement?{reference:t,popper:e,...o}:t;return{update(t=n){const{reference:e,popper:o}=Object.assign(n,t);if(!o||!e)throw new Error("Popper- or reference-element missing.");return O(e,o,n)}}})(u,h,{margin:r}),u.setAttribute("role","button"),u.setAttribute("aria-label",this._t("btn:toggle"));const d=this;this._setupAnimationFrame=requestAnimationFrame((function e(){if(!h.offsetWidth)return requestAnimationFrame(e);d.setColor(t.default),d._rePositioningPicker(),t.defaultRepresentation&&(d._representation=t.defaultRepresentation,d.setColorRepresentation(d._representation)),t.showAlways&&d.show(),d._initializingActive=!1,d._emit("init")}))}_preBuild(){const{options:t}=this;for(const e of["el","container"])t[e]=c(t[e]);this._root=(t=>{const{components:e,useAsButton:o,inline:n,appClass:i,theme:s,lockOpacity:r}=t.options,l=t=>t?"":'style="display:none" hidden',c=e=>t._t(e),p=a(`\n      <div :ref="root" class="pickr">\n\n        ${o?"":'<button type="button" :ref="button" class="pcr-button"></button>'}\n\n        <div :ref="app" class="pcr-app ${i||""}" data-theme="${s}" ${n?'style="position: unset"':""} aria-label="${c("ui:dialog")}" role="window">\n          <div class="pcr-selection" ${l(e.palette)}>\n            <div :obj="preview" class="pcr-color-preview" ${l(e.preview)}>\n              <button type="button" :ref="lastColor" class="pcr-last-color" aria-label="${c("btn:last-color")}"></button>\n              <div :ref="currentColor" class="pcr-current-color"></div>\n            </div>\n\n            <div :obj="palette" class="pcr-color-palette">\n              <div :ref="picker" class="pcr-picker"></div>\n              <div :ref="palette" class="pcr-palette" tabindex="0" aria-label="${c("aria:palette")}" role="listbox"></div>\n            </div>\n\n            <div :obj="hue" class="pcr-color-chooser" ${l(e.hue)}>\n              <div :ref="picker" class="pcr-picker"></div>\n              <div :ref="slider" class="pcr-hue pcr-slider" tabindex="0" aria-label="${c("aria:hue")}" role="slider"></div>\n            </div>\n\n            <div :obj="opacity" class="pcr-color-opacity" ${l(e.opacity)}>\n              <div :ref="picker" class="pcr-picker"></div>\n              <div :ref="slider" class="pcr-opacity pcr-slider" tabindex="0" aria-label="${c("aria:opacity")}" role="slider"></div>\n            </div>\n          </div>\n\n          <div class="pcr-swatches ${e.palette?"":"pcr-last"}" :ref="swatches"></div>\n\n          <div :obj="interaction" class="pcr-interaction" ${l(Object.keys(e.interaction).length)}>\n            <input :ref="result" class="pcr-result" type="text" spellcheck="false" ${l(e.interaction.input)} aria-label="${c("aria:input")}">\n\n            <input :arr="options" class="pcr-type" data-type="HEXA" value="${r?"HEX":"HEXA"}" type="button" ${l(e.interaction.hex)}>\n            <input :arr="options" class="pcr-type" data-type="RGBA" value="${r?"RGB":"RGBA"}" type="button" ${l(e.interaction.rgba)}>\n            <input :arr="options" class="pcr-type" data-type="HSLA" value="${r?"HSL":"HSLA"}" type="button" ${l(e.interaction.hsla)}>\n            <input :arr="options" class="pcr-type" data-type="HSVA" value="${r?"HSV":"HSVA"}" type="button" ${l(e.interaction.hsva)}>\n            <input :arr="options" class="pcr-type" data-type="CMYK" value="CMYK" type="button" ${l(e.interaction.cmyk)}>\n\n            <input :ref="save" class="pcr-save" value="${c("btn:save")}" type="button" ${l(e.interaction.save)} aria-label="${c("aria:btn:save")}">\n            <input :ref="cancel" class="pcr-cancel" value="${c("btn:cancel")}" type="button" ${l(e.interaction.cancel)} aria-label="${c("aria:btn:cancel")}">\n            <input :ref="clear" class="pcr-clear" value="${c("btn:clear")}" type="button" ${l(e.interaction.clear)} aria-label="${c("aria:btn:clear")}">\n          </div>\n        </div>\n      </div>\n    `),u=p.interaction;return u.options.find((t=>!t.hidden&&!t.classList.add("active"))),u.type=()=>u.options.find((t=>t.classList.contains("active"))),p})(this),t.useAsButton&&(this._root.button=t.el),t.container.appendChild(this._root.root)}_finalBuild(){const t=this.options,e=this._root;if(t.container.removeChild(e.root),t.inline){const o=t.el.parentElement;t.el.nextSibling?o.insertBefore(e.app,t.el.nextSibling):o.appendChild(e.app)}else t.container.appendChild(e.app);t.useAsButton?t.inline&&t.el.remove():t.el.parentNode.replaceChild(e.root,t.el),t.disabled&&this.disable(),t.comparison||(e.button.style.transition="none",t.useAsButton||(e.preview.lastColor.style.transition="none")),this.hide()}_buildComponents(){const t=this,e=this.options.components,o=(t.options.sliders||"v").repeat(2),[n,i]=o.match(/^[vh]+$/g)?o:[],s=()=>this._color||(this._color=this._lastColor.clone()),r={palette:$({element:t._root.palette.picker,wrapper:t._root.palette.palette,onstop:()=>t._emit("changestop","slider",t),onchange(o,n){if(!e.palette)return;const i=s(),{_root:r,options:a}=t,{lastColor:l,currentColor:c}=r.preview;t._recalc&&(i.s=100*o,i.v=100-100*n,i.v<0&&(i.v=0),t._updateOutput("slider"));const p=i.toRGBA().toString(0);this.element.style.background=p,this.wrapper.style.background=`\n                        linear-gradient(to top, rgba(0, 0, 0, ${i.a}), transparent),\n                        linear-gradient(to left, hsla(${i.h}, 100%, 50%, ${i.a}), rgba(255, 255, 255, ${i.a}))\n                    `,a.comparison?a.useAsButton||t._lastColor||l.style.setProperty("--pcr-color",p):(r.button.style.setProperty("--pcr-color",p),r.button.classList.remove("clear"));const u=i.toHEXA().toString();for(const{el:e,color:o}of t._swatchColors)e.classList[u===o.toHEXA().toString()?"add":"remove"]("pcr-active");c.style.setProperty("--pcr-color",p)}}),hue:$({lock:"v"===i?"h":"v",element:t._root.hue.picker,wrapper:t._root.hue.slider,onstop:()=>t._emit("changestop","slider",t),onchange(o){if(!e.hue||!e.palette)return;const n=s();t._recalc&&(n.h=360*o),this.element.style.backgroundColor=`hsl(${n.h}, 100%, 50%)`,r.palette.trigger()}}),opacity:$({lock:"v"===n?"h":"v",element:t._root.opacity.picker,wrapper:t._root.opacity.slider,onstop:()=>t._emit("changestop","slider",t),onchange(o){if(!e.opacity||!e.palette)return;const n=s();t._recalc&&(n.a=Math.round(100*o)/100),this.element.style.background=`rgba(0, 0, 0, ${n.a})`,r.palette.trigger()}}),selectable:k({elements:t._root.interaction.options,className:"active",onchange(e){t._representation=e.target.getAttribute("data-type").toUpperCase(),t._recalc&&t._updateOutput("swatch")}})};this._components=r}_bindEvents(){const{_root:t,options:e}=this,o=[i(t.interaction.clear,"click",(()=>this._clearColor())),i([t.interaction.cancel,t.preview.lastColor],"click",(()=>{this.setHSVA(...(this._lastColor||this._color).toHSVA(),!0),this._emit("cancel")})),i(t.interaction.save,"click",(()=>{!this.applyColor()&&!e.showAlways&&this.hide()})),i(t.interaction.result,["keyup","input"],(t=>{this.setColor(t.target.value,!0)&&!this._initializingActive&&(this._emit("change",this._color,"input",this),this._emit("changestop","input",this)),t.stopImmediatePropagation()})),i(t.interaction.result,["focus","blur"],(t=>{this._recalc="blur"===t.type,this._recalc&&this._updateOutput(null)})),i([t.palette.palette,t.palette.picker,t.hue.slider,t.hue.picker,t.opacity.slider,t.opacity.picker],["mousedown","touchstart"],(()=>this._recalc=!0),{passive:!0})];if(!e.showAlways){const n=e.closeWithKey;o.push(i(t.button,"click",(()=>this.isOpen()?this.hide():this.show())),i(document,"keyup",(t=>this.isOpen()&&(t.key===n||t.code===n)&&this.hide())),i(document,["touchstart","mousedown"],(e=>{this.isOpen()&&!l(e).some((e=>e===t.app||e===t.button))&&this.hide()}),{capture:!0}))}if(e.adjustableNumbers){const e={rgba:[255,255,255,1],hsva:[360,100,100,1],hsla:[360,100,100,1],cmyk:[100,100,100,100]};p(t.interaction.result,((t,o,n)=>{const i=e[this.getColorRepresentation().toLowerCase()];if(i){const e=i[n],s=t+(e>=100?1e3*o:o);return s<=0?0:Number((s<e?s:e).toPrecision(3))}return t}))}if(e.autoReposition&&!e.inline){let t=null;const n=this;o.push(i(window,["scroll","resize"],(()=>{n.isOpen()&&(e.closeOnScroll&&n.hide(),null===t?(t=setTimeout((()=>t=null),100),requestAnimationFrame((function e(){n._rePositioningPicker(),null!==t&&requestAnimationFrame(e)}))):(clearTimeout(t),t=setTimeout((()=>t=null),100)))}),{capture:!0}))}this._eventBindings=o}_rePositioningPicker(){const{options:t}=this;if(!t.inline){if(!this._nanopop.update({container:document.body.getBoundingClientRect(),position:t.position})){const t=this._root.app,e=t.getBoundingClientRect();t.style.top=(window.innerHeight-e.height)/2+"px",t.style.left=(window.innerWidth-e.width)/2+"px"}}}_updateOutput(t){const{_root:e,_color:o,options:n}=this;if(e.interaction.type()){const t=`to${e.interaction.type().getAttribute("data-type")}`;e.interaction.result.value="function"==typeof o[t]?o[t]().toString(n.outputPrecision):""}!this._initializingActive&&this._recalc&&this._emit("change",o,t,this)}_clearColor(t=!1){const{_root:e,options:o}=this;o.useAsButton||e.button.style.setProperty("--pcr-color","rgba(0, 0, 0, 0.15)"),e.button.classList.add("clear"),o.showAlways||this.hide(),this._lastColor=null,this._initializingActive||t||(this._emit("save",null),this._emit("clear"))}_parseLocalColor(t){const{values:e,type:o,a:n}=w(t),{lockOpacity:i}=this.options,s=void 0!==n&&1!==n;return e&&3===e.length&&(e[3]=void 0),{values:!e||i&&s?null:e,type:o}}_t(t){return this.options.i18n[t]||L.I18N_DEFAULTS[t]}_emit(t,...e){this._eventListener[t].forEach((t=>t(...e,this)))}on(t,e){return this._eventListener[t].push(e),this}off(t,e){const o=this._eventListener[t]||[],n=o.indexOf(e);return~n&&o.splice(n,1),this}addSwatch(t){const{values:e}=this._parseLocalColor(t);if(e){const{_swatchColors:t,_root:o}=this,n=A(...e),s=r(`<button type="button" style="--pcr-color: ${n.toRGBA().toString(0)}" aria-label="${this._t("btn:swatch")}"/>`);return o.swatches.appendChild(s),t.push({el:s,color:n}),this._eventBindings.push(i(s,"click",(()=>{this.setHSVA(...n.toHSVA(),!0),this._emit("swatchselect",n),this._emit("change",n,"swatch",this)}))),!0}return!1}removeSwatch(t){const e=this._swatchColors[t];if(e){const{el:o}=e;return this._root.swatches.removeChild(o),this._swatchColors.splice(t,1),!0}return!1}applyColor(t=!1){const{preview:e,button:o}=this._root,n=this._color.toRGBA().toString(0);return e.lastColor.style.setProperty("--pcr-color",n),this.options.useAsButton||o.style.setProperty("--pcr-color",n),o.classList.remove("clear"),this._lastColor=this._color.clone(),this._initializingActive||t||this._emit("save",this._color),this}destroy(){cancelAnimationFrame(this._setupAnimationFrame),this._eventBindings.forEach((t=>s(...t))),Object.keys(this._components).forEach((t=>this._components[t].destroy()))}destroyAndRemove(){this.destroy();const{root:t,app:e}=this._root;t.parentElement&&t.parentElement.removeChild(t),e.parentElement.removeChild(e),Object.keys(this).forEach((t=>this[t]=null))}hide(){return!!this.isOpen()&&(this._root.app.classList.remove("visible"),this._emit("hide"),!0)}show(){return!this.options.disabled&&!this.isOpen()&&(this._root.app.classList.add("visible"),this._rePositioningPicker(),this._emit("show",this._color),this)}isOpen(){return this._root.app.classList.contains("visible")}setHSVA(t=360,e=0,o=0,n=1,i=!1){const s=this._recalc;if(this._recalc=!1,t<0||t>360||e<0||e>100||o<0||o>100||n<0||n>1)return!1;this._color=A(t,e,o,n);const{hue:r,opacity:a,palette:l}=this._components;return r.update(t/360),a.update(n),l.update(e/100,1-o/100),i||this.applyColor(),s&&this._updateOutput(),this._recalc=s,!0}setColor(t,e=!1){if(null===t)return this._clearColor(e),!0;const{values:o,type:n}=this._parseLocalColor(t);if(o){const t=n.toUpperCase(),{options:i}=this._root.interaction,s=i.find((e=>e.getAttribute("data-type")===t));if(s&&!s.hidden)for(const t of i)t.classList[t===s?"add":"remove"]("active");return!!this.setHSVA(...o,e)&&this.setColorRepresentation(t)}return!1}setColorRepresentation(t){return t=t.toUpperCase(),!!this._root.interaction.options.find((e=>e.getAttribute("data-type").startsWith(t)&&!e.click()))}getColorRepresentation(){return this._representation}getColor(){return this._color}getSelectedColor(){return this._lastColor}getRoot(){return this._root}disable(){return this.hide(),this.options.disabled=!0,this._root.button.classList.add("disabled"),this}enable(){return this.options.disabled=!1,this._root.button.classList.remove("disabled"),this}}return E(L,"utils",o),E(L,"version","1.8.2"),E(L,"I18N_DEFAULTS",{"ui:dialog":"color picker dialog","btn:toggle":"toggle color picker dialog","btn:swatch":"color swatch","btn:last-color":"use previous color","btn:save":"Save","btn:cancel":"Cancel","btn:clear":"Clear","aria:btn:save":"save and close","aria:btn:cancel":"cancel and close","aria:btn:clear":"clear and close","aria:input":"color input field","aria:palette":"color selection area","aria:hue":"hue selection slider","aria:opacity":"selection slider"}),E(L,"DEFAULT_OPTIONS",{appClass:null,theme:"classic",useAsButton:!1,padding:8,disabled:!1,comparison:!0,closeOnScroll:!1,outputPrecision:0,lockOpacity:!1,autoReposition:!0,container:"body",components:{interaction:{}},i18n:{},swatches:null,inline:!1,sliders:null,default:"#42445a",defaultRepresentation:null,position:"bottom-middle",adjustableNumbers:!0,showAlways:!1,closeWithKey:"Escape"}),E(L,"create",(t=>new L(t))),e=e.default})()}));



class HubError extends Error{}
const HubErrors={None:0,OpenFile:1,FreeSpace:2,CrcMiss:3,SizeMiss:4,Start:5,Write:6,End:7,Abort:8,Timeout:9,Busy:10,Memory:11,WrongClient:12,Forbidden:13,Disabled:14,WrongType:15,PacketDamage:16,CantAlloc:17,FsBusy:18,Cancelled:19,};class DeviceError extends HubError{constructor(code){super(`Device error: ${code}`);this.code=code;}}
class TimeoutError extends HubError{constructor(){super("Timed out");}}

class AsyncTimer{#timeout;#handler;#tid;constructor(timeout=undefined,handler=undefined){this.#timeout=timeout;this.#handler=handler;}
get running(){return this.#tid!==undefined;}
start(timeout=undefined){if(timeout===undefined)timeout=this.#timeout;if(timeout===undefined||this.running)return;this.#tid=setTimeout(()=>{this.handle();},timeout);}
cancel(){if(this.running)clearTimeout(this.#tid);this.#tid=undefined;}
restart(timeout=undefined){this.cancel();this.start(timeout);}
handle(){const handler=this.#handler;if(handler!==undefined)handler();}}
function makeWaiter(){let resolve,reject;const wait=new Promise((res,rej)=>{resolve=res;reject=rej;});return{wait,resolve,reject};}
class AsyncLock{#locked=false;#queue=[];get locked(){return this.#locked;}
async runExclusive(callback,timeout=-1){const release=await this.acquire(timeout);try{return await callback();}finally{release();}}
async acquire(timeout=-1){if(!this.#locked){this.#locked=true;return this.#newReleaser();}
if(timeout===0)
throw new TimeoutError();let{wait,resolve,reject}=makeWaiter();if(timeout>0){const timer=new AsyncTimer(timeout,()=>reject(new TimeoutError()));timer.start();this.#queue.push({resolve,reject,timer});}else{this.#queue.push({resolve,reject,timer:undefined});}
this.#dispatch();return await wait;}#dispatch(){if(!this.#locked&&this.#queue.length){const entry=this.#queue.shift();this.#locked=true;if(entry.timer)clearTimeout(entry.timer);entry.resolve(this.#newReleaser());}}#newReleaser(){let called=false;return()=>{if(called)return;called=true;this.#release();};}#release(){if(this.#locked)
this.#locked=false;this.#dispatch();}
cancel(){this.#queue.forEach((entry)=>entry.reject(this._cancelError));this.#queue=[];}}

class PacketBufferScanFirst{#callback;#timeout;#buf;#tout;constructor(callback,timeout=600){this.#callback=callback;this.#timeout=timeout;this.#buf=[];}
push(data){if(this.#tout)clearTimeout(this.#tout);this.#tout=setTimeout(()=>this.#buf.length=0,this.#timeout);if(!this.#buf&&!data.startsWith('#{'))
return;this.#buf.push(data);if(data.endsWith('}#')&&this.#buf[0][0]===data[data.length-1]){this.#callback(this.#buf.join(''));this.#buf.length=0;if(this.#tout)clearTimeout(this._tout);this.#tout=null;}}
clear(){if(this.#tout)clearTimeout(this.#tout);this.#tout=undefined;this.#buf.length=0;}};class PacketBufferScanAll{#callback;#timeout;#buf;#tout=null;constructor(callback,timeout=600){this.#callback=callback;this.#timeout=timeout;this.#buf=null;}
push(data){if(this.#tout)clearTimeout(this.#tout);this.#tout=setTimeout(()=>this.#buf=null,this.#timeout);if(this.#buf){const merged=new Uint8Array(this.#buf.length+data.length);merged.set(this.#buf);merged.set(data,this.#buf.length);this.#buf=merged;data=null;}else{this.#buf=data;}
this.#pump();}#pump(){let index=0;const decoder=new TextDecoder();while(true){let startIndex=this.#indexOfSeq('#{',index);let endIndex=this.#indexOfSeq('}#',startIndex);if(startIndex===this.#buf.length||endIndex===this.#buf.length)
break;const text=decoder.decode(this.#buf.subarray(startIndex,endIndex+2));this.#callback(text);index=endIndex+2;}
if(index){this.#buf=this.#buf.slice(index);}}#indexOfSeq(seq,fromIndex=0){while(true){const i=this.#buf.indexOf(seq.charCodeAt(0),fromIndex);if(i===-1||i>this.#buf.length-2)
return this.#buf.length;if(this.#buf[i+1]===seq.charCodeAt(1)){return i;}
fromIndex=i+1;}}};
class CyclicBuffer{#buffer;#head;#tail;#max;#full;constructor(size){if(typeof size==="number"){this.#max=size;this.#buffer=new Uint8Array(this.#max);}else{this.#max=size.length;this.#buffer=size;}
this.#head=this.#tail=0;this.#full=false;}
isFull(){return this.#full;}
isEmpty(){return this.#head==this.#tail&&!this.#full;}
capacity(){return this.#max;}
size(){if(this.#full)return this.#max;if(this.#head>=this.#tail)return this.#head-this.#tail;return this.#head+this.#max-this.#tail;}
available(){if(this.#full)return 0;if(this.#head>=this.#tail)return this.#max-this.#head+this.#tail;return this.#tail-this.#head;}
clear(){this.#head=this.#tail=0;this.#full=false;}
push(data){if(data.length>this.available()){return false;}
if(this.#head+data.length>this.#max){let copiedElement=this.#max-this.#head;this.#buffer.set(new Uint8Array(data,0,copiedElement),this.#head);this.#buffer.set(new Uint8Array(data,copiedElement,data.length-copiedElement),0)}else{this.#buffer.set(data,this.#head);}
this.#head=(this.#head+data.length)&this.#max;this.#full=this.#head==this.#tail;return true;}
pop(size){if(size>this.size())
size=this.size();let data;if(this.#tail+size>this.#max){data=new Uint8Array(size);let copiedElement=this.#max-this.#tail;data.copy(new Uint8Array(this.#buffer,this.#tail,copiedElement),0);data.copy(new Uint8Array(this.#buffer,0,size-copiedElement),copiedElement);}else{data=this.#buffer.subarray(this.#tail,this.#tail+size);}
this.#tail=(this.#tail+size)%this.#max;this.#full=false;return data;}}
function Enum(enum_name,...values){const obj=Object.create(null);for(const i of values)
obj[i]=Symbol(`${enum_name}.${i}`);return Object.freeze(obj);}
class InputQueue{#queue=[];#listeners=[];#object_timeout;#get_timeout;constructor(object_timeout,get_timeout){this.#object_timeout=object_timeout;this.#get_timeout=get_timeout;}
get length(){return this.#queue.length;}
clear(){this.#queue.clear();}
put(type,data){const timer=setTimeout(()=>{Array_remove(this.#queue,value);},this.#object_timeout);const value={type,data,timer};this.#queue.push(value);this.#flush();return this.length;}
async get(types){let timed_out=false;let release=()=>{};setTimeout(()=>{timed_out=true;release();},this.#get_timeout);while(!timed_out){const value=this.#getIfMatches(types);if(value)return[value.type,value.data];const e=makeWaiter();release=e.resolve;this.#listeners.push(release);await e.wait;}
throw new TimeoutError();}#getIfMatches(types){for(let i=0;i<this.#queue.length;i++){const value=this.#queue[i];if(types.includes(value.type)){this.#queue.splice(i,1);clearTimeout(value.timer);return value;}}
return undefined;}#flush(){while(this.#listeners.length>0){this.#listeners.shift()();}}}
class EventEmitter{#delegate;constructor(){this.#delegate=document.createDocumentFragment();}
addEventListener(type,callback,options=undefined){this.#delegate.addEventListener(type,callback,options);}
removeEventListener(type,callback,options=undefined){this.#delegate.removeEventListener(type,callback,options);}
dispatchEvent(event){return this.#delegate.dispatchEvent(event);}}
const Modules={UI:(1<<0),INFO:(1<<1),SET:(1<<2),READ:(1<<3),GET:(1<<4),DATA:(1<<5),REBOOT:(1<<6),FILES:(1<<7),FORMAT:(1<<8),DELETE:(1<<9),RENAME:(1<<10),CREATE:(1<<11),FETCH:(1<<12),UPLOAD:(1<<13),OTA:(1<<14),OTA_URL:(1<<15),MQTT:(1<<16),};async function http_get(url,tout){const res=await fetch(url,{signal:AbortSignal.timeout(tout)})
if(!res.ok)
throw new DOMException(res.statusText);return await res.text();}
function http_fetch_blob(url,type,onprogress,tout){return new Promise((res,rej)=>{async function handle(e){if(xhr.response===null)throw new HubError("Network error");if(e.loaded!==e.total||xhr.status!==200){const ab=type==='url'?await readFileAsArrayBuffer(xhr.response):xhr.response;const text=new TextDecoder().decode(ab);throw new HubError(text);}
if(type==='url')return await readFileAsDataUrl(xhr.response);if(type==='text')return new TextDecoder().decode(xhr.response);}
onprogress(0);const xhr=new XMLHttpRequest();xhr.onprogress=(e)=>onprogress(Math.round(e.loaded*100/e.total));xhr.onloadend=(e)=>handle(e).then(res).catch(rej);xhr.ontimeout=()=>rej(new DeviceError(HubErrors.Timeout));xhr.timeout=tout;xhr.responseType=type==='url'?'blob':'arraybuffer';xhr.open('GET',url,true);xhr.send();});}
async function http_post(url,data){const res=await fetch(url,{method:'POST',body:data});if(!res.ok)
throw await res.text();return await res.text();}
function getIPs(ip,netmask){let ip_a=ip.split('.');let sum_ip=(ip_a[0]<<24)|(ip_a[1]<<16)|(ip_a[2]<<8)|ip_a[3];let cidr=Number(netmask);let mask=~(0xffffffff>>>cidr);let network=0,broadcast=0,start_ip=0,end_ip=0;if(cidr===32){network=sum_ip;broadcast=network;start_ip=network;end_ip=network;}else{network=sum_ip&mask;broadcast=network+(~mask);if(cidr===31){start_ip=network;end_ip=broadcast;}else{start_ip=network+1;end_ip=broadcast-1;}}
let ips=['192.168.4.1'];for(let ip=start_ip;ip<=end_ip;ip++){ips.push(`${(ip >>> 24) & 0xff}.${(ip >>> 16) & 0xff}.${(ip >>> 8) & 0xff}.${ip & 0xff}`);}
return ips;}
function sleep(time){return new Promise(res=>setTimeout(res,time));}
function readFileAsArrayBuffer(file){return new Promise((res,rej)=>{let reader=new FileReader();reader.addEventListener('load',e=>{res(reader.result);});reader.addEventListener('error',e=>{rej(reader.error);});reader.readAsArrayBuffer(file);});}
function readFileAsDataUrl(file){return new Promise((res,rej)=>{let reader=new FileReader();reader.addEventListener('load',e=>{res(reader.result);});reader.addEventListener('error',e=>{rej(reader.error);});reader.readAsDataURL(file);});}
function crc32(data){let crc=new Uint32Array(1);crc[0]=0;crc[0]=~crc[0];let str=(typeof(data)=='string');for(let i=0;i<data.length;i++){crc[0]^=str?data[i].charCodeAt(0):data[i];for(let i=0;i<8;i++)crc[0]=(crc[0]&1)?((crc[0]/2)^0x4C11DB7):(crc[0]/2);}
crc[0]=~crc[0];return crc[0];}
function getMime(name){const mime_table={'avi':'video/x-msvideo','bin':'application/octet-stream','bmp':'image/bmp','css':'text/css;charset=utf-8','csv':'text/csv;charset=utf-8','gz':'application/gzip','gif':'image/gif','html':'text/html;charset=utf-8','jpeg':'image/jpeg','jpg':'image/jpeg','js':'text/javascript;charset=utf-8','json':'application/json','png':'image/png','svg':'image/svg+xml;charset=utf-8','txt':'text/plain;charset=utf-8','wav':'audio/wav','xml':'application/xml;charset=utf-8',};let ext=name.split('.').pop();if(ext in mime_table)return mime_table[ext];else return'text/plain';}
function Array_maxBy(arr,fn){return arr.reduce((best,next)=>{const value=fn(next);if(best&&Math.max(best[0],value)==best[0])return best;return[value,next];},null)[1];}
function Array_remove(arr,value){let index;while((index=arr.indexOf(value))!==-1)arr.splice(index,1);}
function isTouchDevice(){return(('ontouchstart'in window)||(navigator.maxTouchPoints>0)||(navigator.msMaxTouchPoints>0));}

const HubCodes=['api_v','id','client','type','update','updates','get','last','crc32','discover','name','prefix','icon','PIN','version','max_upl','http_t','ota_t','ws_port','modules','total','used','code','OK','ack','info','controls','ui','files','notice','alert','push','script','refresh','print','error','fs_err','ota_next','ota_done','ota_err','fetch_start','fetch_chunk','fetch_err','upload_next','upload_done','upload_err','ota_url_err','ota_url_ok','value','maxlen','rows','regex','align','min','max','step','dec','unit','fsize','action','nolabel','suffix','notab','square','disable','hint','len','wwidth','wheight','data','wtype','keep','exp','plugin','js','css','ui_file','stream','port','canvas','width','height','active','html','dummy','menu','gauge','gauge_r','gauge_l','led','log','table','image','text','display','text_f','label','title','dpad','joy','flags','tabs','switch_t','switch_i','button','color','select','spinner','slider','datetime','date','time','confirm','prompt','area','pass','input','hook','row','col','space','platform','map','latlon','location','highacc','layer','udp_port',];
class ConfigChangeEvent extends Event{constructor(type,name,value){super(type);this.name=name;this.value=value;}}
class Config extends EventEmitter{#data;constructor(){super();this.#data={};}
get(...name){const lastName=name.pop();let obj=this.#data;for(const i of name){obj=(i in obj)?obj[i]:{};if(typeof obj!=='object'||!obj)
return;}
return obj[lastName];}
set(...name){const value=name.pop();const lastName=name.pop();let obj=this.#data;for(const i of name){if(!(i in obj)||obj[i]===null)
obj[i]={}
obj=obj[i];if(typeof obj!=='object')
return;}
obj[lastName]=value;name.push(lastName);let path='changed';this.dispatchEvent(new ConfigChangeEvent(path,name,value));for(const i of name){path+='.'+i;this.dispatchEvent(new ConfigChangeEvent(path,name,value));}}
delete(...name){const lastName=name.pop();let obj=this.#data;for(const i of name){if(!(i in obj)||obj[i]===null)
obj[i]={}
obj=obj[i];if(typeof obj!=='object')
return;}
delete obj[lastName];let path='changed';this.dispatchEvent(new ConfigChangeEvent(path,name,undefined));for(const i of name){path+='.'+i;this.dispatchEvent(new ConfigChangeEvent(path,name,undefined));}}
toJson(){return JSON.stringify(this.#data);}
fromJson(data){this.#data=JSON.parse(data);this.#dispatchRecurse(this.#data,'changed');}#dispatchRecurse(obj,path){this.dispatchEvent(new ConfigChangeEvent(path,[],this.#data));if(typeof obj!=='object'||!obj)return;for(const i in obj)if(obj.hasOwnProperty(i)){this.#dispatchRecurse(obj[i],path+'.'+i);}}
createProxy(...names){const self=this;return new Proxy(Object.create(null),{get(t,name,r){return self.get(...names,name);},set(t,name,value,r){self.set(...names,name,value);return true;}});}
getConnection(connName){return this.createProxy('connections',connName);}
getDevice(devId){return this.createProxy('devices',devId);}
get global(){return this.createProxy('hub');}}

const ConnectionState=new Enum('ConnectionState','DISCONNECTED','CONNECTING','CONNECTED',);class ConnectionStateChangeEvent extends Event{constructor(type,connection,state){super(type)
this.connection=connection;this.state=state;}}
class Connection extends EventEmitter{#state;#discovering;#discoverTimer;hub;options;constructor(hub){super();this.#state=ConnectionState.DISCONNECTED;this.#discovering=false;this.#discoverTimer=new AsyncTimer(undefined,()=>{this.#discovering=false;this.hub._checkDiscoverEnd();});this.hub=hub;this.options=this.hub.config.getConnection(this.name);this.options.discover_timeout=3000;}
get name(){return this.constructor.name;}
get priority(){return this.constructor.priority;}
_setState(state){if(this.#state===state)
return;this.#state=state;this.dispatchEvent(new ConnectionStateChangeEvent('statechange',this,state));}
_discoverTimer(){this.#discovering=true;this.#discoverTimer.restart(this.options.discover_timeout);}
isDiscovering(){return this.#discovering;}
getState(){return this.#state;}
isConnected(){return this.options.enabled&&this.#state===ConnectionState.CONNECTED;}
getName(){return null;}
async discover(){if(this.discovering||!this.isConnected())return;this._discoverTimer();for(let pref of this.hub.getAllPrefixes())await this.send(pref);}
async search(){if(this.discovering||!this.isConnected())return;this._discoverTimer();await this.send(this.hub.prefix);}
async add(id){if(this.discovering||!this.isConnected())return;this._discoverTimer();await this.send(this.hub.prefix+'/'+id);}
async begin(){if(this.options.enabled)
await this.connect();}
async connect(){}
async disconnect(){}
async select(){}
async send(data){}
async post(device,command,name='',value=''){let uri=device.info.prefix+'/'+device.info.id+'/'+this.hub.clientId+'/'+command;if(name){uri+='/'+name;if(value){uri+='='+value;}}
await this.send(uri);}}



class HTTPConnection extends Connection{static priority=700;static name='HTTP';constructor(hub){super(hub);this.options.enabled=false;this.options.local_ip='192.168.0.1';this.options.port='80';this.options.netmask='24';this.options.request_timeout=4000;this.options.delay=100;}
isConnected(){return this.options.enabled;}
async discover(){if(this.isDiscovering()||!this.isConnected())return;for(const id of this.hub.getDeviceIds()){const dev=this.hub.dev(id);if(dev.info.ip){this._discoverTimer();try{await this.send(dev.info.ip,dev.info.http_port,`${dev.info.prefix}/${dev.info.id}`);}catch(e){console.log(e);}
this._discoverTimer();await sleep(this.options.delay);}}}
async add(id){}
async discover_ip(ip='',port=undefined){if(this.isDiscovering()||!this.isConnected())return;this._discoverTimer();return await this.send(ip,port,this.hub.prefix);}
async search(){if(this.isDiscovering()||!this.isConnected())return;const ips=getIPs(this.options.local_ip,this.options.netmask);if(!ips)return;let n=0;this._discoverTimer();for(const i of ips){this.#searchInner(i,n++);}}
async#searchInner(ip,n){await sleep(this.options.delay*n);if(!this.isDiscovering())return;this._discoverTimer();try{await this.send(ip,undefined,this.hub.prefix);}catch(e){console.log(e);}}
async post(device,command,name='',value=''){let uri=device.info.prefix+'/'+device.info.id+'/'+this.hub.clientId+'/'+command;if(name){uri+='/'+name;if(value){uri+='='+value;}}
await this.send(device.info.ip,device.info.http_port,uri);}
async send(ip,port,uri){if(!port)port=this.options.port;let res=await http_get(`http://${ip}:${port}/hub/${uri}`,this.options.request_timeout);if(res.length&&res.startsWith('#{')&&res.endsWith('}#')){res=res.slice(2,-2);let chunks=res.split('}##{');for(let ch of chunks){await this.hub._parsePacket(this,'{'+ch+'}',ip,port);}}}};
class WebSocketConnection extends Connection{static priority=800;static name='WS';#ws;#packet_buffer;#reconnect;onConnChange(s){}
constructor(hub){super(hub);this.options.enabled=false;this.options.ip=false;this.options.port=false;this.options.connect_timeout=3300;this.#packet_buffer=new PacketBufferScanFirst(data=>{this.hub._parsePacket(this,data);});}
isConnected(){return this.#ws&&this.#ws.readyState==1;}
async begin(){}
async discover(){}
async search(){}
async connect(){if(this.#ws)return;this._setState(ConnectionState.CONNECTING);this.#reconnect=true;this.#ws=await WebSocketConnection.#wsOpenAsync(`ws://${this.options.ip}:${this.options.port}/`,['hub'],this.options.connect_timeout);this._setState(ConnectionState.CONNECTED);this.#packet_buffer.clear();this.#ws.onclose=async()=>{this._setState(ConnectionState.DISCONNECTED);this.#ws=undefined;await sleep(500);if(this.#reconnect)
await this.connect();};this.#ws.onmessage=(e)=>{this.#packet_buffer.push(e.data);};}
async disconnect(){this._setState(ConnectionState.DISCONNECTED);this.#reconnect=false;if(this.isConnected())
this.#ws.close();}
async send(text){if(this.isConnected())
this.#ws.send(text);}
static#wsOpenAsync(url,protos,timeout){return new Promise((res,rej)=>{const tid=setTimeout(handler,timeout);function handler(e){ws.removeEventListener('open',handler);ws.removeEventListener('error',handler);clearTimeout(tid);if(ws.readyState===WebSocket.OPEN)
res(ws);else rej(e??new TimeoutError());}
const ws=new WebSocket(url,protos);ws.addEventListener('open',handler);ws.addEventListener('error',handler);})}}

class DeviceEvent extends Event{constructor(name,device){super(name);this.device=device;}}
class DeviceCommandEvent extends DeviceEvent{constructor(name,device,cmd,data){super(name,device);this.cmd=cmd;this.data=data;}}
class DeviceUpdateEvent extends DeviceEvent{constructor(device,name,data){super("update",device);this.name=name;this.data=data;}}
class DeviceErrorEvent extends DeviceEvent{constructor(device,error){super("error",device);this.error=error;}}
class DeviceConnectionStatusEvent extends DeviceEvent{constructor(device,status){super("connectionstatus",device);this.status=status;}}
class Device extends EventEmitter{active_connections=[];info;#input_queue;#pingTimer;prev_set={};skip_prd=1000;tout_prd=2500;granted=false;cfg_flag=false;constructor(hub,id){super();this._hub=hub;this.info=hub.config.getDevice(id);this.#input_queue=new InputQueue(1000,1000);this.#pingTimer=new AsyncTimer(3000,async()=>{try{await this.#postAndWait('ping',['OK']);this.dispatchEvent(new DeviceConnectionStatusEvent(this,true));}catch(e){console.log('[PING]',e);this.dispatchEvent(new DeviceConnectionStatusEvent(this,false));}
this.#pingTimer.restart();});}
isModuleEnabled(mod){return!(this.info.modules&mod);}
async#post(cmd,name='',value=''){if(cmd=='set'&&name&&this.isModuleEnabled(Modules.SET)){if(this.prev_set[name])clearTimeout(this.prev_set[name]);this.prev_set[name]=setTimeout(()=>delete this.prev_set[name],this.skip_prd);}
console.log('[OUT]',this.info.id,cmd,name,value);await this.getConnection().post(this,cmd,name,value);}
async#postAndWait(cmd,types,name='',value=''){this.dispatchEvent(new DeviceEvent("transferstart",this));let res;try{await this.#post(cmd,name,value);res=await this.#input_queue.get(types);}catch(e){this.dispatchEvent(new DeviceEvent("transfererror",this));this.dispatchEvent(new DeviceEvent("transferend",this));throw e;}
this.dispatchEvent(new DeviceEvent("transfersuccess",this));this.dispatchEvent(new DeviceEvent("transferend",this));return res;}
async _parse(type,data){this.#input_queue.put(type,data);this.dispatchEvent(new DeviceCommandEvent("command",this,type,data));this.dispatchEvent(new DeviceCommandEvent("command."+type,this,type,data));switch(type){case'ui':await this.#postAndWait('unix',['OK'],Math.floor(new Date().getTime()/1000));break;case'location':if(navigator.geolocation){navigator.geolocation.getCurrentPosition((p)=>this.sendLocation(p),undefined,{enableHighAccuracy:data.highacc});}
break;case'refresh':await this.updateUi();break;case'update':this._checkUpdates(data.updates);break;case'error':this.dispatchEvent(new DeviceErrorEvent(this,new DeviceError(data.code)));}}
isHttpAccessable(){return this.active_connections.some(conn=>conn instanceof HTTPConnection);}
getConnection(){return this.active_connections.length?Array_maxBy(this.active_connections,conn=>conn.priority):null;}
isConnected(){return this.active_connections.length!==0;}
addConnection(conn){if(this.active_connections.includes(conn))return;this.active_connections.push(conn);this.dispatchEvent(new DeviceEvent('connectionchanged',this));conn.addEventListener('statechange',e=>{switch(e.state){case ConnectionState.DISCONNECTED:Array_remove(this.active_connections,conn);this.dispatchEvent(new DeviceEvent('connectionchanged',this));break;}})}
async getInfo(){const[type,data]=await this.#postAndWait('info',['info','OK']);if(type==='info')return data.info;return undefined;}
async reboot(){await this.#postAndWait('reboot',['OK']);}
async sendCli(command){await this.#postAndWait('cli',['OK'],'cli',command);}
sendLocation(p){try{let stamp=Math.round(p.timestamp/1000);let value='';[p.coords.latitude?p.coords.latitude.toFixed(6):0,p.coords.longitude?p.coords.longitude.toFixed(6):0,p.coords.altitude?p.coords.altitude.toFixed(6):0,p.coords.speed?p.coords.speed:0,p.coords.heading?p.coords.heading:0,p.coords.accuracy?p.coords.accuracy:0,].map(v=>value+=v+';');this.#post('location',stamp,value.slice(0,-1));}catch(e){}}
async updateUi(){return(await this.#postAndWait('ui',['ui']))[1];}
async set(name,value){const[cmd,data]=await this.#postAndWait('set',['ui','ack'],name,value);if(cmd==='ui')return data;if(data.name!==name)throw new HubError("set / ack check failed!");return undefined;}
_checkUpdates(updates){if(typeof updates!=='object')
return;for(const[keys,data]of Object.entries(updates)){if(typeof data!=='object')
continue;if('value'in data&&this.prev_set[keys])
delete data.value;if(!Object.keys(data).length)
continue;const names=keys.includes(';')?keys.split(';'):[keys];for(const name of names)
this.dispatchEvent(new DeviceUpdateEvent(this,name,data));}}
async focus(){if(this.info.ws_port&&this._hub._ws&&this.active_connections.some(conn=>conn instanceof HTTPConnection)){const ws=this._hub._ws;await ws.disconnect();ws.options.ip=this.info.ip;ws.options.port=this.info.ws_port;ws.options.enabled=true;await ws.connect();if(!ws.isConnected()){await ws.disconnect();}else{this.addConnection(ws)}}
this.#pingTimer.start();return await this.updateUi();}
async unfocus(){this.#pingTimer.cancel();await this.#post('unfocus');if(this._hub._ws)await this._hub._ws.disconnect();}
async deleteFile(path){return(await this.#postAndWait('delete',['files'],path))[1];}
async createFile(path){return(await this.#postAndWait('mkfile',['files'],path))[1];}
async renameFile(path,new_name){return(await this.#postAndWait('rename',['files'],path,new_name))[1];}
async formatFS(){return(await this.#postAndWait('format',['files']))[1];}
async updateFileList(){return(await this.#postAndWait('files',['files']))[1];}
async fsStop(){if(this.isModuleEnabled(Modules.FETCH)||this.isModuleEnabled(Modules.UPLOAD)||this.isModuleEnabled(Modules.OTA))
await this.#post('fs_abort','all');}
async upload(file,path,progress=undefined){if(!this.isModuleEnabled(Modules.UPLOAD))
throw new DeviceError(HubErrors.Disabled);const data=await readFileAsArrayBuffer(file);const buffer=new Uint8Array(data);const crc=crc32(buffer);if(this.isHttpAccessable()&&this.info.http_t){let formData=new FormData();formData.append('upload',file,"upload");await http_post(`http://${this.info.ip}:${this.info.http_port}/hub/upload?path=${path}&crc32=${crc}&client_id=${this._hub.clientId}&size=${buffer.length}`,formData)}else{if(!progress)progress=()=>{};const upl_bytes=Array.from(buffer);const upl_size=upl_bytes.length;const max_enc_len=this.info.max_upl*3/4-60;let[cmd,data]=await this.#postAndWait('upload',['upload_next','upload_err'],path,upl_size);if(cmd==='upload_next')
[cmd,data]=await this.#postAndWait('upload_chunk',['upload_next','upload_err'],'crc',crc);while(cmd==='upload_next'){const data2=String.fromCharCode.apply(null,upl_bytes.splice(0,max_enc_len));progress(Math.round((upl_size-upl_bytes.length)/upl_size*100));if(upl_bytes.length)
[cmd,data]=await this.#postAndWait('upload_chunk',['upload_next','upload_err'],'next',window.btoa(data2));else
[cmd,data]=await this.#postAndWait('upload_chunk',['upload_done','upload_err'],'last',window.btoa(data2));}
if(cmd==='upload_err')
throw new DeviceError(data.code);}
await this.updateFileList();}
async fetch(path,type,progress=undefined){if(!this.isModuleEnabled(Modules.FETCH))
throw new DeviceError(HubErrors.Disabled);if(!progress)progress=()=>{};if(this.isHttpAccessable()&&this.info.http_t){return await http_fetch_blob(`http://${this.info.ip}:${this.info.http_port}/hub/fetch?path=${path}&client_id=${this._hub.clientId}`,type,progress,this._hub.config.get('connections','HTTP','request_timeout'));}else{let[cmd,data]=await this.#postAndWait('fetch',['fetch_start','fetch_err'],path);let fet_len,fet_buf;if(cmd==='fetch_start'){fet_len=data.len;fet_buf='';[cmd,data]=await this.#postAndWait('fetch_next',['fetch_chunk','fetch_err']);progress(0);}
while(cmd==='fetch_chunk'){fet_buf+=atob(data.data);if(data.last){if(fet_buf.length!=fet_len)
throw new DeviceError(HubErrors.SizeMiss);const crc=crc32(fet_buf);if(crc!=data.crc32)
throw new DeviceError(HubErrors.CrcMiss);if(type==='url')
return`data:${getMime(path)};base64,${btoa(fet_buf)}`;else if(type==='text')
return new TextDecoder().decode(Uint8Array.from(fet_buf,(m)=>m.codePointAt(0)));}
progress(Math.round(fet_buf.length/fet_len*100));[cmd,data]=await this.#postAndWait('fetch_next',['fetch_chunk','fetch_err']);}
if(cmd==='fetch_err')
throw new DeviceError(data.code);}}
async otaUrl(type,url){const[t,data]=await this.#postAndWait('ota_url',['ota_url_ok','ota_url_err'],type,url);if(t==='ota_url_err')
throw new DeviceError(data.code);}
async uploadOta(file,type,progress=undefined){if(!this.isModuleEnabled(Modules.OTA))
throw new DeviceError(HubErrors.Disabled);if(this.isHttpAccessable()&&this.info.http_t){let formData=new FormData();formData.append(type,file,"ota");await http_post(`http://${this.info.ip}:${this.info.http_port}/hub/ota?type=${type}&client_id=${this._hub.clientId}`,formData)}else{if(!progress)progress=()=>{};const fdata=await readFileAsArrayBuffer(file);const buffer=new Uint8Array(fdata);const ota_bytes=Array.from(buffer);const ota_size=ota_bytes.length;const max_enc_len=this.info.max_upl*3/4-60;let[cmd,data]=await this.#postAndWait('ota',['ota_next','ota_done','ota_err'],type);while(cmd==='ota_next'){const data2=String.fromCharCode.apply(null,ota_bytes.splice(0,max_enc_len));progress(Math.round((ota_size-ota_bytes.length)/ota_size*100));[cmd,data]=await this.#postAndWait('ota_chunk',['ota_next','ota_done','ota_err'],(ota_bytes.length)?'next':'last',window.btoa(data2));}
if(cmd==='ota_err')
throw new DeviceError(data.code);}}};
class GyverHub extends EventEmitter{config;#connections=[];#devices=[];_ws;static api_v=2;constructor(){super();this.config=new Config();this.config.set('hub','prefix','MyDevices');this.config.set('hub','client_id',Math.round(Math.random()*0xffffffff).toString(16));}
addConnection(connClass){for(const connection of this.#connections)
if(connection instanceof connClass)
return connection;const conn=new connClass(this);conn.addEventListener('statechange',e=>{this.dispatchEvent(new ConnectionStateChangeEvent('connectionstatechange',e.connection,e.state));this.dispatchEvent(new ConnectionStateChangeEvent('connectionstatechange.'+conn.name,e.connection,e.state));if(conn.isConnected())conn.discover();});this.#connections.push(conn);if(conn.name==='HTTP'){this._ws=this.addConnection(WebSocketConnection);}
return conn;}
get mqtt(){for(const connection of this.#connections){if(connection instanceof MQTTConnection)
return connection;}}
get bt(){for(const connection of this.#connections){if(connection instanceof BLEConnection)
return connection;}}
get serial(){for(const connection of this.#connections){if(connection instanceof SerialConnection)
return connection;}}
get tg(){for(const connection of this.#connections){if(connection instanceof TelegramConnection)
return connection;}}
get http(){for(const connection of this.#connections){if(connection instanceof HTTPConnection)
return connection;}}
get clientId(){return this.config.get('hub','client_id');}
get prefix(){return this.config.get('hub','prefix');}
getAllPrefixes(){const list=[this.prefix];for(const dev_info of Object.values(this.config.get('devices')??{}))
if(dev_info.prefix&&!list.includes(dev_info.prefix))
list.push(dev_info.prefix);return list;}
async begin(){for(const connection of this.#connections){await connection.begin();}}
async discover(){for(let dev of this.#devices){dev.active_connections.length=0;}
for(const connection of this.#connections){connection.discover();}
this._checkDiscoverEnd();}
async search(){for(const connection of this.#connections){connection.search();}
this._checkDiscoverEnd();}
async add(id){for(const connection of this.#connections){connection.add(id);}
this._checkDiscoverEnd();}#isDiscovering(){return this.#connections.some(conn=>conn.isDiscovering());}
_checkDiscoverEnd(){if(!this.#isDiscovering())this.dispatchEvent(new Event('discoverfinished'));}
dev(id){if(!id)return null;for(let d of this.#devices){if(d.info.id==id)return d;}
if(this.config.get('devices',id,'id')===id){const device=new Device(this,id);this.#devices.push(device);this.dispatchEvent(new DeviceEvent('devicecreated',device));return device;}
return null;}
getDeviceIds(){const ids=this.#devices.map(d=>d.info.id);const cfg=this.config.get('devices');if(cfg)
for(const i of Object.keys(cfg))
if(!ids.includes(i))
ids.push(i);return ids;}
addDevice(data,conn=undefined){let device=this.dev(data.id);if(device){let infoChanged=false;for(const key in data){if(device.info[key]!==data[key]){device.info[key]=data[key];infoChanged=true;}}
if(conn)device.addConnection(conn);if(infoChanged)this.dispatchEvent(new DeviceEvent('deviceinfochanged',device));}else{if(!data.prefix)data.prefix=this.prefix;device=new Device(this,data.id);for(const key in data){device.info[key]=data[key];}
if(conn)device.addConnection(conn);this.#devices.push(device);this.dispatchEvent(new DeviceEvent('devicecreated',device));this.dispatchEvent(new DeviceEvent('deviceadded',device));}}
moveDevice(id,dir){if(this.#devices.length==1)return;let idx=0;for(let d of this.#devices){if(d.info.id==id)break;idx++;}
if(dir==1?idx<=this.#devices.length-2:idx>=1){let b=this.#devices[idx];this.#devices[idx]=this.#devices[idx+dir];this.#devices[idx+dir]=b;}}
deleteDevice(id){this.config.delete('devices',id);for(const i in this.#devices){if(this.#devices[i].info.id===id){this.#devices.splice(i,1);return;}}}
async _parsePacket(conn,data,ip=null,port=null){if(!data||!data.length)return;data=data.trim().replaceAll("#{","{").replaceAll("}#","}").replaceAll(/([^\\])\\([^\"\\nrt])/ig,"$1\\\\$2").replaceAll(/\t/ig,"\\t").replaceAll(/\n/ig,"\\n").replaceAll(/\r/ig,"\\r");for(const code in HubCodes){const re=new RegExp(`(#${Number(code).toString(16)})([:,\\]\\}])`,"ig");data=data.replaceAll(re,`"${HubCodes[code]}"$2`);}
const re=/(#[0-9a-f][0-9a-f])([:,\]\}])/ig;if(data.match(re)){this.onHubError('Device has newer API version. Update App!');return;}
try{data=JSON.parse(data);}catch(e){console.log('Wrong packet (JSON): '+e+' in: '+data);return;}
if(!data.id)return this.onHubError('Wrong packet (ID)');if(data.client&&this.clientId!=data.client)return;const type=data.type;delete data.type;if(type=='discover'){if(!this.#isDiscovering()){console.log('Device not added (not discovering):',data);return;}
if(conn instanceof HTTPConnection){data.ip=ip;data.http_port=port;}
this.addDevice(data,conn);}
const device=this.dev(data.id);if(device){console.log('[IN]',type,data);device.addConnection(conn);await device._parse(type,data);}
return device;}};

class Widget{id;type;renderer;data;set_delay=50;set_buf=null;set_timer=null;constructor(data,renderer){this.id=data.id;this.type=data.type;this.data=data;this.renderer=renderer;}
build(){return null;}
update(data){for(const[k,v]of Object.entries(data))
this.data[k]=v;}
_handleSetError(err){}
_handleAck(){}
close(){}
async set(value,ack=true){value=value.toString();if(this.set_timer){this.set_buf=value;}else{this.set_timer=setTimeout(()=>{this.set_timer=null;if(this.set_buf!==null)return this.renderer._set(this,this.set_buf,ack);this.set_buf=null;},this.set_delay);return this.renderer._set(this,value,ack);}}
addFile(path,type,callback){this.renderer._addFile(this,path,type,callback);}
_handleFileProgress(perc){}
_handleFileError(err){}
_handleFileLoaded(res){}}
class BaseWidget extends Widget{#root;#inner;#cont;#hint;#label;#plabel;#suffix;#container;constructor(data,renderer){super(data,renderer);this.#root=makeDOM(this,{tag:'div',class:'widget_main',style:{width:data.wwidth_t+'%',}});this.#inner=makeDOM(this,{tag:'div',class:'widget_inner'});this.#root.append(this.#inner);this.#cont=makeDOM(this,{tag:'div',class:'widget_label'});this.#inner.append(this.#cont);this.#hint=makeDOM(this,{tag:'span',class:'whint',text:'?',style:{display:'none',},also($hint){$hint.addEventListener('click',()=>asyncAlert($hint.title));}});this.#cont.append(this.#hint);this.#label=makeDOM(this,{tag:'span',text:data.type.toUpperCase(),title:this.id,});this.#cont.append(this.#label);this.#plabel=makeDOM(this,{tag:'span',});this.#cont.append(this.#plabel);this.#suffix=makeDOM(this,{tag:'span',class:'wsuffix',});this.#cont.append(this.#suffix);this.#container=makeDOM(this,{tag:'div',class:'widget_body',style:{minHeight:(data.wheight??25)+'px',}});this.#inner.append(this.#container);}
build(){return this.#root;}
makeLayout(...obj){this.#container.replaceChildren(...obj.map(o=>makeDOM(this,o)));}
update(data){super.update(data);if('label'in data){this.#label.textContent=data.label.length?data.label:this.type.toUpperCase();}
if('suffix'in data){this.#suffix.textContent=data.suffix;}
if('nolabel'in data){if(data.nolabel)this.#cont.classList.add('wnolabel');else this.#cont.classList.remove('wnolabel');}
if('square'in data){if(data.square)this.#root.classList.add('wsquare');else this.#root.classList.remove('wsquare');}
if('notab'in data){if(data.notab)this.#inner.classList.add('widget_notab');else this.#inner.classList.remove('widget_notab');}
if('disable'in data){if(data.disable)this.#container.classList.add('widget_dsbl');else this.#container.classList.remove('widget_dsbl');}
if('hint'in data){const htext='name: '+this.id+'\n'+(data.hint??'');this.#label.title=htext;this.#hint.title=htext;this.#hint.style.display=(data.hint&&data.hint.length)?'inline-block':'none';}}
disable(el,disable){if(disable){el.setAttribute('disabled','1');el.classList.add('disable');}else{el.removeAttribute('disabled');el.classList.remove('disable');}}
disabled(){return this.#container.classList.contains('widget_dsbl');}
align(align){this.#container.style.justifyContent=["flex-start","center","flex-end"][Number(align??1)];}
setPlabel(text=null){this.#plabel.textContent=' '+(text??'');}
setSuffix(text=null){this.#suffix.textContent=text??'';}
_handleSetError(err){this.setPlabel("[ERR]");showPopupError(`Widget ${this.id}: `+getError(err));}
_handleAck(){this.setPlabel();}
_handleFileProgress(perc){this.setPlabel(`[${perc}%]`);}
_handleFileError(err){this.setPlabel("[ERR]");showPopupError(`Widget ${this.id}: `+getError(err));}
_handleFileLoaded(){this.setPlabel();}}
function makeDOM(self,obj){if(typeof obj==='string'||obj instanceof Node||!obj.tag)return obj;const $el=document.createElement(obj.tag);for(let[key,value]of Object.entries(obj)){switch(key){case'tag':continue;case'content':$el.replaceChildren(value);break;case'text':$el.textContent=value;break;case'html':$el.innerHTML=value;break;case'class':$el.className=value;break;case'also':value.call(self,$el);break;case'name':self['$'+value]=$el;break;case'style':for(const[skey,sval]of Object.entries(value))$el.style[skey]=sval;break;case'events':for(const[ev,handler]of Object.entries(value))$el.addEventListener(ev,handler.bind(self));break;case'children':for(const i of value)$el.append(makeDOM(self,i));break;default:$el[key]=value;break;}}
return $el;}
function EL(id){return document.getElementById(id);}
function display(id,value){EL(id).style.display=value;}
function addDOM(el_id,tag,text,target){if(EL(el_id))EL(el_id).remove();const el=document.createElement(tag);el.textContent=text;el.id=el_id;target.appendChild(el);return el;}
function waitFrame(){return new Promise(requestAnimationFrame);}
async function wait2Frame(){await waitFrame();await waitFrame();}
async function waitRender(el){while(el===undefined)await waitFrame();}
function getIcon(icon){if(!icon)return'';return icon.length==1?icon:String.fromCharCode(Number('0x'+icon));}
function hexToCol(val,def=null){if(val===null||val===undefined||val=="ffffffff")return def?def:getPrimColor();return"#"+val.padStart(6,'0');}
function intToCol(val){if(val===null||val===undefined)return null;return"#"+Number(val).toString(16).padStart(6,'0');}
function getPrimColor(){return window.getComputedStyle(document.body).getPropertyValue('--prim');}
function colToInt(val){if(val===null||val===undefined)return null;if(val.startsWith('#')){val=val.slice(1);if(val.length==3){val=val[0]+val[0]+val[1]+val[1]+val[2]+val[2];}
return parseInt(val,16);}
if(val.startsWith("rgb(")){let intcol=0;for(const i of val.replace("rgb(","").replace(")","").replace(" ","").split(','))
intcol=(intcol<<8)|i;return intcol;}
return Number(val);}
function dataTotext(data){return b64ToText(data.split('base64,')[1]);}
function b64ToText(base64){const binString=atob(base64);return new TextDecoder().decode(Uint8Array.from(binString,(m)=>m.codePointAt(0)));}
function waiter(size=45,col='var(--prim)',block=true){return`<div class="waiter ${block ? 'waiter_b' : ''}"><span style="font-size:${size}px;color:${col}" class="icon spinning"></span></div>`;}
function noTrust(){return`<div class="blocked_cont"><a href="javascript:void(0)" onclick="notrust_h()" class="blocked">${lang.blocked}</a></div>`;}
async function notrust_h(){if(await asyncConfirm(lang.unblock)){hub.dev(focused).info.trust=1;refresh_h();}}
function adjustColor(col,ratio){let newcol=0;for(let i=0;i<3;i++){let comp=(col&0xff0000)>>16;comp=Math.min(255,Math.floor((comp+1)*ratio));newcol<<=8;newcol|=comp;col<<=8;}
return newcol;}
let GlobalWidgets=new Map();class Renderer extends EventEmitter{#WIDGETS;static#VIRTUAL_WIDGETS=new Set();static register(cls,widgets=GlobalWidgets){widgets.set(cls.wtype,cls);if(cls.virtual)Renderer.#VIRTUAL_WIDGETS.add(cls.wtype);if(cls.style)addDOM(cls.wtype+'_style','style',cls.style,EL('widget_styles'));}
static registerPlugin(js,widgets=GlobalWidgets){let cls=js.match(/class\s+(\w+)\s+extends/);if(!cls||cls.length<2)return null;cls=cls[1];let wtype=js.match(/static wtype\s+=\s+'(\w+)'/);if(!wtype||wtype.length<2)return null;wtype=wtype[1];try{const f=new Function('return ('+js+');');Renderer.register(f(),widgets);}catch(e){return null;}
return wtype;}
device;#widgets;#idMap;#idMapExt;#files;#filesLoaded;constructor(device,widgets=GlobalWidgets){super();this.#WIDGETS=widgets;this.device=device;this.#widgets=[];this.#idMap=new Map();this.#idMapExt=new Map();this.#files=[];this.#filesLoaded=false;}
update(controls){this.close();this.#widgets.length=0;this.#idMap.clear();this.#idMapExt.clear();this.#files.length=0;this.#filesLoaded=false;this._makeWidgets(this.#widgets,'col',controls);this.#filesLoaded=true;this.#loadFiles();}#updateWWidth(type,data){switch(type){case'row':let sumw=0;for(const ctrl of data){if(!ctrl.type||Renderer.#VIRTUAL_WIDGETS.has(ctrl.type))continue;if(!ctrl.wwidth)ctrl.wwidth=1;sumw+=ctrl.wwidth;}
for(const ctrl of data){if(!ctrl.type||Renderer.#VIRTUAL_WIDGETS.has(ctrl.type))continue;ctrl.wwidth_t=ctrl.wwidth*100/sumw;}
break;case'col':for(const ctrl of data){if(!ctrl.type||Renderer.#VIRTUAL_WIDGETS.has(ctrl.type))continue;ctrl.wwidth_t=100;}
break;}}
_makeWidgets(cont,type,data,isExt=false){this.#updateWWidth(type,data);const idMap=isExt?this.#idMapExt:this.#idMap;for(const ctrl of data){if(!ctrl.type)continue;let cls=this.#WIDGETS.get(ctrl.type);if(cls===undefined){console.log('W: Missing widget:',ctrl);cls=this.#WIDGETS.get('load');}
const obj=new cls(ctrl,this);idMap.set(obj.id,obj)
cont.push(obj);}}
async _set(widget,value,ack=true){try{await this.device.set(widget.id,value);}catch(e){console.log(e);if(ack)widget._handleSetError(e);}
if(ack)widget._handleAck();}
build(){const res=[];for(const w of this.#widgets){const $w=w.build();if($w)res.push($w);}
return res;}
close(){for(const w of this.#idMap.values()){w.close();}}
handleUpdate(id,data){const w=this.#idMap.get(id);if(w)w.update(data);}
_addFile(widget,path,type,callback){let has=this.#files.some(f=>f.widget.id==widget.id);if(!has)this.#files.push({widget,path,type,callback});this.#loadFiles();}
async#loadFiles(){if(!this.#filesLoaded)return;while(this.#files.length){const file=this.#files.shift();let res;try{res=await this.device.fetch(file.path,file.type,file.widget._handleFileProgress.bind(file.widget));}catch(e){console.log(e);file.widget._handleFileError(e);continue;}
file.widget._handleFileLoaded(res);file.callback(res);}}
_getPlugin(type){return this.#WIDGETS.get(type);}}
function registerWidgets(){GlobalWidgets=new Map();[ButtonWidget,CanvasWidget,ColorWidget,DateWidget,TimeWidget,DateTimeWidget,DpadWidget,FlagsWidget,GaugeWidget,GaugeRWidget,GaugeLWidget,HTMLWidget,ImageWidget,IconWidget,InputWidget,PassWidget,JoyWidget,LabelWidget,LedWidget,MapWidget,MenuWidget,PlotWidget,PluginLoader,LoadWidget,ConfirmWidget,PromptWidget,RowWidget,ColWidget,SelectWidget,SliderWidget,SpinnerWidget,StreamWidget,SwitchWidget,SwitchIconWidget,TableWidget,TabsWidget,TextWidget,LogWidget,TextFileWidget,DisplayWidget,AreaWidget,TitleWidget,SpaceWidget,DummyWidget,].forEach(cls=>Renderer.register(cls,GlobalWidgets));if(localStorage.hasOwnProperty('plugins')){let plugins=JSON.parse(localStorage.getItem('plugins'));for(let plug in plugins)
Renderer.registerPlugin(plugins[plug],GlobalWidgets);}}
function makeDialog(title,text,buttons,additional=[]){const $box=document.createElement('div');$box.className='dialog_box';const $d=document.createElement('div');$box.append($d);$d.className='ui_col ui_dialog';if(title){const $title=document.createElement('div');$d.append($title);$title.className='ui_row ui_head';$title.textContent=title;}
if(text){const $text=document.createElement('div');$d.append($text);$text.className='ui_row';const $label=document.createElement('label');$text.append($label);$label.className='dialog_row';$label.textContent=text;}
for(add of additional){const $add=document.createElement('div');$d.append($add);$add.className='ui_row';$add.append(add);}
if(buttons){const $buttons=document.createElement('div');$d.append($buttons);$buttons.className='ui_row';$buttons.append(document.createElement('div'));const $row=document.createElement('div');$buttons.append($row);$row.className='ui_btn_row';for(const i of buttons){const $btn=document.createElement('button');$row.append($btn);$btn.className='ui_btn ui_btn_mini';$btn.textContent=i.text;$btn.addEventListener('click',i.click);}}
document.body.appendChild($box);return $box;}
function asyncShowQr($qr,title=null){return new Promise(resolve=>{const $box=makeDialog(title,null,[{text:'OK',click:()=>{document.body.removeChild($box);resolve(true);}}],[$qr]);});}
function asyncAlert(text,title=null){return new Promise(resolve=>{const $box=makeDialog(title,text,[{text:'OK',click:()=>{document.body.removeChild($box);resolve(true);}}]);});}
function asyncConfirm(text,title=null){return new Promise(resolve=>{const $box=makeDialog(title,text,[{text:lang.pop_yes,click:()=>{document.body.removeChild($box);resolve(true);}},{text:lang.pop_no,click:()=>{document.body.removeChild($box);resolve(false);}}]);});}
function asyncPrompt(text,placeh='',title=null){return new Promise(resolve=>{const $input=document.createElement('input');$input.type='text';$input.value=placeh;$input.className='ui_inp';const $box=makeDialog(title,text,[{text:'OK',click:()=>{const res=$input.value;document.body.removeChild($box);resolve(res);}},{text:lang.cancel,click:()=>{document.body.removeChild($box);resolve(null);}}],[$input]);});}
function asyncPromptArea(text,placeh='',title=null){return new Promise(resolve=>{const $input=document.createElement('textarea');$input.rows=5;$input.value=placeh;$input.className='ui_inp ui_area ui_area_wrap';const $box=makeDialog(title,text,[{text:'OK',click:()=>{const res=$input.value;document.body.removeChild($box);resolve(res);}},{text:lang.cancel,click:()=>{document.body.removeChild($box);resolve(null);}}],[$input]);$box.firstElementChild.style.maxWidth="900px";});}
function makePinDialog(title,canCancel,inputHandler){const $box=document.createElement('div');$box.className='dialog_box';const $d=document.createElement('div');$box.append($d);$d.className='ui_col ui_dialog';const $title=document.createElement('div');$d.append($title);$title.className='ui_row ui_head';$title.textContent=title;const $inpRow=document.createElement('div');$d.append($inpRow);$inpRow.className='ui_row pass_inp_inner';const $input=document.createElement('input');$inpRow.append($input);$input.className='ui_inp pass_inp';$input.type='number';$input.pattern='[0-9]*';$input.inputMode='numeric';$d.addEventListener('click',e=>{const $b=e.target;if(!($b instanceof HTMLButtonElement))return;if($b.classList.contains('pin_cancel')){inputHandler(null);return;}
if($b.textContent==='<')$input.value=$input.value.slice(0,-1);else $input.value+=$b.textContent;inputHandler($input.value);})
$input.addEventListener('input',()=>{inputHandler($input.value);});for(let i=0;i<3;i++){const $row=document.createElement('div');$d.append($row);$row.className='ui_row pin_inner';for(let j=0;j<3;j++){const $b=document.createElement('button');$row.append($b);$b.className='ui_btn pin_btn';$b.textContent=""+(i*3+j+1);}}
const $row=document.createElement('div');$d.append($row);$row.className='ui_row pin_inner';{const $b=document.createElement('button');$row.append($b);if(canCancel){$b.className='ui_btn pin_btn pin_cancel';$b.textContent=lang.cancel;}else{$b.className='ui_btn pin_btn pin_no_btn';}}
{const $b=document.createElement('button');$row.append($b);$b.className='ui_btn pin_btn';$b.textContent="0";}
{const $b=document.createElement('button');$row.append($b);$b.className='ui_btn pin_btn pin_red_btn';$b.textContent="<";}
document.body.appendChild($box);return $box;}
function asyncAskPin(title,targetPin,canCancel=false){return new Promise(resolve=>{const $box=makePinDialog(title,canCancel,value=>{if(value===null||value.hashCode()==targetPin){document.body.removeChild($box);resolve(value!==null);}});});}
function showPopup(text,color='#37a93c'){const $e=document.createElement('div');$e.className='notice';$e.textContent=text;$e.style.background=color;document.body.append($e);setTimeout(()=>{$e.remove();},3500);}
function showPopupError(text){showPopup(text,'#a93737');}

class ButtonWidget extends BaseWidget{static wtype='button';$el;#color='var(--prim)';#fontSize='45px';#inline=true;#pressed=false;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'button',class:'icon w_btn',name:'el',text:"",style:{color:this.#color,fill:this.#color,fontSize:this.#fontSize,width:'unset',},events:{click:()=>{},mousedown:()=>{this.#pressed=true;if(!isTouchDevice())this.set(1);},mouseup:()=>{if(!isTouchDevice()&&this.#pressed)this.set(0);this.#pressed=false;},mouseleave:()=>{if(!isTouchDevice()&&this.#pressed)this.set(0);this.#pressed=false;},touchstart:()=>{this.#pressed=true;this.set(1);},touchend:()=>{this.#pressed=false;this.set(0);},},});this.update(data);}
update(data){super.update(data);if('icon'in data){this.#setIcon(data.icon);}
if('color'in data){this.#color=hexToCol(data.color);this.$el.style.color=this.#color;this.$el.style.fill=this.#color;}
if('fsize'in data){this.#fontSize=data.fsize+'px';const size=this.#fontSize;this.$el.style.fontSize=size;this.$el.style.width=this.#inline?'unset':size;}
if('disable'in data){this.disable(this.$el,data.disable);}}#setIcon(text){let icon="";this.$el.style.width='unset';if(text){if(text.includes(".svg")){this.addFile(text,'text',(data)=>{this.$el.innerHTML=data;this.$el.style.width=this.#fontSize;this.$el.style.fill=this.#color;});this.#inline=false;return;}else{icon=getIcon(text);}}
this.$el.innerHTML=icon;this.#inline=true;}
static style=`
.w_btn {
cursor: pointer;
margin: -3px;
}
.w_btn:hover {
filter: brightness(1.15);
}
.w_btn:active {
filter: brightness(0.7);
}`;}
const canvas_const=['MITER','ROUND','BEVEL','SQUARE','PROJECT','CORNER','CORNERS','CENTER','RADIUS','LEFT','RIGHT','TOP','BOTTOM','BASELINE'];const canvas_cmd=['clear','background','fill','noFill','stroke','noStroke','strokeWeight','strokeJoin','strokeCap','rectMode','ellipseMode','imageMode','image','textFont','textSize','textAlign','text','point','line','rect','arc','ellipse','circle','bezier','beginShape','endShape','vertex','bezierVertex','pixelScale','rotate','translate','push','pop'];function showCanvasAPI(cv,data,scale,mapxy,fileHandler){function radians(deg){return deg*0.01745329251;}
const cx=cv.getContext("2d");let _scale=scale;let _fillF=1;let _strokeF=1;let _shapeF=0;let _elMode='CENTER';let _recMode='CORNER';let _imgMode='CORNER';function apply(){if(_fillF)cx.fill();if(_strokeF)cx.stroke();}
function drawEllipse(args){cx.beginPath();let xy=mapxy(args[0],args[1]);let wh=[args[2]*_scale/2,args[3]*_scale/2];switch(_elMode){case'CENTER':break;case'RADIUS':wh=[wh[0]*2,wh[1]*2];break;case'CORNER':xy=[xy[0]+wh[0],xy[1]+wh[1]];break;case'CORNERS':let xy2=mapxy(args[2],args[3]);wh=[(xy2[0]-xy[0])/2,(xy2[1]-xy[1])/2];xy=[xy[0]+wh[0],xy[1]+wh[1]];break;}
cx.ellipse(xy[0],xy[1],wh[0],wh[1],0,0,2*Math.PI);apply();}
for(let i in data){i=Number(i);const item=data[i];if(item.match(/^\d+$/)){let cmd=canvas_cmd[Number(item)];switch(cmd){case'clear':cx.clearRect(0,0,cv.width,cv.height);break;case'noFill':_fillF=0;break;case'noStroke':_strokeF=0;break;case'beginShape':_shapeF=1;cx.beginPath();break;case'push':cx.save();break;case'pop':cx.restore();break;}}else if(item.match(/^\d+:.+/)){let colon=item.indexOf(':');let cmd=canvas_cmd[Number(item.slice(0,colon))];let args=item.slice(colon+1,item.length).split(',').map(v=>{if(v.match(/^[0-9a-f]+$/))return parseInt(v,16)|0;else if(v.match(/^#[0-9a-f]+$/))return'#'+v.substring(1).padStart(8,'0');else return v;});switch(cmd){case'pixelScale':_scale=args[0]?1:scale;break;case'background':let b=cx.fillStyle;cx.fillStyle=args[0];cx.fillRect(0,0,cv.width,cv.height);cx.fillStyle=b;break;case'fill':_fillF=1;cx.fillStyle=args[0];break;case'stroke':_strokeF=1;cx.strokeStyle=args[0];break;case'strokeWeight':cx.lineWidth=args[0]*_scale;break;case'strokeJoin':switch(canvas_const[args[0]]){case'MITER':cx.lineJoin="miter";break;case'BEVEL':cx.lineJoin="bevel";break;case'ROUND':cx.lineJoin="round";break;}
break;case'strokeCap':switch(canvas_const[args[0]]){case'ROUND':cx.lineCap="round";break;case'SQUARE':cx.lineCap="butt";break;case'PROJECT':cx.lineCap="square";break;}
break;case'rectMode':_recMode=canvas_const[args[0]];break;case'ellipseMode':_elMode=canvas_const[args[0]];break;case'imageMode':_imgMode=canvas_const[args[0]];break;case'image':let img=new Image();let path=args.shift();if(path.startsWith('http://')||path.startsWith('https://')){img.src=path;}else{if(fileHandler)fileHandler(path,img);}
img.onload=()=>{let pos=[...args];if(pos.length==3)pos[3]=pos[2]*img.height/img.width;if(pos.length==2){switch(_imgMode){case'CORNERS':case'CORNER':cx.drawImage(img,...mapxy(pos[0],pos[1]));break;case'CENTER':cx.drawImage(img,mapxy(pos[0],pos[1])[0]-img.width/2,mapxy(pos[0],pos[1])[1]-img.height/2);break;}}else{switch(_imgMode){case'CORNER':pos=[...mapxy(pos[0],pos[1]),pos[2]*_scale,pos[3]*_scale];break;case'CORNERS':let pos2=mapxy(args[2],args[3]);pos=[mapxy(pos[0],pos[1])];pos.concat([pos2[0]-pos[0],pos2[1]-pos[1]]);break;case'CENTER':pos=[...mapxy(pos[0],pos[1]),pos[2]*_scale,pos[3]*_scale];pos[0]-=pos[2]/2;pos[1]-=pos[3]/2;break;}
cx.drawImage(img,...pos);}
if(i+1<data.length)showCanvasAPI(cv,data.slice(i+1),scale,mapxy,fileHandler);}
return;case'textFont':cx.font=cx.font.split('px ')[0]+'px '+args[0];break;case'textSize':cx.font=args[0]*_scale+'px '+cx.font.split('px ')[1];break;case'textAlign':switch(canvas_const[args[0]]){case'LEFT':cx.textAlign='left';break;case'CENTER':cx.textAlign='center';break;case'RIGHT':cx.textAlign='right';break;}
switch(canvas_const[args[1]]){case'BASELINE':cx.textBaseline='alphabetic';break;case'TOP':cx.textBaseline='top';break;case'BOTTOM':cx.textBaseline='bottom';break;case'CENTER':cx.textBaseline='middle';break;}
break;case'text':if(_fillF)cx.fillText(args[0],...mapxy(args[1],args[2]));if(_strokeF)cx.strokeText(args[0],...mapxy(args[1],args[2]));break;case'point':cx.beginPath();cx.fillRect(...mapxy(args[0],args[1]),_scale,_scale);break;case'line':cx.beginPath();cx.moveTo(...mapxy(args[0],args[1]));cx.lineTo(...mapxy(args[2],args[3]));if(_strokeF)cx.stroke();break;case'rect':cx.beginPath();let xy=mapxy(args[0],args[1]);let wh=[args[2]*_scale,args[3]*_scale];switch(_recMode){case'CENTER':xy=[xy[0]-wh[0]/2,xy[1]-wh[1]/2];break;case'RADIUS':xy=[xy[0]-wh[0],xy[1]-wh[1]];wh=[wh[0]*2,wh[1]*2];break;case'CORNER':break;case'CORNERS':let xy2=mapxy(args[2],args[3]);wh=[xy2[0]-xy[0],xy2[1]-xy[1]];break;}
if(args[4]){let r=[args[4]*_scale];if(args[5])r=r.concat([args[5]*_scale,args[6]*_scale,args[7]*_scale]);cx.roundRect(xy[0],xy[1],wh[0],wh[1],r);apply();}else{if(_fillF)cx.fillRect(xy[0],xy[1],wh[0],wh[1]);if(_strokeF)cx.strokeRect(xy[0],xy[1],wh[0],wh[1]);}
break;case'arc':cx.beginPath();cx.ellipse(...mapxy(args[0],args[1]),args[2]*_scale,args[3]*_scale,0,radians(args[4]),radians(args[5]));apply();break;case'ellipse':drawEllipse(args);break;case'circle':drawEllipse([args[0],args[1],args[2],args[2]]);break;case'bezier':if(_strokeF){args=[...mapxy(args[0],args[1]),...mapxy(args[2],args[3]),...mapxy(args[4],args[5]),...mapxy(args[6],args[7])];cx.beginPath();cx.moveTo(args[0],args[1]);cx.bezierCurveTo(args[2],args[3],args[4],args[5],args[6],args[7]);cx.stroke();}
break;case'endShape':if(args[0])cx.closePath();apply();break;case'vertex':if(_shapeF){_shapeF=0;cx.moveTo(...mapxy(args[0],args[1]));}else{cx.lineTo(...mapxy(args[0],args[1]));}
break;case'bezierVertex':if(_shapeF){_shapeF=0;cx.moveTo(...mapxy(args[4],args[5]));}
cx.bezierCurveTo(...mapxy(args[0],args[1]),...mapxy(args[2],args[3]),...mapxy(args[4],args[5]));break;case'rotate':cx.rotate(radians(args[0]));break;case'translate':cx.translate(...mapxy(args[0],args[1]));break;}}else{try{eval(item);}catch(e){console.log(e);}}}}
class CanvasWidget extends BaseWidget{static wtype='canvas';$el;cvdata=[];#scale=1;#resize_h;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'div',class:'w_canvas',children:[{tag:'canvas',name:'el',events:{click:e=>this.#click(e)}}]});this.#resize();this.#resize_h=this.#resize.bind(this);window.addEventListener('resize',this.#resize_h);wait2Frame().then(()=>{this.#resize();});this.update(data);this.disable(this.$el,data.disable);}
update(data){super.update(data);if('active'in data)this.$el.style.cursor=data.active?'pointer':'';if('data'in data){this.cvdata=this.cvdata.concat(data.data);this.#show(data.data);}}
close(){window.removeEventListener('resize',this.#resize_h);}#click(e){if(!this.data.active)return;const rect=this.$el.getBoundingClientRect();const ratio=window.devicePixelRatio;let x=Math.round((e.clientX-rect.left)/this.#scale*ratio);if(x<0)x=0;let y=Math.round((e.clientY-rect.top)/this.#scale*ratio);if(y<0)y=0;this.set(x+';'+y);this.setSuffix('['+x+','+y+']');}#resize(){const rw=this.$el.parentNode.clientWidth;if(!rw)return;const scale=rw/this.data.width;const ratio=window.devicePixelRatio;this.#scale=scale*ratio;const rh=Math.floor(this.data.height*scale);this.$el.style.width=rw+'px';this.$el.style.height=rh+'px';this.$el.width=Math.floor(rw*ratio);this.$el.height=Math.floor(rh*ratio);this.#show(this.cvdata);}#show(data){if(!this.$el.parentNode.clientWidth)return;const cv=this.$el;showCanvasAPI(cv,data,this.#scale,(x,y)=>{x*=this.#scale;y*=this.#scale;if(x<0)x=cv.width-x;if(y<0)y=cv.height-y;return[x,y];},(path,img)=>{this.addFile(path,'url',(file)=>{img.src=file;});});}
static style=`
.w_canvas {
border-radius: 4px;
width: 100%;
height: 100%;
overflow: hidden;
margin-bottom: -5px;
}`;}
class ColorWidget extends BaseWidget{static wtype='color';$el;#pickr;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'button',class:'icon icon_btn_big',name:'el',text:'',style:{color:'#000'}});waitRender(this.$el).then(()=>{this.#pickr=Pickr.create({el:this.$el,theme:'nano',default:data.value?intToCol(data.value):'#000',defaultRepresentation:'HEXA',useAsButton:true,components:{preview:true,hue:true,interaction:{hex:false,input:true,save:true}}}).on('save',(color)=>{const col=color.toHEXA().toString();this.$el.style.color=col;this.set(colToInt(col));this.#pickr.hide();});this.update(data);});}
update(data){super.update(data);let col=null;if('value'in data)col=intToCol(data.value)??'#000';if('disable'in data)this.disable(this.$el,data.disable);if(col){try{this.$el.style.color=col;this.#pickr.setColor(col);}catch(e){}}}
close(){this.#pickr.destroyAndRemove();}}
function colToInt(str){return parseInt(str.substr(1),16);}
class DateWidget extends BaseWidget{static wtype='date';$el;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'input',class:'w_date',name:'el',type:'date',style:{color:'var(--prim)'},events:{click:()=>{this.$el.showPicker();},change:()=>{this.set(getUnix(this.$el));},},});this.update(data);}
update(data){super.update(data);if('value'in data)this.$el.value=new Date(data.value*1000).toISOString().split('T')[0];if('color'in data)this.$el.style.color=hexToCol(data.color);}}
class TimeWidget extends BaseWidget{static wtype='time';$el;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'input',class:'w_date',name:'el',type:'time',step:1,style:{color:'var(--prim)'},events:{click:()=>{this.$el.showPicker();},change:()=>{this.set(getUnix(this.$el));},},});this.update(data);}
update(data){super.update(data);if('value'in data)this.$el.value=new Date(data.value*1000).toISOString().split('T')[1].split('.')[0];if('color'in data)this.$el.style.color=hexToCol(data.color);}}
class DateTimeWidget extends BaseWidget{static wtype='datetime';$el;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'input',class:'w_date',name:'el',type:'datetime-local',step:1,style:{color:'var(--prim)'},events:{click:()=>{this.$el.showPicker();},change:()=>{this.set(getUnix(this.$el));},},});this.update(data);}
update(data){super.update(data);if('value'in data)this.$el.value=new Date(data.value*1000).toISOString().split('.')[0];if('color'in data)this.$el.style.color=hexToCol(data.color);}
static style=`
.w_date {
border: none;
outline: none;
font-family: var(--font_f);
cursor: pointer;
background: none;
font-size: 20px;
padding: 0;
}
.w_date::-webkit-calendar-picker-indicator {
display: none;
-webkit-appearance: none;
}`;}
function getUnix(arg){return Math.floor(arg.valueAsNumber/1000);}
class DpadWidget extends BaseWidget{static wtype='dpad';$el;#posX=0;#posY=0;#pressed=false;#_onTouchStart;#_onTouchEnd;#_onMouseDown;#_onMouseUp;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'canvas',name:'el'});this.data.color=colToInt(hexToCol(this.data.color));if("ontouchstart"in document.documentElement){this.#_onTouchStart=this.#onTouchStart.bind(this);this.#_onTouchEnd=this.#onTouchEnd.bind(this);this.$el.addEventListener("touchstart",this.#_onTouchStart);document.addEventListener("touchend",this.#_onTouchEnd);}else{this.#_onMouseDown=this.#onMouseDown.bind(this);this.#_onMouseUp=this.#onMouseUp.bind(this);this.$el.addEventListener("mousedown",this.#_onMouseDown);document.addEventListener("mouseup",this.#_onMouseUp);}
this.$el.parentNode.addEventListener('resize',()=>{this.#redraw();})
this.update(data);this.disable(this.$el,data.disable);waitFrame().then(()=>{this.#redraw(false);});}
close(){if("ontouchstart"in document.documentElement){this.$el.removeEventListener("touchstart",this.#_onTouchStart);document.removeEventListener("touchend",this.#_onTouchEnd);}else{this.$el.removeEventListener("mousedown",this.#_onMouseDown);document.removeEventListener("mouseup",this.#_onMouseUp);}}#redraw(send=true){const cv=this.$el;let size=cv.parentNode.clientWidth;if(!size)return;cv.style.width=size+'px';cv.style.height=size+'px';size*=window.devicePixelRatio;const center=size/2;cv.width=size;cv.height=size;cv.style.cursor='pointer';let x=0;let y=0;if(this.#pressed){x=Math.round((this.#posX-center)/center*255);y=-Math.round((this.#posY-center)/center*255);if(Math.abs(x)<50&&Math.abs(y)<50){x=0;y=0;}else{if(Math.abs(x)>Math.abs(y)){x=Math.sign(x);y=0;}else{x=0;y=Math.sign(y);}}}
const cx=cv.getContext("2d");cx.clearRect(0,0,size,size);cx.beginPath();cx.arc(center,center,size*0.44,0,2*Math.PI,false);cx.lineWidth=size*0.02;cx.strokeStyle=intToCol(this.#pressed?adjustColor(this.data.color,1.3):this.data.color);cx.stroke();cx.lineWidth=size*0.045;const rr=size*0.36;const cw=size*0.1;const ch=rr-cw;const sh=[[1,0],[-1,0],[0,1],[0,-1]];for(let i=0;i<4;i++){cx.beginPath();cx.strokeStyle=intToCol((x==sh[i][0]&&y==-sh[i][1])?adjustColor(this.data.color,1.3):this.data.color);cx.moveTo(center+ch*sh[i][0]-cw*sh[i][1],center+ch*sh[i][1]-cw*sh[i][0]);cx.lineTo(center+rr*sh[i][0],center+rr*sh[i][1]);cx.lineTo(center+ch*sh[i][0]+cw*sh[i][1],center+ch*sh[i][1]+cw*sh[i][0]);cx.stroke();}
if(send)this.set(x+';'+y);}#onTouchStart(event){if(this.data.disable)return;event.preventDefault();this.#pressed=true;const ratio=window.devicePixelRatio;this.#posX=(event.targetTouches[0].pageX-this.$el.offsetLeft)*ratio;this.#posY=(event.targetTouches[0].pageY-this.$el.offsetTop)*ratio;this.#redraw();}#onMouseDown(event){if(this.data.disable)return;this.#pressed=true;const ratio=window.devicePixelRatio;this.#posX=(event.pageX-this.$el.offsetLeft)*ratio;this.#posY=(event.pageY-this.$el.offsetTop)*ratio;this.#redraw();}#onTouchEnd(){if(this.#pressed){this.#pressed=false;this.#redraw();}}#onMouseUp(){if(this.#pressed){this.#pressed=false;this.#redraw();}}}
class FlagsWidget extends BaseWidget{static wtype='flags';$el;#value=0;#items=[];constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'div',class:'w_flags_cont',name:'el',events:{click:e=>{if(this.$el.getAttribute("disabled"))return;const i=e.target.dataset.flagIndex;if(i===undefined)return;const unset=e.target.classList.contains('checked');if(unset)this.#value&=~(1<<i);else this.#value|=1<<i;this.set(this.#value);this.#render();}}});this.disable(this.$el,data.disable);this.update(data);}
update(data){super.update(data);if('value'in data)this.#value=Number(data.value);if('text'in data)this.#items=data.text.split(/[,;]/);if('color'in data)this.$el.style.setProperty('--checked-color',hexToCol(data.color));if('disable'in data)this.disable(this.$el,data.disable);this.#render();}#render(){const labels=[];let val=this.#value;for(const i in this.#items){const $i=makeDOM(null,{tag:'label',class:'w_flags'+(val&1?' checked':''),text:this.#items[i],});$i.dataset.flagIndex=i;labels.push($i);val>>=1;}
this.$el.replaceChildren(...labels);}
static style=`
.w_flags {
padding: 4px 13px;
margin: 3px;
border-radius: 35px;
background: var(--dark);
font-size: 18px;
color: var(--font);
user-select: none;
--checked-color: var(--prim);
}
.w_flags_cont:not(.disable) .w_flags {
cursor: pointer;
}
.w_flags_cont:not(.disable) .w_flags:hover {
background: var(--black);
}
.w_flags.checked {
background: var(--checked-color) !important;
color: white;
}
.w_flags_cont {
display: flex;
flex-wrap: wrap;
justify-content: center;
}`;}
class GaugeBaseWidget extends BaseWidget{static OUT_OF_RANGE_COLOR='#8e1414';$el;#redraw;#cstyle;constructor(data,renderer){super(data,renderer);this.perc=null;this.value=0;this.min=0;this.max=100;this.dec=0;this.unit='';this.icon='';this.tout=null;switch(this.type){case'gauge':this.#redraw=this.#redrawGauge;break;case'gauge_l':this.#redraw=this.#redrawGaugeL;break;case'gauge_r':this.#redraw=this.#redrawGaugeR;break;}
this.makeLayout({tag:'canvas',name:'el',events:{resize:()=>this.#redraw()}});this.#cstyle=window.getComputedStyle(this.$el);this.update(data);wait2Frame().then(()=>this.#redraw());}
close(){if(this.tout)clearTimeout(this.tout);this.tout=null;}
update(data){super.update(data);if('value'in data)this.value=Number(data.value);if('min'in data)this.min=Number(data.min);if('max'in data)this.max=Number(data.max);if('dec'in data)this.dec=Number(data.dec);if('unit'in data)this.unit=data.unit;if('icon'in data)this.icon=data.icon;this.#redraw();}#redrawGauge(){this.color=hexToCol(this.data.color);let cv=this.$el;let rw=cv.parentNode.clientWidth;if(!rw)return;const ratio=window.devicePixelRatio;let rh=Math.floor(rw*0.47);cv.style.width=rw+'px';cv.style.height=rh+'px';cv.width=Math.floor(rw*ratio);cv.height=Math.floor(rh*ratio);let cx=cv.getContext("2d");let perc=(this.value-this.min)*100/(this.max-this.min);if(perc<0)perc=0;if(perc>100)perc=100;if(this.perc==null)this.perc=perc;else{if(Math.abs(this.perc-perc)<=0.15)this.perc=perc;else this.perc+=(perc-this.perc)*0.15;if(this.perc!=perc)setTimeout(()=>this.#redraw(),20);}
cx.clearRect(0,0,cv.width,cv.height);cx.lineWidth=cv.width/8;cx.strokeStyle=this.#cstyle.getPropertyValue('--dark');cx.beginPath();cx.arc(cv.width/2,cv.height*0.97,cv.width/2-cx.lineWidth,Math.PI*(1+this.perc/100),Math.PI*2);cx.stroke();cx.strokeStyle=this.color;cx.beginPath();cx.arc(cv.width/2,cv.height*0.97,cv.width/2-cx.lineWidth,Math.PI,Math.PI*(1+this.perc/100));cx.stroke();let font=this.#cstyle.fontFamily;cx.fillStyle=this.color;cx.font='10px '+font;cx.textAlign="center";let text=this.unit;let len=Math.max((this.value.toFixed(this.dec)+text).length,(this.min.toFixed(this.dec)+text).length,(this.max.toFixed(this.dec)+text).length);if(len==1)text+='  ';else if(len==2)text+=' ';let w=Math.max(cx.measureText(this.value.toFixed(this.dec)+text).width,cx.measureText(this.min.toFixed(this.dec)+text).width,cx.measureText(this.max.toFixed(this.dec)+text).width);if(this.value>this.max||this.value<this.min)cx.fillStyle=GaugeBaseWidget.OUT_OF_RANGE_COLOR;else cx.fillStyle=this.#cstyle.getPropertyValue('--font2');cx.font=cv.width*0.43*10/w+'px '+font;cx.fillText(this.value.toFixed(this.dec)+this.unit,cv.width/2,cv.height*0.93);cx.font='10px '+font;w=Math.max(cx.measureText(Math.round(this.min)).width,cx.measureText(Math.round(this.max)).width);cx.fillStyle=this.#cstyle.getPropertyValue('--font');cx.font=cx.lineWidth*0.55*10/w+'px '+font;cx.fillText(this.min,cx.lineWidth,cv.height*0.92);cx.fillText(this.max,cv.width-cx.lineWidth,cv.height*0.92);}#redrawGaugeR(){this.color=hexToCol(this.data.color);let cv=this.$el;let rw=cv.parentNode.clientWidth;if(!rw)return;const ratio=window.devicePixelRatio;cv.style.width=rw+'px';cv.style.height=cv.style.width;cv.width=Math.floor(rw*ratio);cv.height=cv.width;let cx=cv.getContext("2d");let perc=(this.value-this.min)*100/(this.max-this.min);if(perc<0)perc=0;if(perc>100)perc=100;if(this.perc==null)this.perc=perc;else{if(Math.abs(this.perc-perc)<=0.15)this.perc=perc;else this.perc+=(perc-this.perc)*0.15;if(this.perc!=perc)setTimeout(()=>this.#redraw(),20);}
let joint=Math.PI*(0.5+2*(this.perc/100));cx.clearRect(0,0,cv.width,cv.height);cx.lineWidth=cv.width/8;cx.strokeStyle=this.#cstyle.getPropertyValue('--dark');cx.beginPath();cx.arc(cv.width/2,cv.height/2,cv.width/2-cx.lineWidth,joint,Math.PI*2.5);cx.stroke();cx.strokeStyle=this.color;cx.beginPath();cx.arc(cv.width/2,cv.height/2,cv.width/2-cx.lineWidth,Math.PI/2,joint);cx.stroke();let font=this.#cstyle.fontFamily;cx.fillStyle=this.color;cx.font='10px '+font;cx.textAlign="center";cx.textBaseline="middle";let text=this.unit;let len=Math.max((this.value.toFixed(this.dec)+text).length,(this.min.toFixed(this.dec)+text).length,(this.max.toFixed(this.dec)+text).length);if(len==1)text+='  ';else if(len==2)text+=' ';let w=Math.max(cx.measureText(this.value.toFixed(this.dec)+text).width,cx.measureText(this.min.toFixed(this.dec)+text).width,cx.measureText(this.max.toFixed(this.dec)+text).width);if(this.value>this.max||this.value<this.min)cx.fillStyle=GaugeBaseWidget.OUT_OF_RANGE_COLOR;else cx.fillStyle=this.#cstyle.getPropertyValue('--font2');cx.font=cv.width*0.5*10/w+'px '+font;cx.fillText(this.value.toFixed(this.dec)+this.unit,cv.width/2,cv.height*0.52);}#redrawGaugeL(){this.color=hexToCol(this.data.color);let cv=this.$el;let rw=cv.parentNode.clientWidth;if(!rw)return;const ratio=window.devicePixelRatio;let height=30;let r=ratio;let sw=2*r;let off=5*r;cv.style.width=rw+'px';cv.style.height=height+'px';cv.width=Math.floor(rw*r);cv.height=Math.floor(height*r);const cx=cv.getContext("2d");let perc=(this.value-this.min)*100/(this.max-this.min);if(perc<0)perc=0;if(perc>100)perc=100;if(this.perc==null)this.perc=perc;else{if(Math.abs(this.perc-perc)<=0.15)this.perc=perc;else this.perc+=(perc-this.perc)*0.15;if(this.perc!=perc)setTimeout(()=>this.#redraw(),20);}
let wid=cv.width-sw-off*2;cx.clearRect(0,0,cv.width,cv.height);cx.fillStyle=this.#cstyle.getPropertyValue('--dark');cx.beginPath();cx.roundRect(off+sw/2,sw/2,wid,cv.height-sw,5*r);cx.fill();cx.fillStyle=this.color;cx.beginPath();cx.roundRect(off+sw/2,sw/2,wid*this.perc/100,cv.height-sw,5*r);cx.fill();if(this.value>this.max||this.value<this.min)cx.fillStyle=GaugeBaseWidget.OUT_OF_RANGE_COLOR;else cx.fillStyle=this.#cstyle.getPropertyValue('--font');let font=this.#cstyle.fontFamily;cx.font=(19*r)+'px '+font;cx.textAlign="center";cx.textBaseline="middle";let txt=this.value.toFixed(this.dec)+this.unit;cx.fillText(txt,cv.width/2,cv.height*0.52);if(this.icon){let tw=cx.measureText(txt).width;cx.font=(20*r)+'px FA5';cx.textAlign="right";cx.fillText(getIcon(this.icon),cv.width/2-tw/2-off,cv.height*0.52);}
cx.fillStyle=this.#cstyle.getPropertyValue('--font');cx.font=(12*r)+'px '+font;cx.textAlign="left";cx.fillText(this.min.toFixed(this.dec),off+sw/2+off,cv.height*0.52);cx.textAlign="right";cx.fillText(this.max.toFixed(this.dec),cv.width-(off+sw/2+off),cv.height*0.52);}}
class GaugeWidget extends GaugeBaseWidget{static wtype='gauge';constructor(data,renderer){super(data,renderer);}}
class GaugeRWidget extends GaugeBaseWidget{static wtype='gauge_r';constructor(data,renderer){super(data,renderer);}}
class GaugeLWidget extends GaugeBaseWidget{static wtype='gauge_l';constructor(data,renderer){super(data,renderer);}}
class HTMLWidget extends BaseWidget{static wtype='html';$el;#root;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'div',name:'el',});this.#root=this.$el.attachShadow({mode:'closed'});this.#root.innerHTML=waiter();this.update(data);}
update(data){super.update(data);if(!data.value)return;if(data.value.endsWith('.html')){this.addFile(data.value,'text',file=>{this.#apply(file);});}else{this.#apply(data.value);}}#apply(text){if(!this.renderer.device.info.trust){this.#root.replaceChildren();this.#root.innerHTML=noTrust();return;}
this.#root.innerHTML=text;}}
class IconWidget extends BaseWidget{static wtype='icon';$el;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'span',class:'w_icon w_icon_led',text:"",name:'el',style:{fontSize:'35px',},});this.update(data);}
update(data){super.update(data);if('icon'in data)this.$el.innerHTML=getIcon(data.icon);if('fsize'in data)this.$el.style.fontSize=data.fsize+'px';if('color'in data)this.$el.style.setProperty('--on-color',hexToCol(data.color));if('value'in data){if(Number(data.value))this.$el.classList.add('w_icon_on');else this.$el.classList.remove('w_icon_on');}}
static style=`
.w_icon {
font-weight: bold;
font-family: 'FA5';
}
.w_icon_led {
--on-color: var(--prim);
color: var(--black);
text-shadow: 0 0 4px #0003;
}
.w_icon_led.w_icon_on {
color: var(--on-color);
text-shadow: 0 0 10px var(--on-color);
}`;}
class ImageWidget extends BaseWidget{static wtype='image';$el;#path;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'div',name:'el',html:waiter(),});this.update(data);}
update(data){super.update(data);if('value'in data)this.#path=data.value;if('action'in data||'value'in data){this.addFile(this.#path,'url',file=>{this.$el.innerHTML=`<img style="width:100%" src="${file}">`;});}}}
class InputWidget extends BaseWidget{static wtype='input';$el;#changed;#regex;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'div',class:'w_inp_cont',children:[{tag:'input',class:'w_inp',name:'el',type:'text',events:{keydown:e=>{if(e.key=='Enter')this.#send(true);},input:()=>{this.#changed=true;},focusout:()=>{this.#send();}}}]});this.update(data);}
update(data){super.update(data);if('regex'in data)this.#regex=data.regex;if('color'in data)this.$el.style.boxShadow='0px 2px 0px 0px '+hexToCol(data.color);if('value'in data)this.$el.value=data.value;if('maxlen'in data)this.$el.maxlength=Math.ceil(data.maxlen);if('disable'in data)this.disable(this.$el,data.disable);}#send(force=false){if(this.#regex){const r=new RegExp(this.#regex);if(!r.test(this.$el.value)){showPopupError("Wrong text!");return;}}
if(force||this.#changed){this.#changed=false;this.set(this.$el.value);}}
static style=`
.w_inp {
font-size: 17px;
border: none;
font-family: var(--font_f);
width: 100%;
color: var(--font);
padding-left: 4px;
margin-top: -4px;
background: none;
box-shadow: 0px 2px 0px 0px var(--prim);
}
.w_inp:focus {
filter: brightness(1.3);
outline: none;
}
.w_inp_cont {
display: flex;
width: 100%;
}`;}
class PassWidget extends BaseWidget{static wtype='pass';$el;#changed;#regex;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'div',class:'w_inp_cont',children:[{tag:'input',class:'w_inp',name:'el',type:'password',events:{keydown:e=>{if(e.key=='Enter')this.#send(true);},input:()=>{this.#changed=true;},focusout:()=>{this.#send();}}},{tag:'div',class:'btn_inp_block',children:[{tag:'button',class:'icon w_eye',text:'',events:{click:()=>{this.$el.type=this.$el.type=='text'?'password':'text';}}}]}]});this.update(data);}
update(data){super.update(data);if('regex'in data)this.#regex=data.regex;if('color'in data)this.$el.style.boxShadow='0px 2px 0px 0px '+hexToCol(data.color);if('value'in data)this.$el.value=data.value;if('maxlen'in data)this.$el.maxlength=Math.ceil(data.maxlen);if('disable'in data)this.disable(this.$el,data.disable);}#send(force=false){if(this.#regex){const r=new RegExp(this.#regex);if(!r.test(this.$el.value)){showPopupError("Wrong text!");return;}}
if(force||this.#changed){this.#changed=false;this.set(this.$el.value);}}
static style=`
.w_eye {
font-size: 18px;
cursor: pointer;
color: var(--font2);
margin-top: -7px;
}`;}
class JoyWidget extends BaseWidget{static wtype='joy';$el;#center=0;#posX=null;#posY=null;#pressed=0;#_onTouchStart;#_onTouchMove;#_onTouchEnd;#_onMouseDown;#_onMouseMove;#_onMouseUp;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'canvas',name:'el'});this.data.color=colToInt(hexToCol(this.data.color));if("ontouchstart"in document.documentElement){this.#_onTouchStart=this.#onTouchStart.bind(this);this.#_onTouchMove=this.#onTouchMove.bind(this);this.#_onTouchEnd=this.#onTouchEnd.bind(this);this.$el.addEventListener("touchstart",this.#_onTouchStart,{passive:false});document.addEventListener("touchmove",this.#_onTouchMove,{passive:false});document.addEventListener("touchend",this.#_onTouchEnd);}else{this.#_onMouseDown=this.#onMouseDown.bind(this);this.#_onMouseMove=this.#onMouseMove.bind(this);this.#_onMouseUp=this.#onMouseUp.bind(this);this.$el.addEventListener("mousedown",this.#_onMouseDown);document.addEventListener("mousemove",this.#_onMouseMove);document.addEventListener("mouseup",this.#_onMouseUp);}
this.$el.parentNode.addEventListener('resize',()=>{this.#reset();this.#redraw();})
this.update(data);this.disable(this.$el,data.disable);waitFrame().then(()=>{this.#redraw(false);});}
close(){if("ontouchstart"in document.documentElement){this.$el.removeEventListener("touchstart",this.#_onTouchStart,{passive:false});document.removeEventListener("touchmove",this.#_onTouchMove,{passive:false});document.removeEventListener("touchend",this.#_onTouchEnd);}else{this.$el.removeEventListener("mousedown",this.#_onMouseDown);document.removeEventListener("mousemove",this.#_onMouseMove);document.removeEventListener("mouseup",this.#_onMouseUp);}}#reset(){this.#posX=null;this.#posY=null;}#redraw(send=true){const cv=this.$el;let size=cv.parentNode.clientWidth;if(!size)return;cv.style.width=size+'px';cv.style.height=size+'px';size*=window.devicePixelRatio;cv.width=size;cv.height=size;cv.style.cursor='pointer';const r=size*0.23;const R=size*0.4;this.#center=size/2;if(this.#posX===null)this.#posX=this.#center;if(this.#posY===null)this.#posY=this.#center;this.#posX=constrain(this.#posX,r,size-r);this.#posY=constrain(this.#posY,r,size-r);let x=Math.round((this.#posX-this.#center)/(size/2-r)*255);let y=-Math.round((this.#posY-this.#center)/(size/2-r)*255);const cx=cv.getContext("2d");cx.clearRect(0,0,size,size);cx.beginPath();cx.arc(this.#center,this.#center,R,0,2*Math.PI,false);let grd=cx.createRadialGradient(this.#center,this.#center,R*2/3,this.#center,this.#center,R);grd.addColorStop(0,'#00000005');grd.addColorStop(1,'#00000030');cx.fillStyle=grd;cx.fill();cx.beginPath();cx.arc(this.#posX,this.#posY,r,0,2*Math.PI,false);grd=cx.createRadialGradient(this.#posX,this.#posY,0,this.#posX,this.#posY,r);grd.addColorStop(0,intToCol(adjustColor(this.data.color,0.7)));grd.addColorStop(1,intToCol(adjustColor(this.data.color,this.#pressed?1.3:1)));cx.fillStyle=grd;cx.fill();if(this.data.exp){x=((x*x+255)>>8)*(x>0?1:-1);y=((y*y+255)>>8)*(y>0?1:-1);}
if(send){this.set(x+';'+y);this.setSuffix('['+x+','+y+']');}}#onTouchStart(event){if(this.data.disabled)return;event.preventDefault();this.#pressed=true;}#onTouchMove(event){if(!this.#pressed)return;event.preventDefault();let target=null;for(const t of event.changedTouches){if(t.target===this.$el)target=t;}
if(!target)return;this.#posX=target.pageX;this.#posY=target.pageY;if(this.$el.offsetParent.tagName.toUpperCase()==="BODY"){this.#posX-=this.$el.offsetLeft;this.#posY-=this.$el.offsetTop;}else{this.#posX-=this.$el.offsetParent.offsetLeft;this.#posY-=this.$el.offsetParent.offsetTop;}
const ratio=window.devicePixelRatio;this.#posX*=ratio;this.#posY*=ratio;this.#redraw();}#onTouchEnd(event){if(!this.#pressed)return;let target=null;for(const t of event.changedTouches){if(t.target===this.$el)target=t;}
if(!target)return;this.#pressed=false;if(!this.data.keep){this.#posX=this.#center;this.#posY=this.#center;}
this.#redraw();}#onMouseDown(){if(this.data.disabled)return;this.#pressed=true;document.body.style.userSelect='none';}#onMouseMove(event){if(!this.#pressed)return;this.#posX=event.pageX;this.#posY=event.pageY;if(this.$el.offsetParent.tagName.toUpperCase()==="BODY"){this.#posX-=this.$el.offsetLeft;this.#posY-=this.$el.offsetTop;}else{this.#posX-=this.$el.offsetParent.offsetLeft;this.#posY-=this.$el.offsetParent.offsetTop;}
const ratio=window.devicePixelRatio;this.#posX*=ratio;this.#posY*=ratio;this.#redraw();}#onMouseUp(){if(!this.#pressed)return;this.#pressed=false;if(!this.data.keep){this.#posX=this.#center;this.#posY=this.#center;}
this.#redraw();document.body.style.userSelect='';}}
function constrain(val,min,max){return val<min?min:(val>max?max:val);}
class LabelWidget extends BaseWidget{static wtype='label';$lbl_cont;$lbl_icon;$lbl;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'div',class:'w_label',name:'lbl_cont',style:{fontSize:'33px'},children:[{tag:'span',class:'w_icon',name:'lbl_icon',},{tag:'label',name:'lbl',}]});this.update(data);}
update(data){super.update(data);if('value'in data)this.$lbl.textContent=data.value;if('color'in data)this.$lbl_cont.style.color=hexToCol(data.color);if('fsize'in data)this.$lbl_cont.style.fontSize=data.fsize+'px';if('align'in data)this.align(data.align);if('icon'in data)this.$lbl_icon.innerHTML=data.icon?(getIcon(data.icon)+' '):'';}
static style=`
.w_label {
padding: 0px 10px;
text-wrap: nowrap;
}`;}
class LedWidget extends BaseWidget{static wtype='led';$el;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'div',class:'w_led',name:'el',});this.update(data);}
update(data){super.update(data);if('color'in data)this.$el.style.setProperty('--on-color',hexToCol(data.color));if('disable'in data)this.disable(this.$el,data.disable);if('value'in data){if(data.value)this.$el.classList.add('w_led_on');else this.$el.classList.remove('w_led_on');}}
static style=`
.w_led {
--on-color: var(--prim);
margin: 0 auto;
width: 30px;
height: 30px;
border-radius: 50%;
background: var(--back);
box-shadow: inset 0 0 2px 2px var(--black);
}
.w_led.w_led_on {
background: var(--on-color);
box-shadow: var(--on-color) 0 0 9px 1px, inset 2px 3px 0px 0px #fff3;
}`;}
const markIcon=L.divIcon({html:'',iconSize:[26,36],iconAnchor:[26/2,43],className:'icon icon_map',});const mapZeroPos=[55.754994,37.623288];const mapLayers=[{attribution:"OpenStreetMap",tiles:"https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",subdomains:'abc'},{attribution:"Google",tiles:"https://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}",subdomains:['mt0','mt1','mt2','mt3']},{attribution:"Google",tiles:"https://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}",subdomains:['mt0','mt1','mt2','mt3']},{attribution:"Google",tiles:"https://{s}.google.com/vt/lyrs=s,h&x={x}&y={y}&z={z}",subdomains:['mt0','mt1','mt2','mt3']}];class MapWidget extends BaseWidget{static wtype='map';$el;map;marker;cvdata=[];constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'div',name:'el',style:{width:'100%',height:'100%',},});waitRender(this.$el).then(()=>{this.map=L.map(this.$el);let layer=mapLayers[data.layer??0];L.tileLayer(layer.tiles,{minZoom:3,maxZoom:20,attribution:layer.attribution,subdomains:layer.subdomains,}).addTo(this.map);this.map.on('click',async(e)=>{if(this.disabled()||!data.active)return;this._send(e.latlng);});L_canvasLayer().delegate(this).addTo(this.map);this.map.setView(('latlon'in data)?data.latlon:mapZeroPos,10);this.update(data);});}
update(data){super.update(data);if('latlon'in data){this.map.panTo(data.latlon);this._setMarker(data.latlon);}
if('data'in data)this.cvdata=this.cvdata.concat(data.data);}
onDrawLayer(info){let cx=info.canvas.getContext('2d');cx.clearRect(0,0,info.canvas.width,info.canvas.height);showCanvasAPI(info.canvas,this.cvdata,L_scale(info),(x,y)=>{let point=L_toPoint(info,[x/1000000.0,y/1000000.0]);return[point.x,point.y];});}
_setMarker(latlon){if(this.marker){this.marker.setLatLng(latlon);}else{this.marker=L.marker(latlon,{icon:markIcon,draggable:'true'}).addTo(this.map).on('dragend',(e)=>this._send(e.target.getLatLng()));}}
_send(pos){this.set(pos.lat.toFixed(6)+','+pos.lng.toFixed(6)).then(()=>this._setMarker(pos));}
static style=`
.icon_map {
font-size: 35px;
color: #e70017;
}`;}
class MenuOpenEvent extends Event{constructor(name){super('menuopen');this.name=name;}}
class MenuWidget extends Widget{static wtype='menu';$el;constructor(data,renderer){super(data,renderer);this.$el=EL('menu');this.update(data);}
update(data){super.update(data);if(!data.text||!this.$el)return;this.$el.replaceChildren();const labels=data.text.split(';');for(const i in labels){this.$el.append(makeDOM(null,{tag:'div',class:i==data.value?"menu_item menu_act":"menu_item",text:labels[i].trim(),events:{click:()=>this.#openMenu(i)}}));}
this.$el.append(makeDOM(null,{tag:'hr'}));this.renderer.dispatchEvent(new Event('menuchanged'));}#openMenu(i){this.renderer.dispatchEvent(new MenuOpenEvent(i));this.set(i);}
close(){if(this.$el)this.$el.replaceChildren();}
static style=`
#menu_overlay {
cursor: pointer;
position: fixed;
left: 0;
top: 0;
display: none;
width: 100%;
height: 100%;
background-color: #0008;
z-index: 2;
animation: opac .1s;
backdrop-filter: blur(4px);
}
.menu {
display: block;
max-height: 0;
transition: max-height .1s ease-out;
overflow: hidden;
position: fixed;
top: 50px;
background: var(--tab);
z-index: 3;
border-radius: 0px 0px 4px 4px;
max-width: var(--ui_width);
left: 50%;
transform: translateX(-50%);
}
.menu_show {
max-height: 100%;
transition: max-height .1s ease-in;
}
.menu_item {
cursor: pointer;
height: 35px;
line-height: 35px;
font-size: 20px;
padding-left: 10px;
border: 5px solid transparent;
border-width: 0 0 0 5px;
}
.menu_item:first-child {
margin-top: 8px;
}
.menu_item:last-child {
margin-bottom: 8px;
}
.menu_item:hover {
background: var(--back);
}
.menu_act {
border-color: var(--prim);
}`;}
class SpaceWidget extends BaseWidget{static wtype='space';constructor(data,renderer){super(data,renderer);this.update(data);}
update(data){data.nolabel=true;data.notab=true;super.update(data);}}
class DummyWidget extends Widget{static wtype='dummy';static virtual=true;constructor(data,renderer){super(data,renderer);}}
class PlotWidget extends BaseWidget{static wtype='plot';$el;#cv;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'div',class:'',children:[{tag:'canvas',name:'el',}]});this.#cv=new Plot(data.id,this.$el,data.height??150,data.text,data.type,true);this.$el.parentNode.addEventListener('resize',()=>{this.#cv.resize();});wait2Frame().then(()=>{this.#cv.redraw();});this.update(data.value);}
update(data){super.update(data);if('value'in data){this.#cv.update(data.value);this.#cv.redraw();}}
close(){this.#cv.stop();}}
class Plot{constructor(id,cv,height,labels,type,dark){this.id=id;this.cv=cv;this.height=height;this.labels=labels?labels.split(';'):null;this.type=type;this.dark=dark;this.data=[];this.resize();cv.onclick=(event)=>this._click(event);if("ontouchstart"in document.documentElement){document.addEventListener("touchmove",this._onTouchMove,{passive:false});}else{document.addEventListener("mousemove",this._onMouseMove);}}
stop(){if("ontouchstart"in document.documentElement){document.removeEventListener("touchmove",this._onTouchMove);}else{document.removeEventListener("mousemove",this._onMouseMove);}}
clear(){this.data=[];}
resize(){let cv=this.cv;let rw=cv.parentNode.clientWidth;if(!rw)return;let r=window.devicePixelRatio;cv.style.width=rw+'px';cv.style.height=this.height+'px';cv.width=Math.floor(rw*r);cv.height=Math.floor(this.height*r);this.redraw(this.data);}
update(data){this.data=this.data.concat(data);}
redraw(){let cv=this.cv;let cx=cv.getContext("2d");let r=window.devicePixelRatio;cx.fillRect(0,0,cv.width,cv.height);}
_click(e){let rect=this.cv.getBoundingClientRect();let x=Math.round(e.clientX-rect.left);if(x<0)x=0;let y=Math.round(e.clientY-rect.top);if(y<0)y=0;}
_onTouchMove=(event)=>{event.preventDefault();for(let t of event.changedTouches){if(t.target===this.cv)this._move(t);}}
_onMouseMove=(event)=>{if(event.target==this.cv)this._move(event);}
_move(rect){let x=rect.pageX;let y=rect.pageY;if(this.cv.offsetParent.tagName.toUpperCase()==="BODY"){x-=this.cv.offsetLeft;y-=this.cv.offsetTop;}else{x-=this.cv.offsetParent.offsetLeft;y-=this.cv.offsetParent.offsetTop;}
x=this._constrain(x,0,this.cv.width/window.devicePixelRatio);y=this._constrain(y,0,this.cv.height/window.devicePixelRatio);this.redraw();}
_constrain(x,min,max){if(x<min)return min;if(x>max)return max;return x;}};
class PluginLoader extends Widget{static wtype='plugin';constructor(data,renderer){super(data,renderer);this.update(data);}
update(data){super.update(data);if(!data.value)return;if(data.value.endsWith('.js')){this.addFile(data.value,'text',file=>{this.#apply(file);});}else{this.#apply(data.value);}}#apply(text){if(Renderer.registerPlugin(text))
this.renderer.dispatchEvent(new Event('pluginloaded'));}}
class LoadWidget extends Widget{static wtype='load';$el;#widget;constructor(data,renderer){super(data,renderer);this.$el=document.createElement('div');this.$el.classList.add('widget_col');this.$el.style.width=this.data.wwidth_t+'%';this.$el.innerHTML=waiter();const w=this.renderer._getPlugin(data.wtype);if(w)this.#apply(w);else this.renderer.addEventListener('pluginloaded',()=>{const w=this.renderer._getPlugin(data.type);if(w)this.#apply(w);});this.update(data);}
update(data){super.update(data);if(this.#widget)this.#widget.update(data);}#apply(w){if(!this.renderer.device.info.trust){this.$el.innerHTML=noTrust();return;}
if(this.#widget)this.#widget.close();this.#widget=new w(this.data,this.renderer);const $w=this.#widget.build();if($w)this.$el.replaceChildren($w);else this.$el.replaceChildren();}
build(){return this.$el;}
close(){if(this.#widget)this.#widget.close();this.#widget=undefined;}
handleSetTimeout(){if(this.#widget)this.#widget.handleSetTimeout();}
handleAck(){if(this.#widget)this.#widget.handleAck();}}
class ConfirmWidget extends Widget{static wtype='confirm';static virtual=true;constructor(data,renderer){super(data,renderer);this.update(data);}
update(data){super.update(data);if('action'in data)asyncConfirm(this.data.text).then(res=>this.set(res?1:0));}}
class PromptWidget extends Widget{static wtype='prompt';static virtual=true;constructor(data,renderer){super(data,renderer);this.update(data);}
update(data){super.update(data);if('action'in data)asyncPrompt(this.data.text,this.data.value).then(res=>{if(res!==null){this.data.value=res;this.set(res);}});}}
class RowWidget extends Widget{static wtype='row';#children;constructor(data,renderer){super(data,renderer);this.#children=[];this.renderer._makeWidgets(this.#children,data.type,data.data);}
build(){const $root=document.createElement('div');$root.classList.add('widget_'+this.data.type);$root.style.width=this.data.wwidth_t+'%';for(const w of this.#children){const $w=w.build();if($w)$root.append($w);}
return $root;}}
class ColWidget extends RowWidget{static wtype='col';constructor(data,renderer){super(data,renderer);}}
class SelectWidget extends BaseWidget{static wtype='select';$el;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'select',class:'w_select',name:'el',style:{color:'var(--prim)'},events:{change:()=>this.set(this.$el.value)},});this.update(data);}
update(data){super.update(data);if('value'in data)this.$el.value=data.value;if('text'in data){const options=[];if(data.text){const ops=data.text.toString().split(/[;,]/);for(const i in ops){const option=document.createElement('option');option.value=i;option.text=ops[i].trim();option.selected=(i==this.$el.value);options.push(option);}}
this.$el.replaceChildren(...options);}
if('color'in data)this.$el.style.color=hexToCol(data.color);}
static style=`
.w_select {
border: none;
outline: none;
cursor: pointer;
font-size: 18px;
font-family: var(--font_f);
width: 100%;
border-radius: 4px;
background: none;
padding-left: 7px;
min-height: 30px;
}
select option {
background: var(--back);
}`;}
class SliderWidget extends BaseWidget{static wtype='slider';$el;$out;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'input',class:'w_slider',name:'el',type:'range',min:0,max:100,step:1,dec:0,value:0,events:{input:()=>{this.#move()},wheel:e=>{e.preventDefault();if(this.$el.getAttribute("disabled"))return;this.$el.value=Number(this.$el.value)-Math.sign(Number(e.deltaY))*Number(this.$el.step);this.#move();},},},{tag:'div',class:'w_slider_out',children:[{tag:'output',name:'out'}]});this.update(data);waitFrame().then(()=>this.#move(false));}
update(data){super.update(data);if('value'in data)this.$el.value=data.value;if('color'in data)this.$el.style.backgroundImage=`linear-gradient(${hexToCol(data.color)}, ${hexToCol(data.color)})`;if('min'in data)this.$el.min=data.min;if('max'in data)this.$el.max=data.max;if('step'in data)this.$el.step=data.step;if('disable'in data)this.disable(this.$el,data.disable);this.#move(false);}#move(send=true){this.$el.style.backgroundSize=(Number(this.$el.value)-Number(this.$el.min))*100/(Number(this.$el.max)-Number(this.$el.min))+'% 100%';this.$out.textContent=Number(this.$el.value).toFixed(Number(this.data.dec??0))+(this.data.unit??'');if(send)this.set(this.$el.value);}
static style=`
.w_slider {
-webkit-appearance: none;
-moz-appearance: none;
width: 100%;
height: 35px;
padding: 0;
margin: 0;
background: var(--dark);
background-repeat: no-repeat;
background-image: linear-gradient(var(--prim), var(--prim));
border-radius: 5px;
cursor: pointer;
touch-action: none;
}
.w_slider:hover {
filter: brightness(1.1);
}
.w_slider::-webkit-slider-thumb {
-webkit-appearance: none;
height: 1px;
width: 1px;
}
.w_slider::-webkit-slider-thumb:hover {
filter: brightness(1.1);
}
.w_slider::-moz-range-thumb {
-moz-appearance: none;
outline: none;
border: none;
background: none;
height: 1px;
width: 1px;
}
.w_slider_out {
margin-left: -110px;
pointer-events: none;
text-align: right;
z-index: 1;
width: 100px;
padding-right: 10px;
}`;}
class SpinnerWidget extends BaseWidget{static wtype='spinner';$el;$unit;#dec=0;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'div',class:'w_spinner_row',children:[{tag:'button',class:'icon icon_btn btn_no_pad',text:'',events:{click:()=>this.#spin(-1)}},{tag:'div',class:'w_spinner_block',children:[{tag:'input',class:'w_spinner',name:'el',type:'number',min:0,max:100,step:1,value:0,events:{input:()=>this.#spin(0),keydown:e=>{if(e.key=='Enter'){e.preventDefault();this.#spin(0);}},wheel:e=>this.#wheel(e),}},{tag:'label',class:'w_spinner_unit',name:'unit',events:{wheel:e=>this.#wheel(e),}}]},{tag:'button',class:'icon icon_btn btn_no_pad',text:'',events:{click:()=>this.#spin(+1)}}]});this.disable(this.$el,data.disable);this.update(data);waitFrame().then(()=>this.#spin(0,false));}
update(data){super.update(data);if('value'in data)this.$el.value=data.value;if('min'in data)this.$el.min=data.min;if('max'in data)this.$el.max=data.max;if('step'in data)this.$el.step=data.step;if('dec'in data)this.#dec=data.dec;if('unit'in data)this.$unit.textContent=data.unit;this.#spin(0,false);}#spin(dir,send=true){const el=this.$el;if(dir&&el.getAttribute("disabled"))return;let val=Number(el.value)+Number(el.step)*Math.sign(Number(dir));val=Math.max(Number(el.min),val);val=Math.min(Number(el.max),val);el.value=Number(val).toFixed(Number(this.#dec));el.style.width=el.value.length+'ch';if(send)this.set(el.value);}#wheel(e){e.preventDefault();this.#spin(-e.deltaY);}
static style=`
.w_spinner_row {
display: flex;
align-items: center;
}
.w_spinner_block {
margin: 0px 10px;
display: flex;
}
.w_spinner {
outline: none;
border: none;
background: none;
text-align: center;
margin: 0;
padding: 0;
font-family: var(--font_f);
color: var(--font2);
font-size: 20px;
}
.w_spinner_unit {
font-family: var(--font_f);
color: var(--font2);
font-size: 20px;
}`;}
class StreamWidget extends BaseWidget{static wtype='stream';$el;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'img',name:'el',style:{width:'100%',}});this.update(data);}
update(data){super.update(data);if('port'in data||'path'in data)
this.$el.src=`http://${this.renderer.device.info.ip}:${data.port}/${data.path ?? ''}`;}}
class SwitchWidget extends BaseWidget{static wtype='switch_t';$el;$slider;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'div',class:'switch_cont',children:[{tag:'label',class:'switch',children:[{tag:'input',type:'checkbox',name:'el',events:{change:()=>{this.$slider.style.backgroundColor=this.$el.checked?hexToCol(this.data.color):'';this.set(this.$el.checked?1:0)}}},{tag:'span',class:'slider',name:'slider',}]}]});this.update(data);}
update(data){super.update(data);if('color'in data&&this.$el.checked)this.$slider.style.backgroundColor=hexToCol(data.color);if('value'in data){this.$el.checked=(Number(data.value)==1);this.$slider.style.backgroundColor=this.$el.checked?hexToCol(this.data.color):'';}
if('disable'in data)this.disable(this.$el,data.disable);}}
class SwitchIconWidget extends BaseWidget{static wtype='switch_i';$el;$slider;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'div',class:'icon icon_btn_big w_swicon',name:'el',style:{fontSize:'45px',width:'75px',},events:{click:()=>{if(this.$el.getAttribute('disabled'))return;this.$el.classList.toggle('w_swicon_on');this.set(this.$el.classList.contains('w_swicon_on')?1:0);}}});this.update(data);}
update(data){super.update(data);if('value'in data){if(Number(data.value)==1)this.$el.classList.add('w_swicon_on');else this.$el.classList.remove('w_swicon_on');}
if('fsize'in data){this.$el.style.fontSize=data.fsize+'px';this.$el.style.width=data.fsize*1.7+'px';}
if('icon'in data)this.$el.innerHTML=getIcon(data.icon);if('color'in data)this.$el.style.setProperty('--on-color',hexToCol(data.color));if('disable'in data)this.disable(this.$el,data.disable);}
static style=`
.w_swicon {
--on-color: var(--prim);
border-radius: 50%;
aspect-ratio: 1;
padding: 10px;
display: flex;
justify-content: center;
align-items: center;
box-sizing: border-box;
color: var(--on-color);
border: 2px solid var(--on-color);
}
.w_swicon_on {
color: var(--tab);
background: var(--on-color);
}`;}
class TableWidget extends BaseWidget{static wtype='table';$el;#align='';#width='';#data='';#path='';constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'table',class:'w_table',name:'el',});this.update(data);}
update(data){super.update(data);if('align'in data)this.#align=data.align;if('width'in data)this.#width=data.width;if('value'in data){let val=data.value;if(!val.includes(';')&&val.endsWith(".csv")){this.#path=val;}else{this.#path='';this.#data=val;}}
if('action'in data||'value'in data)this.#reload();else if('align'in data||'width'in data)this.#render();}#reload(){if(this.#path){this.$el.innerHTML=waiter();this.addFile(this.#path,'text',file=>{this.#data=file.replaceAll(/\\n/ig,"\n");this.#render();});}else{this.#render();}}#render(){const aligns=this.#align.split(/[,;]/);const widths=this.#width.split(/[,;]/);const table=parseCSV(this.#data);const items=[];for(const row of table){const $row=document.createElement('tr');for(const col in row){const $col=document.createElement('td');if(widths[col])$col.width=widths[col]+'%';$col.align=aligns[col]??'center';$col.textContent=row[col];$row.append($col);}
items.push($row);}
this.$el.replaceChildren(...items);}
static style=`
.w_table {
border-collapse: collapse;
width: 100%;
margin-bottom: 4px;
}
.w_table td,
.w_table th {
border: 1px solid var(--font3);
padding: 4px 8px;
}`;}
function parseCSV(str){const arr=[];let quote=false;for(let row=0,col=0,c=0;c<str.length;c++){let cc=str[c],nc=str[c+1];arr[row]=arr[row]||[];arr[row][col]=arr[row][col]||'';if(cc=='"'&&quote&&nc=='"'){arr[row][col]+=cc;++c;continue;}
if(cc=='"'){quote=!quote;continue;}
if((cc==';'||cc==',')&&!quote){++col;continue;}
if(cc=='\r'&&nc=='\n'&&!quote){++row;col=0;++c;continue;}
if(cc=='\n'&&!quote){++row;col=0;continue;}
if(cc=='\r'&&!quote){++row;col=0;continue;}
arr[row][col]+=cc;}
return arr;}
class TabsWidget extends BaseWidget{static wtype='tabs';$el;$ul;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'div',class:'w_tabs',name:'el',children:[{tag:'ul',name:'ul',events:{wheel:e=>{e.preventDefault();this.$ul.scrollLeft+=e.deltaY;},click:e=>{if(this.$el.getAttribute("disabled"))return;const tabId=e.target.dataset.tabId;if(tabId===undefined)return;this.set(tabId);this.#change(tabId,false);}}}]});this.disable(this.$el,data.disable);this.update(data);waitFrame().then(()=>this.#change(data.value??0));}
update(data){super.update(data);if('text'in data){const tabs=[];if(data.text){const labels=data.text.split(/[,;]/);for(const i in labels){const $i=makeDOM(null,{tag:'li',text:labels[i].trim(),});$i.dataset.tabId=i;tabs.push($i);}}
this.$ul.replaceChildren(...tabs);}
if('value'in data)this.#change(Number(data.value));if('color'in data)this.$ul.style.setProperty('--active-item-color',hexToCol(data.color));}#change(num,move=true){const list=this.$ul.children;for(let i=0;i<list.length;i++){if(i==num)list[i].classList.add('w_tab_act');else list[i].classList.remove('w_tab_act');}
if(move)this.$ul.scrollLeft=this.$ul.scrollWidth*num/list.length;}
static style=`
.w_tabs {
width: 100%;
}
.w_tabs>ul {
--active-item-color: var(--prim);
padding: 0;
display: flex;
list-style-type: none;
font-size: 19px;
flex-direction: row;
overflow-x: scroll;
white-space: nowrap;
scrollbar-width: none;
user-select: none;
margin: 0;
}
.w_tabs ul::-webkit-scrollbar {
display: none;
}
.w_tabs>ul>li {
display: flex;
align-items: center;
color: var(--font);
border-radius: 5px;
padding: 5px;
margin: 2px;
}
.w_tabs:not(.disable)>ul {
cursor: pointer;
}
.w_tabs:not(.disable)>ul>li:hover {
/*filter: brightness(0.8);*/
background: var(--back);
}
.w_tab_act {
background: var(--active-item-color) !important;
color: var(--tab) !important;
font-weight: 600;
}`;}
class TextWidget extends BaseWidget{static wtype='text';$el;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'textarea',class:'ui_area ui_area_passive',name:'el',readOnly:true,rows:5,});this.update(data);}
update(data){super.update(data);if('value'in data)this.$el.value=data.value;if('rows'in data)this.$el.rows=data.rows;if('disable'in data)this.disable(this.$el,data.disable);}}
class LogWidget extends BaseWidget{static wtype='log';$el;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'textarea',class:'ui_area ui_area_passive',name:'el',readOnly:true,rows:5,style:{color:'var(--prim)'},});this.update(data);}
update(data){super.update(data);if('value'in data){this.$el.value=data.value.trim();this.$el.scrollTop=this.$el.scrollHeight;}
if('rows'in data)this.$el.rows=data.rows;if('disable'in data)this.disable(this.$el,data.disable);}}
class TextFileWidget extends BaseWidget{static wtype='text_f';$el;#path;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'textarea',class:'ui_area ui_area_passive',name:'el',readOnly:true,});this.update(data);}
update(data){super.update(data);if('value'in data)this.#path=data.value;if('rows'in data)this.$el.rows=data.rows;if('action'in data||'value'in data){this.addFile(this.#path,'text',(file)=>{this.$el.value=file;});}
if('disable'in data)this.disable(this.$el,data.disable);}}
class DisplayWidget extends BaseWidget{static wtype='display';$el;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'textarea',class:'w_disp',name:'el',readOnly:true,rows:2,style:{fontSize:'20px',background:'var(--prim)'},events:{wheel:e=>{e.preventDefault();this.$el.scrollLeft+=e.deltaY;}}});this.update(data);}
update(data){super.update(data);if('value'in data)this.$el.value=data.value;if('color'in data)this.$el.style.background=hexToCol(data.color);if('fsize'in data)this.$el.style.fontSize=data.fsize+'px';if('rows'in data)this.$el.rows=data.rows;if('disable'in data)this.disable(this.$el,data.disable);}
static style=`
.w_disp {
border: none;
outline: none;
font-family: var(--font_f);
width: 100%;
color: white;
resize: none;
cursor: default;
padding: 3px 7px;
border-radius: 5px;
margin-bottom: 3px;
/* overflow: hidden; */
text-wrap: nowrap;
}
.w_disp::-webkit-resizer {
display: none;
}
.w_disp::-webkit-scrollbar {
display: none;
}
.w_disp::-webkit-scrollbar-track {
display: none;
}
.w_disp::-webkit-scrollbar-thumb {
display: none;
}`;}
class AreaWidget extends BaseWidget{static wtype='area';$el;#changed;#regex;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'textarea',class:'ui_area',name:'el',events:{keydown:e=>{if(e.key=='Enter')this.#send(true);},input:()=>{this.#changed=true;},focusout:()=>{this.#send();}},});this.update(data);}
update(data){super.update(data);if('regex'in data)this.#regex=data.regex;if('color'in data)this.$el.style.boxShadow='0px 2px 0px 0px '+hexToCol(data.color);if('value'in data)this.$el.value=data.value;if('maxlen'in data)this.$el.maxlength=Math.ceil(data.maxlen);if('rows'in data)this.$el.rows=data.rows;if('disable'in data)this.disable(this.$el,data.disable);}#send(force=false){if(this.#regex){const r=new RegExp(this.#regex);if(!r.test(this.$el.value)){showPopupError("Wrong text!");return;}}
if(force||this.#changed){this.#changed=false;this.set(this.$el.value);}}}
class TitleWidget extends BaseWidget{static wtype='title';$cont;$icon;$label;constructor(data,renderer){super(data,renderer);this.makeLayout({tag:'div',class:'w_label',name:'cont',style:{fontSize:'35px'},children:[{tag:'span',class:'w_icon',name:'icon',},{tag:'label',name:'label',}]});this.update(data);}
update(data){data.nolabel=true;data.notab=true;data.square=false;super.update(data);if('value'in data)this.$label.textContent=data.value;if('color'in data)this.$cont.style.color=hexToCol(data.color);if('fsize'in data)this.$cont.style.fontSize=data.fsize+'px';if('align'in data)this.align(data.align);if('icon'in data)this.$icon.innerHTML=data.icon?(getIcon(data.icon)+' '):'';}}



const langBase={English:{errors:["not an error","open file error","not enough space","checksum error","size error","start error","write error","end error","aborted","timeout","busy","memory error","wrong client","forbidden","module disabled","incorret type","damaged packet","can't allocate","FS busy","cancelled"],themes:{auto:"System",dark:"Dark",light:"Light"},colors:{ORANGE:"Orange",YELLOW:"Yellow",GREEN:"Green",MINT:"Mint",AQUA:"Aqua",BLUE:"Blue",VIOLET:"Violet",PINK:"Pink"},api_mis:"Device and App API version mismatch. Update library and App!",pop_yes:"Yes",pop_no:"No",cancel:"Cancel",done:"Done",error:"Error",upload:"Upload",fetch:"Fetch",connecting:"Connecting",connected:"Connected",connect:"Connect",disconnect:"Disconnect",disconnected:"Disconnected",not_conn:"Not connected",select:"Select",clip_copy:"Copied to clipboard",import_ok:"Import done",import_err:"Wrong data",config:"Config",wifi_ip:"Local IP",wifi_mask:"Netmask",wifi_port:"HTTP port",wifi_add:"Add by IP",mq_host:"Host",mq_port:"Port (WSS)",mq_login:"Login",mq_pass:"Password",sr_baud:"Baudrate",sr_offset:"Start offset, ms",sr_port:"Port",tg_token:"Bot token",tg_chat:"Chat ID",cfg_search:"Search",cfg_prefix:"Net name",cfg_id:"Client ID",cfg_theme:"Theme",cfg_color:"Main Color",cfg_font:"Font",cfg_width:"App width",cfg_wide_mode:"Wide device UI",cfg_css:"Plugin CSS",cfg_js:"Plugin JS",cfg_proj:"Project links",cfg_plugin:"Plugin links",cfg_updates:"Check updates",cfg_sett:"Settings",cfg_import:"Import",cfg_export:"Export",cfg_reset:"Reset",cfg_reset_conf:"Reset all settings?",cfg_add:"Add by ID",cfg_find_dev:"Find devices",m_config:"Config",m_info:"Info",m_files:"Files",m_ota:"OTA",i_settings:"Settings",i_console:"Console",i_trust:"Trust this device",i_main:"UI width",i_css:"Plugin CSS",i_js:"Plugin JS",i_reboot:"Reboot",i_link:"Link",dev_trust_warning:"",i_topics:"Topics",i_version:"Version",i_net:"Network",i_memory:"Memory",i_system:"System",fs_fsbr:"FS browser",fs_used:"Used",fs_format:"Format",fs_upload_to:"Upload to",fs_upload:"Upload",fs_create_f:"Create file",fs_create:"Create",fs_name:"File name",fs_wrap:"Wrap text",fs_save:"Save & upload",rename:"Rename",delete:"Delete",fetch:"Fetch",download:"Download",open:"Open",edit:"Edit",wrong_ota:"Wrong file! Use",p_add_project:"Add your project",p_projects:"Projects",p_not_support:"Browser in not supported",p_use_https:"Use https version of website",p_has_upd:"Update available",p_upd:"Update firmware",p_install:"Install",wrong_text:"Wrong text!",wrong_ip:"Wrong IP",dup_names:"Duplicated names",redirect:"Redirect to",hub_pin:"Enter PIN",dev_pin:"Enter PIN for device ",blocked:"Blocked. Trust?",unblock:"Trust this device and it's custom code?",plugin_test:"Plugin Test",add_plugin:"Add your plugin",plugins:"Plugins",plug_add:"Add plugin by name",plug_link:"Go to plugin",delete_plugin:"Delete plugin?",my_plugins:"MY PLUGINS",},Russian:{errors:["не ошибка","невозможно открыть файл","недостаточно места","ошибка контрольной суммы","ошибка размера","ошибка старта","ошибка записи","ошибка завершения","прервано","тайм-аут","занят","ошибка памяти","не тот клиент","запрещено","модуль отключен","некорректный тип","пакет повреждён","невозможно выделить память","файловая система занята","отменено"],themes:{auto:"Системная",dark:"Тёмная",light:"Светлая"},colors:{ORANGE:"Оранжевый",YELLOW:"Жёлтый",GREEN:"Зелёный",MINT:"Мятный",AQUA:"Бирюзовый",BLUE:"Синий",VIOLET:"Фиолетовый",PINK:"Розовый"},api_mis:"Разная версия API у устройства и приложения. Обнови приложение и библиотеку!",pop_yes:"Да",pop_no:"Нет",cancel:"Отмена",done:"Завершено",error:"Ошибка",upload:"Загрузка",fetch:"Скачивание",connecting:"Подключение",connected:"Подключено",connect:"Подключить",disconnect:"Отключить",disconnected:"Отключено",not_conn:"Не подключено",select:"Выбрать",clip_copy:"Скопировано в буфер обмена",import_ok:"Импорт завершён",import_err:"Некорректные данные",config:"Настройки",wifi_ip:"Мой IP",wifi_mask:"Маска сети",wifi_port:"HTTP порт",wifi_add:"Добавить по IP",mq_host:"Хост",mq_port:"Порт (WSS)",mq_login:"Логин",mq_pass:"Пароль",sr_baud:"Скорость",sr_offset:"Задержка запуска, мс",sr_port:"Порт",tg_token:"Токен бота",tg_chat:"ID чата",cfg_search:"Поиск",cfg_prefix:"Имя сети",cfg_id:"ID клиента",cfg_theme:"Тема",cfg_color:"Цвет",cfg_font:"Шрифт",cfg_width:"Ширина окна",cfg_wide_mode:"Интерфейс по ширине окна",cfg_css:"Плагин CSS",cfg_js:"Плагин JS",cfg_proj:"Ссылки проектов",cfg_plugin:"Ссылки плагинов",cfg_updates:"Проверять обновления",cfg_sett:"Настройки",cfg_import:"Импорт",cfg_export:"Экспорт",cfg_reset:"Сброс",cfg_reset_conf:"Сбросить все настройки?",cfg_add:"Добавить по ID",cfg_find_dev:"Найти устройства",m_config:"Настройки",m_info:"Инфо",m_files:"Файлы",m_ota:"OTA",i_settings:"Настройки",i_console:"Консоль",i_trust:"Доверять этому устройству",i_main:"Ширина ПУ",i_css:"Плагин CSS",i_js:"Плагин JS",i_reboot:"Перезагрузка",i_link:"Ссылка",dev_trust_warning:"Внимание: включение этой настройки разрешит устройству выполняить скрипты от в GyverHub. Включение этой настройки для неизвестных устройств может нарушить работу GyverHub и украсть ваши данные!\n\nВы действительно хотите доверять этому устройству?",i_topics:"Топики",i_version:"Версия",i_net:"Сеть",i_memory:"Память",i_system:"Система",fs_fsbr:"FS браузер",fs_used:"Занято",fs_format:"Форматировать",fs_upload_to:"Загрузить в",fs_upload:"Загрузить",fs_create_f:"Создать файл",fs_create:"Создать",fs_name:"Имя файла",fs_wrap:"Переносить текст",fs_save:"Сохранить и загрузить",rename:"Переименовать",delete:"Удалить",fetch:"Скачать",download:"Скачать",open:"Открыть",edit:"Редактировать",wrong_ota:"Некорректный файл! Используй",p_add_project:"Добавить свой проект",p_projects:"Проекты",p_not_support:"Браузер не поддерживается",p_use_https:"Используйте https версию сайта",p_has_upd:"Доступно обновление",p_upd:"Обновить прошивку",p_install:"Установить",wrong_text:"Некорректный текст!",wrong_ip:"Некорректный IP",dup_names:"Повторяющиеся имена",redirect:"Перейти на",hub_pin:"Введите ПИН",dev_pin:"Введите пин устройства ",blocked:"Заблокировано. Доверять?",unblock:"Доверять этому устройству и разрешить выполнение скриптов?",plugin_test:"Тест плагинов",add_plugin:"Добавить свой плагин",plugins:"Плагины",plug_add:"Добавить плагин по имени",plug_link:"Перейти",delete_plugin:"Удалить плагин?",my_plugins:"МОИ ПЛАГИНЫ",}};

const colors={ORANGE:"d55f30",YELLOW:"d69d27",GREEN:"37A93C",MINT:"25b18f",AQUA:"2ba1cd",BLUE:"297bcd",VIOLET:"825ae7",PINK:"c8589a",};function getError(err){if(err instanceof DeviceError)
return lang.errors[err.code];if(err instanceof TimeoutError)
return lang.errors[HubErrors.Timeout];if(err instanceof DOMException)
return`${err.name}: ${err.message}`
console.log(err);return`${err}`;}
function isSSL(){return window.location.protocol=='https:';}
function userLang(){switch(navigator.language||navigator.userLanguage){case'ru-RU':case'ru':return'Russian';}
return'English';}
async function switch_ssl(ssl){if(ssl&&!isSSL()){if(await asyncConfirm(lang.redirect+" HTTPS?"))window.location.href=window.location.href.replace('http:','https:');}
if(!ssl&&isSSL()){if(await asyncConfirm(lang.redirect+" HTTP?"))window.location.href=window.location.href.replace('https:','http:');}}
String.prototype.hashCode=function(){if(!this.length)return 0;let hash=new Uint32Array(1);for(let i=0;i<this.length;i++){hash[0]=((hash[0]<<5)-hash[0])+this.charCodeAt(i);}
return hash[0];}
function openURL(url){window.open(url,'_blank').focus();}
async function copyClip(text){try{await navigator.clipboard.writeText(text);showPopup(lang.clip_copy);}catch(e){showPopupError(lang.error);}}
function browser(){if(navigator.userAgent.includes("Opera")||navigator.userAgent.includes('OPR'))return'opera';else if(navigator.userAgent.includes("Edg"))return'edge';else if(navigator.userAgent.includes("Chrome"))return'chrome';else if(navigator.userAgent.includes("Safari"))return'safari';else if(navigator.userAgent.includes("Firefox"))return'firefox';else if((navigator.userAgent.includes("MSIE"))||(!!document.documentMode==true))return'IE';else return'unknown';}
function showNotif(name,text){if(!("Notification"in window)||Notification.permission!='granted')return;const descr=name+' ('+new Date(Date.now()).toLocaleString()+')';navigator.serviceWorker.getRegistration().then(function(reg){reg.showNotification(text,{body:descr,vibrate:true});}).catch(e=>console.log(e));}
function platform(){if('GyverHubDesktop'in window)return'desktop';if('flutter_inappwebview'in window)return'mobile';return'local';}
function getMaskList(){const list=[];for(let i=0;i<33;i++){let imask;if(i==32)imask=0xffffffff;else imask=~(0xffffffff>>>i);list.push(`${(imask >>> 24) & 0xff}.${(imask >>> 16) & 0xff}.${(imask >>> 8) & 0xff}.${imask & 0xff}`);}
return list;}
function getLocalIP(silent=true){const ip=window.location.hostname;if(checkIP(ip)){EL('local_ip').value=ip;hub.config.set('connections','HTTP','local_ip',ip);}else if(!silent){asyncAlert(lang.p_not_support);}}
function checkIP(ip){return Boolean(ip&&ip.match(/^((25[0-5]|(2[0-4]|1[0-9]|[1-9]|)[0-9])(\.(?!$)|$)){4}$/));}

function add_device(device,dev){let icon=dev.icon;if(icon.length)icon='';EL('devices').innerHTML+=`
<div class="device ${device.isConnected() ? '' : 'offline'}" id="device#${dev.id}" onclick="device_h('${dev.id}')" title="${dev.id} [${dev.prefix}]">
<div id="d_head#${dev.id}">
<div class="d_icon">
<span class="icon icon_min" id="icon#${dev.id}">${getIcon(icon) ?? ''}</span>
</div>
<div class="d_title">
<span class="d_name" id="name#${dev.id}">${dev.name}</span><sup class="conn_dev" id="SERIAL#${dev.id}">S</sup><sup class="conn_dev" id="BLE#${dev.id}">B</sup><sup class="conn_dev" id="HTTP#${dev.id}">W</sup><sup class="conn_dev" id="MQTT#${dev.id}">M</sup><sup class="conn_dev" id="TG#${dev.id}">T</sup>
</div>
</div>
<div id="d_cfg#${dev.id}" class="d_btn_cont">
<div class="icon d_btn_red" onclick="delete_h('${dev.id}');event.stopPropagation()"></div>
<div class="icon d_btn_green" onclick="dev_up_h('${dev.id}');event.stopPropagation()"></div>
<div class="icon d_btn_green" onclick="dev_down_h('${dev.id}');event.stopPropagation()"></div>
</div>
<span class="icon d_btn_cfg" onclick="dev_cfg_h('${dev.id}');event.stopPropagation()"></span>
</div>`;EL('d_head#'+dev.id).style.display=device.cfg_flag?'none':'flex';EL('d_cfg#'+dev.id).style.display=device.cfg_flag?'flex':'none';}
function render_devices(){EL('devices').replaceChildren();for(const id of hub.getDeviceIds()){const dev=hub.dev(id);add_device(dev,dev.info);for(let connection of dev.active_connections){display(`${connection.name}#${dev.info.id}`,'inline-block');}}}
function dev_cfg_h(id){const dev=hub.dev(id);dev.cfg_flag=!dev.cfg_flag;EL('d_head#'+id).style.display=dev.cfg_flag?'none':'flex';EL('d_cfg#'+id).style.display=dev.cfg_flag?'flex':'none';}
function errorBar(v){if(v)document.body.classList.add('connection-error');else document.body.classList.remove('connection-error');}
function spinArrows(val){if(val)EL('icon_refresh').classList.add('spinning');else EL('icon_refresh').classList.remove('spinning');}
function mq_change(opened){display('mq_start',opened?'none':'inline-block');display('mq_stop',opened?'inline-block':'none');display('mqtt_ok',opened?'block':'none');}
function bt_change(opened){display('bt_open',opened?'none':'inline-block');display('bt_close',opened?'inline-block':'none');display('bt_ok',opened?'block':'none');}
function serial_change(opened){display('serial_open',opened?'none':'inline-block');display('serial_close',opened?'inline-block':'none');display('serial_ok',opened?'block':'none');}
function tg_change(opened){display('tg_start',opened?'none':'inline-block');display('tg_stop',opened?'inline-block':'none');display('tg_ok',opened?'block':'none');}
function showInfo(info){function addInfo(el,label,value,title=''){EL(el).innerHTML+=`
<div class="ui_row info">
<label>${label}</label>
<label title="${title}" class="info_label">${value}</label>
</div>`;}
EL('info_version').replaceChildren();EL('info_net').replaceChildren();EL('info_memory').replaceChildren();EL('info_system').replaceChildren();for(const i in info.version)addInfo('info_version',i,info.version[i]);for(const i in info.net)addInfo('info_net',i,info.net[i]);for(const i in info.memory){if(typeof(info.memory[i])==='object'){const used=info.memory[i][0];const total=info.memory[i][1];let mem=(used/1024).toFixed(1)+' KiB';let title=used;if(total){mem+=' ['+(used/total*100).toFixed(0)+'%]';title+=' of '+total;}
addInfo('info_memory',i,mem,`Used ${title} bytes`);}else{addInfo('info_memory',i,info.memory[i]);}}
for(const i in info.system){if(i=='Uptime'){const sec=info.system[i];const upt=Math.floor(sec/86400)+':'+new Date(sec*1000).toISOString().slice(11,19);const d=new Date();const utc=d.getTime()-(d.getTimezoneOffset()*60000);addInfo('info_system',i,upt);addInfo('info_system','Started',new Date(utc-sec*1000).toISOString().split('.')[0].replace('T',' '));continue;}
addInfo('info_system',i,info.system[i]);}}
function renderBody(){document.body.innerHTML+=`
<div id="plugins"></div>
<div id="app_plugins"></div>
<div id="test_plugins"></div>
<div id="widget_styles"></div>
<div class="header-row">
<div class="header">
<div class="icon header-back" data-action="back"></div>
<div class="header-title" data-action="back">GyverHub</div>
<div id="conn" class="header-connection"></div>
<div id='bt_ok' class="icon header-connection-icon"></div>
<div id='mqtt_ok' class="icon header-connection-icon"></div>
<div id='serial_ok' class="icon header-connection-icon"></div>
<div id='tg_ok' class="icon header-connection-icon"></div>
<div class="header-connections"></div>
<div class="icon header-icon icon_refresh" id='icon_refresh' data-action="refresh"></div>
<div class="icon header-icon icon_cfg" data-action="config"></div>
<div class="icon header-icon icon_menu" id='icon_menu' data-action="menu"></div>
</div>
</div>
<div class="main">
<div id="menu_overlay" onclick="menu_show(0)"></div>
<div id="menu" class="main_col menu"></div>
<div class="main_inn">
<div class="main_col screen-plugins">
<div id="my_plugins"></div>
<div id="plugins_cont"></div>
</div>
<div class="main_col screen-test">
<div id="test_container" class=""></div>
<br>
<div class="ui_col">
<div class="ui_inpbtn_row">
<input id="test_controls" class="ui_inp ui_inp_wbtn" type="text" value="" placeholder='{"value":50}'>
<button onclick="testbuild_h()" class="ui_btn upl_btn">Build</button>
</div>
<div class="ui_inpbtn_row">
<input id="test_updates" class="ui_inp ui_inp_wbtn" type="text" value="" placeholder='{"value":50}'>
<button onclick="testupdate_h()" class="ui_btn upl_btn">Update</button>
</div>
<div class="ui_btn_row">
<label>Out:&nbsp</label><label id="test_out"></label>
</div>
</div>
<div class="ui_col">
<div class="ui_row test-tabs"><label>JS</label></div>
<div class="ui_row"><textarea id="test_js" rows="40" class="ui_inp ui_area ui_area_wrap"></textarea></div>
</div>
</div>
<div id="projects_cont" class="main_col screen-projects">
<div class="proj">
<div class="proj_name">
<a href="https://github.com/GyverLibs/GyverHub-projects" target="_blank">+ <slot name="lang.p_add_project"></slot></a>
</div>
</div>
</div>
<div id="devices" class="main_col screen-main"></div>
<div id="controls" class="main_col screen-ui"></div>
<div class="main_col screen-dev_config">
<div class="ui_col">
<div class="ui_row ui_head">
<label><span class="icon icon_ui"></span><slot name="lang.i_settings"></slot></label>
</div>
<div class="ui_row">
<label><slot name="lang.i_console"></slot></label>
<label class="switch"><input type="checkbox" id="info_cli_sw" onchange="showCLI(this.checked);save_cfg()">
<span class="slider"></span></label>
</div>
<div class="ui_row">
<label><slot name="lang.i_trust"></slot></label>
<label class="switch"><input type="checkbox" id="info_trust" onchange="trust_dev_h()">
<span class="slider"></span></label>
</div>
<div class="ui_row">
<label class="ui_label"><slot name="lang.i_main"></slot></label>
<div class="ui_inp_row">
<input class="ui_inp" type="text" id="main_width" onchange="ui_width_h(this)">
</div>
</div>
<hr>
<div class="ui_row">
<label class="ui_label"><slot name="lang.i_css"></slot></label>
<button class="icon icon_btn_big" onclick="ui_plugin_css_h()"></button>
</div>
<div class="ui_row">
<label class="ui_label"><slot name="lang.i_js"></slot></label>
<button class="icon icon_btn_big" onclick="ui_plugin_js_h()"></button>
</div>
<hr>
<div class="ui_btn_row">
<button id="reboot_btn" class="ui_btn ui_btn_mini" onclick="reboot_h()"><span class="icon icon_inline"></span><slot name="lang.i_reboot"></slot></button>
</div>
</div>
</div>
<div class="main_col screen-info">
<div class="ui_col" id="info_topics">
<div class="ui_row ui_head">
<label><span class="icon icon_ui"></span><slot name="lang.i_topics"></slot></label>
</div>
<div class="ui_row info">
<label>ID</label>
<label id="info_id" class="info_label info_label_small">-</label>
</div>
<div class="ui_row info">
<label>Set</label>
<label id="info_set" class="info_label info_label_small">-</label>
</div>
<div class="ui_row info">
<label>Read</label>
<label id="info_read" class="info_label info_label_small">-</label>
</div>
<div class="ui_row info">
<label>Get</label>
<label id="info_get" class="info_label info_label_small">-</label>
</div>
<div class="ui_row info">
<label>Status</label>
<label id="info_status" class="info_label info_label_small">-</label>
</div>
</div>
<div class="ui_col">
<div class="ui_row ui_head">
<label><span class="icon icon_ui"></span><slot name="lang.i_system"></slot></label>
</div>
<div id="info_system"></div>
</div>
<div class="ui_col">
<div class="ui_row ui_head">
<label><span class="icon icon_ui"></span><slot name="lang.i_net"></slot></label>
</div>
<div id="info_net"></div>
</div>
<div class="ui_col">
<div class="ui_row ui_head">
<label><span class="icon icon_ui"></span><slot name="lang.i_memory"></slot></label>
</div>
<div id="info_memory"></div>
</div>
<div class="ui_col">
<div class="ui_row ui_head">
<label><span class="icon icon_ui"></span><slot name="lang.i_version"></slot></label>
</div>
<div id="info_version"></div>
</div>
</div>
<div class="main_col screen-fsbr_edit">
<div class="ui_col">
<div class="ui_row ui_head">
<label><span class="icon icon_ui"></span>Editor</label>
</div>
<div class="ui_row">
<label id="edit_path"></label>
</div>
<div class="ui_row">
<label><slot name="lang.fs_wrap"></slot></label>
<label class="switch">
<input type="checkbox" id="editor_wrap" onchange="this.checked?editor_area.classList.remove('ui_area_wrap'):editor_area.classList.add('ui_area_wrap')">
<span class="slider"></span>
</label>
</div>
<div class="ui_row">
<textarea rows=20 id="editor_area" class="ui_inp ui_area ui_area_wrap"></textarea>
</div>
<div class="ui_row">
<button id="editor_save" onclick="editor_save()" class="ui_btn ui_btn_mini"><slot name="lang.fs_save"></slot></button>
<button onclick="editor_cancel()" class="ui_btn ui_btn_mini"><slot name="lang.cancel"></slot></button>
</div>
</div>
</div>
<div class="main_col screen-files">
<div class="ui_col">
<div class="ui_row ui_head">
<label><span class="icon icon_ui"></span><slot name="lang.fs_fsbr"></slot></label>
</div>
<div id="fs_browser">
<div id="fsbr_inner"></div>
<div class="ui_btn_row">
<button id="fs_format" onclick="format_h()" class="ui_btn ui_btn_mini"><slot name="lang.fs_format"></slot></button>
<button id="fs_create" onclick="create_h()" class="ui_btn ui_btn_mini"><slot name="lang.fs_create"></slot></button>
<button id="fs_upload" onclick="upload_h()" class="ui_btn ui_btn_mini"><slot name="lang.fs_upload"></slot></button>
</div>
</div>
</div>
</div>
<div class="main_col screen-ota">
<div class="ui_col">
<div class="ui_row ui_head">
<label><span class="icon icon_ui"></span>OTA FILE</label>
</div>
<div id="fs_otaf">
<div class="ui_row">
<div>
<input type="file" id="ota_upload" style="display:none" onchange="uploadOta(this.files[0], 'flash')">
<button onclick="ota_upload.click()" class="ui_btn ui_btn_mini drop_area" ondrop="uploadOta(event.dataTransfer.files[0], 'flash')">Flash</button>
<input type="file" id="ota_upload_fs" style="display:none" onchange="uploadOta(this.files[0], 'fs')">
<button onclick="ota_upload_fs.click()" class="ui_btn ui_btn_mini drop_area" ondrop="uploadOta(event.dataTransfer.files[0], 'fs')">Filesystem</button>
</div>
<label style="font-size:18px" id="ota_label"></label>
</div>
</div>
</div>
<div class="ui_col">
<div class="ui_row ui_head">
<label><span class="icon icon_ui"></span>OTA URL</label>
</div>
<div id="fs_otaurl">
<div class="ui_inpbtn_row">
<input class="ui_inp ui_inp_wbtn" type="text" id="ota_url_f">
<button id="ota_url_btn" onclick="otaUrl(ota_url_f.value,'flash')" class="ui_btn upl_btn">Flash</button>
</div>
<div class="ui_inpbtn_row">
<input class="ui_inp ui_inp_wbtn" type="text" id="ota_url_fs">
<button id="ota_url_btn" onclick="otaUrl(ota_url_fs.value,'fs')" class="ui_btn upl_btn">FS</button>
</div>
</div>
</div>
</div>
<div class="main_col screen-config">
<div class="ui_col">
<div class="ui_row ui_head ui_tab" onclick="use_local.click()">
<label class="ui_label ui_tab" id="local_label"><span class="icon icon_ui"></span>WiFi</label>
<input type="checkbox" id="use_local" data-hub-config="connections.HTTP.enabled" onchange="update_cfg(this);save_cfg()" style="display:none">
</div>
<div id="local_block" style="display:none">
<div class="ui_row" id="http_only_http" style="display:none">
<span style="color:#c60000">Works only on <strong class="span_btn" onclick="window.location.href = window.location.href.replace('https', 'http')">HTTP</strong>!</span>
</div>
<div id="http_settings">            
<div class="ui_row">
<label class="ui_label"><slot name="lang.wifi_ip"></slot></label>
<div class="ui_inp_row">
<input class="ui_inp" type="text" id="local_ip" data-hub-config="connections.HTTP.local_ip" onchange="update_cfg(this)">
<div class="btn_inp_block">
<button class="icon icon_btn" onclick="update_ip_h();update_cfg(EL('local_ip'))"></button>
</div>
</div>
</div>
<div class="ui_row">
<label><slot name="lang.wifi_mask"></slot></label>
<div class="ui_inp_row">
<select class="ui_inp ui_sel" id="netmask" data-hub-config="connections.HTTP.netmask" onchange="update_cfg(this)"></select>
</div>
</div>
<div class="ui_row">
<label><slot name="lang.wifi_port"></slot></label>
<div class="ui_inp_row"><input class="ui_inp" type="text" id="http_port" data-hub-config="connections.HTTP.port" onchange="update_cfg(this)">
</div>
</div>
<span class="notice_block">Disable:
<u><slot name="browser"></slot>://flags/#block-insecure-private-network-requests</u></span>
<hr>
<div class="ui_row">
<label class="ui_label"><slot name="lang.wifi_add"></slot></label>
<div class="ui_inp_row">
<input class="ui_inp" type="text" value="192.168.1.1" id="local_add_ip">
<div class="btn_inp_block">
<button class="icon icon_btn" onclick="manual_ip_h(local_add_ip.value)"></button>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="ui_col">
<div class="ui_row ui_head">
<label class="ui_label"><span class="icon icon_ui"></span><slot name="lang.cfg_search"></slot></label>
</div>
<div class="ui_row">
<label class="ui_label"><slot name="lang.cfg_prefix"></slot></label>
<div class="ui_inp_row">
<input class="ui_inp" type="text" id="prefix" data-hub-config="hub.prefix" onchange="update_cfg(this)">
</div>
</div>
<div class="ui_row">
<label class="ui_label"><slot name="lang.cfg_add"></slot></label>
<div class="ui_inp_row">
<input class="ui_inp" type="text" value="device_id" id="add_by_id">
<div class="btn_inp_block">
<button class="icon icon_btn" onclick="manual_id_h(add_by_id.value)"></button>
</div>
</div>
</div>
<hr>
<div class="ui_btn_row">
<button class="ui_btn ui_btn_mini" onclick="search()"><slot name="lang.cfg_find_dev"></slot></button>
</div>
</div>
<div class="ui_col">
<div class="ui_row ui_head">
<label class="ui_label"><span class="icon icon_ui"></span><slot name="lang.cfg_sett"></slot></label>
</div>
<div class="ui_row">
<label class="ui_label"><slot name="lang.cfg_id"></slot></label>
<div class="ui_inp_row">
<input class="ui_inp" type="text" id="client_id" data-hub-config="hub.client_id" onchange="update_cfg(this)" oninput="if(this.value.length>8)this.value=this.value.slice(0,-1)">
</div>
</div>
<div class="ui_row">
<label class="ui_label"><slot name="lang.cfg_theme"></slot></label>
<div class="ui_inp_row">
<select class="ui_inp ui_sel" id='theme' onchange="update_cfg(this)">
<option value="auto"></option>
<option value="dark"></option>
<option value="light"></option>
</select>
</div>
</div>
<div class="ui_row">
<label class="ui_label"><slot name="lang.cfg_color"></slot></label>
<div class="ui_inp_row">
<select class="ui_inp ui_sel" id='maincolor' onchange="update_cfg(this)">
<option value="ORANGE"></option>
<option value="YELLOW"></option>
<option value="GREEN"></option>
<option value="MINT"></option>
<option value="AQUA"></option>
<option value="BLUE"></option>
<option value="VIOLET"></option>
<option value="PINK"></option>
</select>
</div>
</div>
<div class="ui_row">
<label class="ui_label"><slot name="lang.cfg_font"></slot></label>
<div class="ui_inp_row">
<select class="ui_inp ui_sel" id='font' onchange="update_cfg(this)">
<option value="monospace">monospace</option>
<option value="system-ui">system-ui</option>
<option value="cursive">cursive</option>
<option value="Arial">Arial</option>
<option value="Verdana">Verdana</option>
<option value="Tahoma">Tahoma</option>
<option value="Trebuchet MS">Trebuchet MS</option>
<option value="Georgia">Georgia</option>
<option value="Garamond">Garamond</option>
</select>
</div>
</div>
<div class="ui_row">
<label class="ui_label">Language</label>
<div class="ui_inp_row">
<select class="ui_inp ui_sel" id='lang' onchange="update_cfg(this);save_cfg();location.reload()">
<option value="English">English</option>
<option value="Russian">Russian</option>
</select>
</div>
</div>
<div class="ui_row">
<label class="ui_label"><slot name="lang.cfg_width"></slot></label>
<div class="ui_inp_row">
<input class="ui_inp" type="text" id="ui_width" onchange="update_cfg(this)">
</div>
</div>
<hr>
<div class="ui_row">
<label><slot name="lang.cfg_wide_mode"></slot></label>
<label class="switch"><input type="checkbox" id="wide_mode" onchange="update_cfg(this)"><span class="slider"></span></label>
</div>
<div class="ui_row">
<label><slot name="lang.cfg_updates"></slot></label>
<label class="switch"><input type="checkbox" id="check_upd" onchange="update_cfg(this)"><span class="slider"></span></label>
</div>
<hr>
<div class="ui_row">
<label class="ui_label"><slot name="lang.cfg_css"></slot></label>
<button class="icon icon_btn_big" onclick="app_plugin_css()"></button>
</div>
<div class="ui_row">
<label class="ui_label"><slot name="lang.cfg_js"></slot></label>
<button class="icon icon_btn_big" onclick="app_plugin_js()"></button>
</div>
<div class="ui_row">
<label class="ui_label"><slot name="lang.cfg_proj"></slot></label>
<button class="icon icon_btn_big" onclick="project_links()"></button>
</div>
<div class="ui_row">
<label class="ui_label"><slot name="lang.cfg_plugin"></slot></label>
<button class="icon icon_btn_big" onclick="plugin_links()"></button>
</div>
<hr>
<div class="ui_btn_row">
<button class="ui_btn ui_btn_mini" onclick="cfg_export()"><slot name="lang.cfg_export"></slot></button>
<button class="ui_btn ui_btn_mini" onclick="cfg_import()"><slot name="lang.cfg_import"></slot></button>
<button class="ui_btn ui_btn_mini" onclick="cfg_reset()"><slot name="lang.cfg_reset"></slot></button>
</div>
</div>
<div class="ui_col">
<div class="ui_row ui_head ui_tab" onclick="use_pin.click()">
<label id="pin_label" class="ui_label ui_tab"><span class="icon icon_ui"></span>PIN</label>
<input type="checkbox" id="use_pin" onchange="update_cfg(this)" style="display:none">
</div>
<div id="pin_block" style="display:none">
<div class="ui_row">
<label class="ui_label">PIN</label>
<div class="ui_inp_row"><input class="ui_inp" type="password" pattern="[0-9]*" inputmode="numeric" id="pin" onchange="make_pin(this);update_cfg(this)" oninput="check_type(this)">
</div>
</div>
</div>
</div>
<div class="ui_col">
<div class="cfg_info" id="hub_stat">GyverHub vdev esp</div>
<hr>
<div class="cfg_info">
<a href="https://fontawesome.com/v5/search?o=r&m=free&s=solid" target="_blank">Fontawesome</a>
<a href="https://github.com/Simonwep/pickr" target="_blank">Pickr</a>
<a href="https://github.com/mqttjs/MQTT.js" target="_blank">MQTT.js</a>
<a href="https://github.com/ghornich/sort-paths" target="_blank">sort-paths.js</a>
<a href="https://github.com/loginov-rocks/Web-Bluetooth-Terminal" target="_blank">Bluetooth Terminal</a>
<a href="https://github.com/davidshimjs/qrcodejs" target="_blank">QRCode.js</a>
<a href="https://esphome.github.io/esp-web-tools/" target="_blank">ESP Web Tools</a>
<a href="https://leafletjs.com/" target="_blank">Leaflet.js</a>
</div>
</div>
</div>
</div>
</div>
<div class="cli" id="cli_cont">
<div class="cli_block">
<div class="cli_area" id="cli"></div>
<div class="cli_row">
<span class="icon cli_icon"></span>
<input type="text" class="ui_inp cli_inp" id="cli_input" onkeydown="checkCLI(event)">
<button class="icon icon_btn cli_icon cli_enter" onclick="sendCLI()"></button>
</div>
</div>
</div>
<div class="footer">
<a href="https://alexgyver.ru/support_alex/" target="_blank"><span class="icon i_footer" title="Support"></span></a>
<a style="cursor:pointer" data-action="show_screen" data-screen="projects"><span class="icon i_footer" title="Projects"></span></a>
<a style="cursor:pointer" data-action="show_screen" data-screen="plugins"><span class="icon i_footer" title="Plugins"></span></a>
<a style="cursor:pointer" data-action="show_screen" data-screen="test"><span class="icon i_footer" title="Plugin Test"></span></a>
<a href="https://github.com/GyverLibs/GyverHub/wiki" target="_blank"><span class="icon i_footer" title="Wiki"></span></a>
</div>
`;let masks=getMaskList();for(let mask in masks){EL('netmask').innerHTML+=`<option value="${mask}">${masks[mask]}</option>`;}}
let cfg_changed=false;let cfg={serial_offset:2000,use_pin:false,pin:'',theme:'auto',maincolor:'GREEN',font:'monospace',check_upd:true,ui_width:480,wide_mode:false,lang:userLang(),app_plugin_css:'',app_plugin_js:'',project_links:'',plugin_links:'',api_ver:2,};if(localStorage.hasOwnProperty('app_config')){const cfg_r=JSON.parse(localStorage.getItem('app_config'));if(cfg.api_ver===cfg_r.api_ver){cfg=cfg_r;}else{localStorage.clear();location.reload();}}
localStorage.setItem('app_config',JSON.stringify(cfg));let lang=langBase[cfg.lang];function update_cfg(el){if(el.type=='text')el.value=el.value.trim();const val=(el.type=='checkbox')?el.checked:el.value;if(el.id in cfg)cfg[el.id]=val;else if(el.dataset.hubConfig){if(el.dataset.hubConfig==='connections.HTTP.local_ip'&&!checkIP(val)){asyncAlert(lang.wrong_ip);return;}
hub.config.set(...el.dataset.hubConfig.split('.'),val);}
cfg_changed=true;update_theme();}
function save_cfg(){if(cfg.pin.length<4)cfg.use_pin=false;localStorage.setItem('app_config',JSON.stringify(cfg));localStorage.setItem('hub_config',hub.config.toJson());}
async function app_plugin_css(){const res=await asyncPromptArea(lang.cfg_css,cfg.app_plugin_css);if(res!==null){cfg.app_plugin_css=res;save_cfg();update_theme();}}
async function app_plugin_js(){const res=await asyncPromptArea(lang.cfg_js,cfg.app_plugin_js);if(res!==null){cfg.app_plugin_js=res;save_cfg();update_theme();}}
async function project_links(){const res=await asyncPromptArea(lang.cfg_proj,cfg.project_links);if(res!==null){cfg.project_links=res;save_cfg();}}
async function plugin_links(){const res=await asyncPromptArea(lang.cfg_plugin,cfg.plugin_links);if(res!==null){cfg.plugin_links=res;save_cfg();}}
function update_theme(){document.body.classList.remove('theme-dark','theme-light','theme-auto');document.body.classList.add('theme-'+cfg.theme.toLowerCase());const r=document.querySelector(':root');r.style.setProperty('--ui_width',cfg.ui_width+'px');r.style.setProperty('--prim',hexToCol(colors[cfg.maincolor]));r.style.setProperty('--font_f',cfg.font);EL('app_plugins').replaceChildren();addDOM('app_css','style',cfg.app_plugin_css,EL('app_plugins'));addDOM('app_js','script',cfg.app_plugin_js,EL('app_plugins'));display('local_block',hub.config.get('connections','HTTP','enabled')?'block':'none');EL('local_label').style.color=hub.config.get('connections','HTTP','enabled')?'var(--font)':'var(--font3)';display('pin_block',cfg.use_pin?'block':'none');EL('pin_label').style.color=cfg.use_pin?'var(--font)':'var(--font3)';}
function cfg_export(){const config={app_config:cfg,hub_config:hub.config.toJson(),};const $a=document.createElement('a');$a.href="data:text/json;charset=utf-8,"+encodeURIComponent(JSON.stringify(config));$a.download="GyverHub-config-export.json";document.body.appendChild($a);$a.click();$a.remove();}
function cfg_import(){const $in=document.createElement('input');$in.type='file';$in.accept=".json,application/json";$in.addEventListener("change",async()=>{const file=$in.files[0];try{const ab=await readFileAsArrayBuffer(file);const text=new TextDecoder().decode(ab);const data=JSON.parse(text);cfg=data.app_config;hub.config.fromJson(data.hub_config);}catch(e){console.log(e);showPopupError(lang.import_err);return;}
save_cfg();showPopup(lang.import_ok);setTimeout(()=>location.reload(),500);});$in.click();}
async function cfg_reset(){if(await asyncConfirm(lang.cfg_reset_conf)){localStorage.clear();setTimeout(()=>location.reload(),500);}}



let menu_f=false;let pin_id=null;let screen='main';let focused=null;async function show_screen(nscreen){spinArrows(false);screen=nscreen;document.body.dataset.screen=screen;const $title=document.getElementsByClassName('header-title')[0];const dev=hub.dev(focused);if(dev)dev.fsStop();switch(screen){case'main':$title.textContent="GyverHub";showCLI(false);break;case'test':$title.textContent=lang.plugin_test;break;case'projects':$title.textContent=lang.p_projects;loadProjects();break;case'plugins':$title.textContent=lang.plugins;loadPlugins();break;case'ui':$title.textContent=dev.info.name;EL('controls').replaceChildren();break;case'config':$title.textContent=lang.config;break;case'info':$title.textContent=dev.info.name+'/info';enterMenu('menu_info');await show_info();break;case'files':$title.textContent=dev.info.name+'/fs';EL('fs_upload').textContent=lang.fs_upload;enterMenu('menu_fsbr');display('fs_browser',dev.isModuleEnabled(Modules.FILES)?'block':'none');display('fs_upload',dev.isModuleEnabled(Modules.UPLOAD)?'block':'none');display('fs_create',dev.isModuleEnabled(Modules.CREATE)?'block':'none');display('fs_format',dev.isModuleEnabled(Modules.FORMAT)?'flex':'none');if(dev.isModuleEnabled(Modules.FILES)){EL('fsbr_inner').innerHTML=waiter();await dev.updateFileList();}
break;case'fsbr_edit':$title.textContent=dev.info.name+'/fs';enterMenu('menu_fsbr');break;case'ota':$title.textContent=dev.info.name+'/ota';enterMenu('menu_ota');const ota_t='.'+dev.info.ota_t;EL('ota_upload').accept=ota_t;EL('ota_upload_fs').accept=ota_t;EL('ota_url_f').value="http://flash"+ota_t;EL('ota_url_fs').value="http://filesystem"+ota_t;display('fs_otaf',dev.isModuleEnabled(Modules.OTA)?'block':'none');display('fs_otaurl',dev.isModuleEnabled(Modules.OTA_URL)?'block':'none');break;case'dev_config':$title.textContent=dev.info.name+'/cfg';enterMenu('menu_cfg');show_cfg();break;}}
function show_cfg(){const dev=hub.dev(focused);EL('main_width').value=dev.info.main_width;EL('info_cli_sw').checked=document.body.classList.contains('show-cli');EL('info_trust').checked=dev.info.trust;}
async function show_info(){const dev=hub.dev(focused);EL('info_id').textContent=focused;EL('info_set').textContent=dev.info.prefix+'/'+focused+'/ID/set/*';EL('info_read').textContent=dev.info.prefix+'/'+focused+'/ID/read/*';EL('info_get').textContent=dev.info.prefix+'/hub/'+focused+'/get/*';EL('info_status').textContent=dev.info.prefix+'/hub/'+focused+'/status';display('reboot_btn',dev.isModuleEnabled(Modules.REBOOT)?'block':'none');display('info_topics',dev.isModuleEnabled(Modules.MQTT)?'block':'none');EL('info_version').replaceChildren();EL('info_net').replaceChildren();EL('info_memory').replaceChildren();EL('info_system').replaceChildren();if(dev.isModuleEnabled(Modules.INFO)){const info=await dev.getInfo();if(info)showInfo(info);}}
async function refresh_h(){if(!focused){discover();return}
const dev=hub.dev(focused);switch(screen){case"ui":await dev.updateUi();break;case"files":await dev.updateFileList();break;case"info":const info=await dev.getInfo();if(info)showInfo(info);break;}}
async function back_h(){if(focused){const dev=hub.dev(focused);dev.fsStop();}
if(menu_f){menu_show(false);return;}
switch(screen){case'ui':close_device();break;case'dev_config':case'info':case'files':case'ota':enterMenu();show_screen('ui');hub.dev(focused).updateUi();break;case'fsbr_edit':show_screen('files');break;case'config':config_h();break;default:show_screen('main');break;}}
function config_h(){if(screen=='config'){show_screen('main');if(cfg_changed){save_cfg();discover();}
cfg_changed=false;}else{show_screen('config');}}
async function manual_ip_h(ip){let device;try{device=await hub.http.discover_ip(ip);}catch(e){showPopupError(getError(e));return;}
save_cfg();show_screen('main');if(device)device_h(device.info.id);}
async function manual_id_h(id){show_screen('main');await hub.add(id);}
function update_ip_h(){getLocalIP(false);}
function menu_h(){menu_show(!menu_f);}
function devlink_h(){copyClip(devLink());}
function qr_h(){}
function devLink(){let qs=window.location.origin+window.location.pathname+'?';const info=hub.dev(focused).info;["id","prefix","ip","http_port"].forEach(x=>{if(info[x])qs+=`${x}=${info[x]}&`;});return qs.slice(0,-1);}
function ui_width_h(el){hub.dev(focused).info.main_width=el.value;}
async function ui_plugin_css_h(){const res=await asyncPromptArea(lang.i_css,hub.dev(focused).info.plugin_css);if(res!==null){hub.dev(focused).info.plugin_css=res;addDOM('device_css','style',res,EL('plugins'));}}
async function ui_plugin_js_h(){const res=await asyncPromptArea(lang.i_js,hub.dev(focused).info.plugin_js);if(res!==null){hub.dev(focused).info.plugin_js=res;addDOM('device_js','script',res,EL('plugins'));}}
function menu_show(state){menu_f=state;const cl=EL('menu').classList;if(menu_f)cl.add('menu_show');else cl.remove('menu_show');EL('icon_menu').textContent=menu_f?'':'';display('menu_overlay',menu_f?'block':'none');}
function updateSystemMenu(){const dev=hub.dev(focused);EL('menu').append(makeDOM(null,{tag:'div',class:"menu_item menu_cfg",text:lang.m_config,events:{click:()=>show_screen('dev_config')}}));EL('menu').append(makeDOM(null,{tag:'div',class:"menu_item menu_info",text:lang.m_info,events:{click:()=>show_screen('info')}}));if(dev.isModuleEnabled(Modules.FILES)){EL('menu').append(makeDOM(null,{tag:'div',class:"menu_item menu_fsbr",text:lang.m_files,events:{click:()=>show_screen('files')}}));}
if(dev.isModuleEnabled(Modules.OTA)||dev.isModuleEnabled(Modules.OTA_URL)){EL('menu').append(makeDOM(null,{tag:'div',class:"menu_item menu_ota",text:lang.m_ota,events:{click:()=>show_screen('ota')}}));}}
function enterMenu(sel=null){menu_show(false);for(const $i of EL('menu').children)
$i.classList.remove('menu_act');if(sel!==null)
document.querySelector('.menu_item.'+sel).classList.add('menu_act');}
async function device_h(id){const dev=hub.dev(id);if(!dev||!dev.isConnected())return;if(!dev.info.api_v||dev.info.api_v!=GyverHub.api_v)asyncAlert(lang.api_mis);if(dev.info.pin&&!dev.granted){if(!await asyncAskPin(lang.dev_pin+dev.info.name,dev.info.pin,true)){return false;}
dev.granted=true;}
focused=id;EL('menu').replaceChildren();updateSystemMenu();EL('conn').textContent=dev.getConnection().name;addDOM('device_css','style',dev.info.plugin_css,EL('plugins'));addDOM('device_js','script',dev.info.plugin_js,EL('plugins'));show_screen('ui');dev.focus();}
function close_device(){if(renderer)renderer.close();renderer=null;const $root=EL('controls');$root.replaceChildren();EL('plugins').replaceChildren();EL('ota_label').replaceChildren();errorBar(false);hub.dev(focused).unfocus();focused=null;show_screen('main');}
async function delete_h(id){if(await asyncConfirm(lang.delete+' '+id+'?')){hub.deleteDevice(id);EL(`device#${id}`).remove();}}
function dev_up_h(id){hub.moveDevice(id,-1);render_devices();}
function dev_down_h(id){hub.moveDevice(id,1);render_devices();}
async function trust_dev_h(){const v=EL('info_trust').checked;if(v&&!await asyncConfirm(lang.dev_trust_warning)){EL('info_trust').checked=false;return;}
hub.dev(focused).info.trust=v;}
function showCLI(v){if(v)document.body.classList.add('show-cli');else document.body.classList.remove('show-cli');if(v)EL('cli_input').focus();EL('info_cli_sw').checked=v;}
function printCLI(text,color){if(document.body.classList.contains('show-cli')){if(EL('cli').innerHTML)EL('cli').innerHTML+='\n';EL('cli').innerHTML+=`<span style="color:${hexToCol(color, 'var(--font2)')}">${text}</span>`;EL('cli').scrollTop=EL('cli').scrollHeight;}}
function toggleCLI(){EL('cli').replaceChildren();EL('cli_input').value="";showCLI(!document.body.classList.contains('show-cli'));}
function checkCLI(event){if(event.key=='Enter')sendCLI();}
async function sendCLI(){await hub.dev(focused).sendCli(EL('cli_input').value);EL('cli').innerHTML+="\n>"+EL('cli_input').value;EL('cli').scrollTop=EL('cli').scrollHeight;EL('cli_input').value="";}
function make_pin(arg){if(arg.value.length>=4)arg.value=arg.value.hashCode();else arg.value='';}
function check_type(arg){if(arg.value.length>0){let c=arg.value[arg.value.length-1];if(c<'0'||c>'9')arg.value=arg.value.slice(0,-1);}}
async function reboot_h(){if(await asyncConfirm(lang.i_reboot+'?')){await hub.dev(focused).reboot();}}
let renderer;function showControls(device,controls){if(!renderer){renderer=new Renderer(device);renderer.addEventListener('menuchanged',()=>{updateSystemMenu();});renderer.addEventListener('menuopen',()=>{try{device.fsStop();}catch(e){}
enterMenu();if(screen!='ui')show_screen('ui');});}
renderer.update(controls);const $root=EL('controls');$root.style.setProperty('--device-width',device.info.main_width+'px');if(cfg.wide_mode)$root.classList.add('wide-mode');else $root.classList.remove('wide-mode');$root.replaceChildren(...renderer.build());}
class TestDevice{async set(name,value){EL('test_out').innerHTML=value;}};let testWidgets=new Map();let testDevice=new TestDevice();let testRenderer=new Renderer(testDevice,testWidgets);async function testbuild_h(){let wtype=Renderer.registerPlugin(EL('test_js').value,testWidgets);if(!wtype)return;let json;try{json=JSON.parse(EL('test_controls').value);}catch(e){return;}
let controls=Object.assign({id:'test',type:wtype},json);testRenderer.update([controls]);let cont=EL('test_container');cont.replaceChildren(...testRenderer.build());let config={controls:EL('test_controls').value,updates:EL('test_updates').value,plugin:EL('test_js').value,};localStorage.setItem('test_config',JSON.stringify(config));}
function testupdate_h(){let updates;try{updates=JSON.parse(EL('test_updates').value);}catch(e){return;}
for(let upd in updates){let obj={};obj[upd]=updates[upd];testRenderer.handleUpdate('test',obj);}}
let fs_arr=[];function showFsbr(device,fs,total,used){fs_arr=[];for(const path in fs)fs_arr.push(path);fs_arr=sortPaths(fs_arr,'/');let inner='';for(const i in fs_arr){if(fs_arr[i].endsWith('/')){inner+=`<div class="fs_file fs_folder drop_area" onclick="upload_h('${fs_arr[i]}')" ondrop="upload_file(event.dataTransfer.files[0],'${fs_arr[i]}')">${fs_arr[i]}</div>`;}else{const none="style='display:none'";inner+=`<div class="fs_file" onclick="openFSctrl(${i})">${fs_arr[i]}<div class="fs_weight">${(fs[fs_arr[i]] / 1000).toFixed(2)} kB</div></div>
<div id="fs#${i}" class="fs_controls">
<button ${device.isModuleEnabled(Modules.RENAME) ? '' : none} title="${lang.rename}" class="icon icon_btn_big" onclick="renameFile(${i})"></button>
<button ${device.isModuleEnabled(Modules.DELETE) ? '' : none} title="${lang.delete}" class="icon icon_btn_big" onclick="deleteFile(${i})"></button>
<button ${device.isModuleEnabled(Modules.FETCH) ? '' : none} title="${lang.fetch}" class="icon icon_btn_big" onclick="fetchFile(${i},'${fs_arr[i]}')"></button>
<label id="process#${i}"></label>
<a id="download#${i}" title="${lang.download}" class="icon icon_btn_big" href="" download="" style="display:none"></a>
<button id="open#${i}" title="${lang.open}" class="icon icon_btn_big" onclick="openFile(EL('download#${i}').href)" style="display:none"></button>
<button ${device.isModuleEnabled(Modules.UPLOAD) ? '' : none} id="edit#${i}" title="${lang.edit}" class="icon icon_btn_big" onclick="editFile(EL('download#${i}').href,${i})" style="display:none"></button>
</div>`;}}
if(total){inner+=`<div class="fs_info" style="background-image:linear-gradient(90deg,var(--prim) ${used / total * 100}%, var(--back) 0%);">${lang.fs_used} ${(used / 1000).toFixed(2)}/${(total / 1000).toFixed(2)} kB [${Math.round(used / total * 100)}%]</div>`;}else{inner+=`<div class="fs_info">${lang.fs_used} ${(used / 1000).toFixed(2)} kB</div>`;}
EL('fsbr_inner').innerHTML=inner;}
function openFSctrl(i){const current=EL(`fs#${i}`).style.display=='flex';document.querySelectorAll('.fs_controls').forEach(el=>el.style.display='none');if(!current)display(`fs#${i}`,'flex');}
function upload_h(dirname='/'){const $in=document.createElement('input');$in.type='file';$in.addEventListener('change',async()=>{upload_file($in.files[0],dirname);});$in.click();}
async function upload_file(file,dirname='/'){if(!dirname.endsWith('/'))dirname+='/';const path=await asyncPrompt(lang.fs_name,dirname+file.name,lang.fs_upload);if(!path)return;uploadFile(file,path);}
function openFile(src){let w=window.open();src=w.document.write('<iframe src="'+src+'" frameborder="0" style="border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;" allowfullscreen></iframe>');}
async function uploadFile(file,path){if(!path.startsWith('/'))path='/'+path;EL('fs_upload').innerHTML=waiter(22,'var(--font_inv)',false);try{await hub.dev(focused).upload(file,path,perc=>{showPopup(lang.upload+'... '+perc+'%');});}catch(e){EL('fs_upload').textContent=lang.fs_upload;showPopupError(`[${lang.upload}] `+getError(e));return;}
EL('fs_upload').textContent=lang.fs_upload;showPopup(`[${lang.upload}] `+lang.done);}
async function fetchFile(index,path){display('download#'+index,'none');display('edit#'+index,'none');display('process#'+index,'unset');EL('process#'+index).replaceChildren();let data;try{data=await hub.dev(focused).fetch(path,'url',perc=>{EL('process#'+index).textContent=perc+'%';});}catch(e){showPopupError(`[${lang.fetch}] `+getError(e));EL('process#'+index).textContent=lang.error;return;}
display('download#'+index,'inline-block');const name=path.split('/').pop();EL('download#'+index).href=data;EL('download#'+index).download=name;display('edit#'+index,'inline-block');if(platform()!='mobile')display('open#'+index,'inline-block');display('process#'+index,'none');}
async function format_h(){if(!await asyncConfirm(lang.fs_format+'?'))return;try{await hub.dev(focused).formatFS();}catch(e){showPopupError('[FS] '+getError(e));}}
async function create_h(){const path=await asyncPrompt(lang.fs_name,'/',lang.fs_create_f);if(!path)return;if(path[0]!='/')path='/'+path;try{await hub.dev(focused).createFile(path);}catch(e){showPopupError('[FS] '+getError(e));}}
async function deleteFile(i){if(!await asyncConfirm(lang.delete+' '+fs_arr[i]+'?'))return;try{await hub.dev(focused).deleteFile(fs_arr[i]);}catch(e){showPopupError('[FS] '+getError(e));}}
async function renameFile(i){const path=fs_arr[i];const res=await asyncPrompt(lang.rename+' '+path+':',path);if(!res||res==path)return;try{await hub.dev(focused).renameFile(path,res);}catch(e){showPopupError('[FS] '+getError(e));}}
let edit_idx=0;function editFile(data,idx){EL('editor_area').value=dataTotext(data);EL('editor_area').scrollTop=0;EL('edit_path').textContent=fs_arr[idx];show_screen('fsbr_edit');edit_idx=idx;}
function editor_cancel(){show_screen('files');}
function editor_save(){editor_cancel();const div=fs_arr[edit_idx].lastIndexOf('/');const name=fs_arr[edit_idx].slice(div+1);uploadFile(new File([EL('editor_area').value],name,{type:getMime(name),lastModified:new Date()}),fs_arr[edit_idx]);}
const updates_list=[];async function getUpdateInfo(dev){if(updates_list.includes(dev.info.id))return;const ver=dev.info.version;if(!ver||!ver.includes('@'))return;const namever=ver.split('@',2);let proj;try{const resp=await fetch("https://raw.githubusercontent.com/"+namever[0]+"/main/project.json",{cache:"no-store"});proj=await resp.json();}catch(e){return;}
if(!('builds'in proj)||!('version'in proj)||proj.version===namever[1])return;updates_list.push(dev.info.id);const platform=dev.info.platform;for(const build of proj.builds){if(build.chipFamily===platform)
return{name:namever[0],version:proj.version,notes:proj.notes,url:build.parts[0].path,};{const text=`${namever[0]} v${proj.version}:\n${proj.notes}\n\n${lang.p_upd}?`;if(await asyncConfirm(text,lang.p_has_upd+'!'))otaUrl(build.parts[0].path,'flash');break;}}}
async function installOta(dev,type,url){showPopup('OTA start');try{await dev.otaUrl(type,url);}catch(e){showPopupError('[OTA url] '+getError(e));return;}
showPopup('[OTA] '+lang.done);}
async function checkUpdates(dev){if(!cfg.check_upd)return;const upd=await getUpdateInfo(dev);if(!upd)return;const text=`${upd.name} v${upd.version}:\n${upd.notes}\n\n${lang.p_upd}?`;if(!await asyncConfirm(text,lang.p_has_upd+'!'))return;await installOta(dev,'flash',upd.url);}
async function otaUrl(url,type){if(!await asyncConfirm(lang.fs_upload+' OTA?'))
return;await installOta(hub.dev(focused),type,url);}
async function uploadOta(file,type){const dev=hub.dev(focused);if(!file.name.endsWith(dev.info.ota_t)){asyncAlert(lang.wrong_ota+' .'+dev.info.ota_t);return;}
const res=await asyncConfirm(lang.fs_upload+' OTA '+type+'?');if(!res)return;EL('ota_label').innerHTML=waiter(25,'var(--font)',false);EL('ota_upload').value='';EL('ota_upload_fs').value='';try{await dev.uploadOta(file,type,perc=>{EL('ota_label').textContent=perc+'%';});}catch(e){showPopupError('[OTA] '+getError(e));EL('ota_label').textContent=lang.error;return;}
showPopup('[OTA] '+lang.done);EL('ota_label').textContent=lang.done;}
document.addEventListener('DOMContentLoaded',async()=>{if(!localStorage.hasOwnProperty('hub_config')){localStorage.setItem('hub_config',hub.config.toJson());}
renderBody();apply_cfg();render_main();registerWidgets();if(localStorage.hasOwnProperty('test_config')){let data=JSON.parse(localStorage.getItem('test_config'));EL('test_controls').value=data.controls;EL('test_updates').value=data.updates;EL('test_js').value=data.plugin;}
document.addEventListener('click',e=>{const $t=e.composedPath().find(e=>e.dataset&&e.dataset.action);if(!$t)return;switch($t.dataset.action){case"show_screen":show_screen($t.dataset.screen);break;case"back":back_h();break;case"refresh":refresh_h();break;case"config":config_h();break;case"menu":menu_h();break;}});let force=1;if(force)hub.config.set('connections','HTTP','enabled',true);update_theme();set_drop();key_change();handle_back();register_SW();getLocalIP();const qs=window.location.search;if(qs){const params=new URLSearchParams(qs).entries();const data={};for(const param of params)data[param[0]]=param[1];if(!hub.dev(data.id))hub.addDevice(data);}
if(cfg.use_pin&&cfg.pin.length)await asyncAskPin(lang.hub_pin,cfg.pin,false);const ver=localStorage.getItem('version');const app_version='dev';if(!ver||ver!=app_version){localStorage.setItem('version',app_version);setTimeout(()=>{asyncAlert(lang.i_version+' '+app_version+'!\n'+'');},1000);}
if('Notification'in window&&Notification.permission=='default')Notification.requestPermission();show_screen('main');render_devices();hub.begin();await discover();function render_main(){const slots=document.getElementsByTagName('slot');while(slots.length){const i=slots[0];const p=i.name.split('.');const n=p.shift();let v='';if(n==='lang'){v=lang;for(const i of p)
v=v[i]??"";}
if(n==='browser')
v=browser();if(n==='location')
v=location.href;i.replaceWith(v);}
for(const i of EL('maincolor').children){i.text=lang.colors[i.value];}
for(const i of EL('theme').children){i.text=lang.themes[i.value];}}
function register_SW(){}
function set_drop(){function preventDrop(e){e.preventDefault()
e.stopPropagation()}
['dragenter','dragover','dragleave','drop'].forEach(e=>{document.body.addEventListener(e,preventDrop,false);});['dragenter','dragover'].forEach(e=>{document.body.addEventListener(e,function(){document.querySelectorAll('.drop_area').forEach((el)=>{el.classList.add('active');});},false);});['dragleave','drop'].forEach(e=>{document.body.addEventListener(e,function(){document.querySelectorAll('.drop_area').forEach((el)=>{el.classList.remove('active');});},false);});}
function key_change(){document.addEventListener('keydown',function(e){switch(e.keyCode){case 116:if(!e.ctrlKey){e.preventDefault();refresh_h();}
break;case 192:if(e.ctrlKey&&focused){e.preventDefault();toggleCLI();}
break;default:break;}});}
function handle_back(){window.history.pushState({page:1},"","");window.onpopstate=function(e){window.history.pushState({page:1},"","");back_h();}}
function apply_cfg(){if(cfg.pin.length<4)cfg.use_pin=false;for(const key in cfg){const el=EL(key);if(el==undefined)continue;if(el.type=='checkbox')el.checked=cfg[key];else el.value=cfg[key];}
for(const el of document.querySelectorAll('[data-hub-config]')){const value=hub.config.get(...el.dataset.hubConfig.split('.'));if(el.type=='checkbox')el.checked=value;else el.value=value;}}});async function discover(){spinArrows(true);for(const id of hub.getDeviceIds()){EL(`device#${id}`).className="device offline";display(`SERIAL#${id}`,'none');display(`BLE#${id}`,'none');display(`HTTP#${id}`,'none');display(`MQTT#${id}`,'none');}
let dis_local=1;if(dis_local){let device;try{device=await hub.http.discover_ip(window.location.hostname,window.location.port.length?window.location.port:80);}catch(e){showPopupError(getError(e));return;}
if(device)device_h(device.info.id);}}
function search(){if(cfg_changed){save_cfg();}
cfg_changed=false;show_screen('main');spinArrows(true);hub.search();}
const hub=new GyverHub();hub.addConnection(HTTPConnection);if(localStorage.hasOwnProperty('hub_config')){hub.config.fromJson(localStorage.getItem('hub_config'));}
hub.config.addEventListener('changed.devices',()=>{save_cfg();});hub.addEventListener('deviceadded',(ev)=>{const dev=ev.device.info;dev.main_width=450;dev.plugin_css='';dev.plugin_js='';add_device(ev.device,dev);});hub.addEventListener('devicecreated',ev=>{ev.device.addEventListener('transferstart',e=>{if(screen!=='main'&&e.device.info.id===focused)
spinArrows(true);});ev.device.addEventListener('transferend',e=>{if(screen!=='main'&&e.device.info.id===focused)
spinArrows(false);});ev.device.addEventListener('connectionchanged',e=>{for(const $i of document.querySelectorAll('.conn_dev'))
$i.style.display='';const conn=e.device.getConnection()?.name;EL(`device#${e.device.info.id}`).className=conn?"device":'device offline';if(conn&&conn!=='WS')
display(`${conn}#${e.device.info.id}`,'inline-block');if(e.device.info.id==focused)
EL('conn').textContent=conn??'';});ev.device.addEventListener('command.alert',e=>{asyncAlert(e.device.info.name+': '+e.data.text);});ev.device.addEventListener('command.notice',e=>{showPopup(e.device.info.name+': '+e.data.text,hexToCol(e.data.color));});let push_timer=0;ev.device.addEventListener('command.push',e=>{let date=(new Date).getTime();if(date-push_timer>3000){push_timer=date;showNotif(e.device.info.name+': ',e.data.text);}});ev.device.addEventListener('command.print',e=>{if(e.device.info.id==focused)
printCLI(e.data.text,e.data.color);});ev.device.addEventListener('command.files',e=>{if(e.device.info.id==focused)
showFsbr(e.device,e.data.fs,e.data.total,e.data.used);});ev.device.addEventListener('command.ui',e=>{if(e.device.info.id==focused&&e.data.controls)
showControls(e.device,e.data.controls);});ev.device.addEventListener('command.script',e=>{if(e.device.info.trust)
eval(e.data.script);else
showPopupError('Script from device was blocked!');});ev.device.addEventListener('command.fs_err',()=>{if(e.device.info.id==focused)
EL('fsbr_inner').innerHTML=`<div class="fs_err">FS ${lang.error}</div>`;});ev.device.addEventListener('error',e=>{if(e.device.info.id==focused)
showPopupError(getError(e.error));});ev.device.addEventListener('update',e=>{if(e.device.info.id==focused&&screen=='ui'&&renderer)
renderer.handleUpdate(e.name,e.data);});ev.device.addEventListener('connectionstatus',e=>{if(e.device.info.id==focused)
errorBar(!e.status);});});hub.addEventListener('deviceinfochanged',ev=>{const dev=ev.device.info;EL(`name#${dev.id}`).textContent=dev.name?dev.name:'Unknown';EL(`device#${dev.id}`).title=`${dev.id} [${dev.prefix}]`;});hub.addEventListener('discoverfinished',()=>{if(screen=='main')spinArrows(false);});hub.addEventListener('protocolerror',ev=>{showPopupError(ev.text);});


